# MediLingual - Medical English Learning Platform

MediLingual is an interactive web application designed to help healthcare professionals improve their medical English communication skills. The platform offers a Duolingo-style learning experience with a focus on medical terminology and doctor-patient interactions.

## Features

- **Three Learning Levels**:
  - Level 1: Medical Vocabulary Practice
  - Level 2: Guided Clinical Cases
  - Level 3: Complex Clinical Cases with AI-powered responses

- **Real-time Translation**:
  - Instantly translate medical phrases into your native language
  - Supports multiple languages including Spanish, Portuguese, French, Italian, German, Arabic, and Hindi

- **Pronunciation Feedback**:
  - Record your pronunciation and receive immediate feedback
  - AI-powered analysis of pronunciation accuracy

- **Interactive Learning**:
  - Practice with realistic medical scenarios
  - Progress tracking and achievement system
  - Gamified learning experience

## Technology Stack

- **Frontend**:
  - React.js
  - Tailwind CSS
  - Lucide React for icons
  - React Router for navigation

- **Backend** (planned):
  - Node.js with Express
  - MongoDB for database
  - JWT for authentication
  - Speech-to-text and text-to-speech APIs

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/medilingual.git
   cd medilingual
   ```

2. Install dependencies:
   ```
   cd frontend
   npm install
   # or
   yarn install
   ```

3. Start the development server:
   ```
   npm run dev
   # or
   yarn dev
   ```

4. Open your browser and navigate to `http://localhost:5173`

## Project Structure

```
medilingual/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── AudioRecorder.jsx
│   │   │   ├── ComplexClinicalCase.jsx
│   │   │   ├── GuidedClinicalCase.jsx
│   │   │   ├── PracticePage.jsx
│   │   │   ├── PronunciationFeedback.jsx
│   │   │   ├── TranslationButton.jsx
│   │   │   └── VocabularyPractice.jsx
│   │   ├── App.jsx
│   │   ├── chooseLanguage.tsx
│   │   ├── login.jsx
│   │   └── main.jsx
│   ├── public/
│   └── package.json
└── backend/ (planned)
```

## Future Enhancements

- Mobile app versions for iOS and Android
- Offline mode for practicing without internet connection
- Integration with medical education platforms
- Community features for healthcare professionals
- Advanced AI for more realistic patient responses

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Inspired by the need for better medical communication across language barriers
- Special thanks to healthcare professionals who provided feedback during development 