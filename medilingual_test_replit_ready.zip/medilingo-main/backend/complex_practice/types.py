import graphene
from graphene_django import DjangoObjectType
from .models import PatientCase

class ComplexPatientCaseType(DjangoObjectType):
    class Meta:
        model = PatientCase
        fields = ('id', 'slug', 'title', 'content', 'speciality', 'level') 