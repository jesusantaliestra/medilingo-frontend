from django.db import models
from django_extensions.db.fields import AutoSlugField
from user import LanguageChoices
from practice.models import Level, Speciality, BaseModel
from user.models import User

class PatientCase(BaseModel):
    slug = AutoSlugField(populate_from='title', unique=True, verbose_name="Slug")
    title = models.CharField(max_length=255)
    content = models.TextField(verbose_name="Case Content")
    speciality = models.ForeignKey(Speciality, on_delete=models.CASCADE, verbose_name="Medical Speciality", related_name='complex_patient_cases')
    level = models.ForeignKey(Level, on_delete=models.CASCADE, verbose_name="Level", related_name='complex_patient_cases')
    language = models.CharField(max_length=3, choices=LanguageChoices, default=LanguageChoices.ENGLISH)

    def __str__(self):
        return f"{self.title} - {self.speciality.name}"

    class Meta:
        verbose_name = "Patient Case"
        verbose_name_plural = "Patient Cases"
        ordering = ['title']

    def case_text(self):
        return f"Case: {self.title.lower()}"

class UserPatientCaseAttempt(BaseModel):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="User", related_name='user_patient_case_attempts')
    patient_case = models.ForeignKey(PatientCase, on_delete=models.CASCADE, verbose_name="Patient Case", related_name='user_attempts')
    score = models.IntegerField(default=0, verbose_name="Score")
    completed = models.BooleanField(default=False, verbose_name="Completed")

    class Meta:
        unique_together = ('user', 'patient_case')
        verbose_name = "User Patient Case Attempt"
        verbose_name_plural = "User Patient Case Attempts"

    def __str__(self):
        return f"{self.user.username} - {self.patient_case.title}"
