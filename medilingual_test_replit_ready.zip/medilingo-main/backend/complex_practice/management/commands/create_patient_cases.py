from django.core.management.base import BaseCommand
from complex_practice.models import PatientCase
from practice.models import Level, Speciality
from django.db import IntegrityError

class Command(BaseCommand):
    help = 'Create patient cases with proper handling of unique_together constraint'

    def handle(self, *args, **options):
        # Get or create levels and specialities
        level1 = Level.objects.get_or_create(name='Beginner')[0]
        level2 = Level.objects.get_or_create(name='Intermediate')[0]
        level3 = Level.objects.get_or_create(name='Advanced')[0]

        speciality1 = Speciality.objects.get_or_create(name='Cardiology')[0]
        speciality2 = Speciality.objects.get_or_create(name='Neurology')[0]

        # Sample patient cases
        patient_cases = [
            {
                'title': 'Cardiac Case 1',
                'content': 'Patient presents with chest pain...',
                'level': level1,
                'speciality': speciality1
            },
            {
                'title': 'Neurological Case 1',
                'content': 'Patient presents with headache...',
                'level': level1,
                'speciality': speciality2
            },
            # Add more cases as needed
        ]

        created_count = 0
        skipped_count = 0

        for case_data in patient_cases:
            try:
                PatientCase.objects.create(**case_data)
                created_count += 1
                self.stdout.write(self.style.SUCCESS(f'Successfully created patient case: {case_data["title"]}'))
            except IntegrityError:
                skipped_count += 1
                self.stdout.write(self.style.WARNING(
                    f'Skipped creating patient case: {case_data["title"]} - '
                    f'Already exists for level {case_data["level"].name} and speciality {case_data["speciality"].name}'
                ))

        self.stdout.write(self.style.SUCCESS(
            f'Finished creating patient cases. Created: {created_count}, Skipped: {skipped_count}'
        )) 