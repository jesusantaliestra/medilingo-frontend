from django.contrib import admin
from .models import PatientCase

@admin.register(PatientCase)
class PatientCaseAdmin(admin.ModelAdmin):
    list_display = ('title', 'slug', 'speciality', 'level', 'created_at')
    list_filter = ('speciality', 'level', 'created_at')
    search_fields = ('title', 'slug', 'content')
    readonly_fields = ('created_at', 'updated_at', 'slug')
    fieldsets = (
        ('Case Information', {
            'fields': ('title', 'slug')
        }),
        ('Content', {
            'fields': ('content',),
            'classes': ('wide',)
        }),
        ('Relations', {
            'fields': ('speciality', 'level', 'language',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
