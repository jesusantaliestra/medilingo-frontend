from typing import Optional
from openai import OpenAI
from django.conf import settings
import json

from practice.language_code import get_language_native_name_by_code
from practice.models import Level, Speciality
from .models import PatientCase

def generate_clinical_case(
    level: 'Level',
    language: str,
    speciality: 'Speciality',
) -> Optional[PatientCase]:
    """
    Generate a clinical case if one doesn't exist for the given level, speciality and language.
    
    Args:
        level: Level instance for the case
        language: Language code (e.g., 'en', 'es')
        speciality: Speciality instance for the case
        
    Returns:
        PatientCase instance if created, None if case already exists
    """
    # Check if case already exists
    existing_case = PatientCase.objects.filter(
        level=level,
        speciality=speciality,
        language=language
    ).first()
    
    if existing_case:
        return None
        
    # Initialize OpenAI client
    client = OpenAI(api_key=settings.OPENAI_API_KEY)
    
    # Create prompt for OpenAI
    prompt = f"""Generate a realistic clinical case in {get_language_native_name_by_code(language)} language.
    This case should be appropriate for {speciality.name} speciality at {speciality.category.name} category.
    
    You must return a valid JSON object with exactly these fields:
    {{
        "title": "string",
        "content": "string"
    }}
    
    The title should be concise and descriptive of the case.
    The content should be detailed symptoms but no clinical findings and diagnosis. you just write the case, later doctor ask for any other information or suggest reports or medicine.
    
    Make it realistic and educational, focusing on common scenarios in {speciality.name}.
    Do not include any other text or explanation, only the JSON object.
    """
    
    try:
        # Call OpenAI API
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a medical education expert. You must respond with valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000,
            response_format={ "type": "json_object" }
        )
        
        # Parse the response
        case_data = json.loads(response.choices[0].message.content)
        
        # Create PatientCase instance
        case = PatientCase.objects.create(
            title=case_data['title'],
            content=case_data['content'],
            speciality=speciality,
            level=level,
            language=language
        )
        
        return case
        
    except Exception as e:
        raise Exception(f"Error generating clinical case: {str(e)}") 