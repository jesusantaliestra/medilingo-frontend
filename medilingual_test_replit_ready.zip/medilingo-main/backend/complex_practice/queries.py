import graphene
from .types import ComplexPatientCaseType
from .models import PatientCase
from practice.utils import get_user_speciality_cases

class ComplexPracticeQuery(graphene.ObjectType):
    complex_patient_cases = graphene.List(ComplexPatientCaseType)
    complex_patient_case = graphene.Field(ComplexPatientCaseType, slug=graphene.String())

    def resolve_complex_patient_cases(self, info):
        return get_user_speciality_cases(info.context.user)

    def resolve_complex_patient_case(self, info, slug):
        try:
            return PatientCase.objects.get(slug=slug)
        except PatientCase.DoesNotExist:
            return None 