import graphene
from graphene import relay


# Import queries from each app
from practice.queries import PracticeQuery
from user.queries import UserAdminQuery
from complex_practice.queries import ComplexPracticeQuery
from vocabulary_practice.queries import VocabularyPracticeQuery
from guided_practice.queries import GuidedPracticeQuery
from feedback.mutations import Query as FeedbackQuery
from oet.queries import ReadingQuery, WritingQuery, SpeakingQuery, ListeningQuery
from billing.queries import BillingQuery

# Import mutations from each app
from practice.mutations import PracticeMutation
from user.mutation import UserMutation
from user.admin_mutation import UserAdminMutation
from feedback.mutations import Mutation as FeedbackMutation
from oet.mutations import ReadingMutation
from billing.mutations import BillingMutation

class Query(
    PracticeQuery,
    UserAdminQuery,
    ComplexPracticeQuery,
    VocabularyPracticeQuery,
    GuidedPracticeQuery,
    FeedbackQuery,
    ReadingQuery,
    WritingQuery,
    SpeakingQuery,
    ListeningQuery,
    BillingQuery,
    graphene.ObjectType
):
    """
    Root query class that combines all query classes from different apps.
    This is the main entry point for all GraphQL queries.
    """
    pass

class Mutation(
    PracticeMutation,
    UserMutation,
    UserAdminMutation,
    FeedbackMutation,
    ReadingMutation,
    BillingMutation,
    graphene.ObjectType
):
    """
    Root mutation class that combines all mutation classes from different apps.
    This is the main entry point for all GraphQL mutations.
    """

# Create the schema with the combined Query and Mutation classes
medilingual_schema = graphene.Schema(query=Query, mutation=Mutation)