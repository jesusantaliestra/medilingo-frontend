import graphene
from graphene_django.types import ErrorType
from graphql import GraphQLError
from django.contrib.contenttypes.models import ContentType
from .models import Feedback
from .types import FeedbackType

class SaveFeedback(graphene.Mutation):
    class Arguments:
        content_type_id = graphene.ID(required=True)
        object_id = graphene.ID(required=True)
        feedback_text = graphene.String(required=True)
        score = graphene.Int(required=True)

    feedback = graphene.Field(FeedbackType)
    errors = graphene.List(ErrorType)

    def mutate(self, info, content_type_id, object_id, feedback_text, score):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to save feedback")

        try:
            content_type = ContentType.objects.get_for_id(content_type_id)
            feedback = Feedback.objects.create(
                user=info.context.user,
                content_type=content_type,
                object_id=object_id,
                feedback_text=feedback_text,
                score=score
            )
            return SaveFeedback(feedback=feedback, errors=None)
        except Exception as e:
            return SaveFeedback(feedback=None, errors=[ErrorType(field="error", messages=[str(e)])])

class Query(graphene.ObjectType):
    feedback = graphene.List(FeedbackType)

    def resolve_feedback(self, info):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to view feedback")
        return Feedback.objects.filter(user=info.context.user).order_by('-created_at')

class Mutation(graphene.ObjectType):
    save_feedback = SaveFeedback.Field() 