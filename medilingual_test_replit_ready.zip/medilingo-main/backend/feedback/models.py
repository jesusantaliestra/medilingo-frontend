from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey, GenericRelation
from django.contrib.contenttypes.models import ContentType
from user.models import User

class Feedback(models.Model):
    """Model to store feedback for completed consultations"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='feedback')
    
    # Generic relation fields
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')
    
    feedback_text = models.TextField(verbose_name="Feedback")
    score = models.IntegerField(verbose_name="Score")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Feedback for {self.user.username} - {self.content_object}"

    class Meta:
        verbose_name = "Feedback"
        verbose_name_plural = "Feedback"
        ordering = ['-created_at']

