import graphene
from graphene_django import DjangoObjectType
from graphene import relay
from django.contrib.contenttypes.models import ContentType
from .models import Feedback
from complex_practice.types import ComplexPatientCaseType
from guided_practice.types import GuidedPracticeType
from vocabulary_practice.types import VocabularyType

class ContentTypeType(DjangoObjectType):
    class Meta:
        model = ContentType
        interfaces = (relay.Node,)
        fields = ('id', 'app_label', 'model')

class PracticeUnion(graphene.Union):
    class Meta:
        types = (ComplexPatientCaseType, GuidedPracticeType, VocabularyType)

class FeedbackType(DjangoObjectType):
    content_type = graphene.Field(ContentTypeType)
    content_object = graphene.Field(PracticeUnion)

    class Meta:
        model = Feedback
        interfaces = (relay.Node,)
        fields = ('id', 'user', 'content_type', 'object_id', 'feedback_text', 'score', 'created_at', 'updated_at')

    def resolve_content_object(self, info):
        return self.content_object 