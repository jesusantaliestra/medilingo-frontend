from django.db import models
from django.conf import settings
from django.utils import timezone

# Create your models here.

class Subscription(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    start_date = models.DateTimeField(default=timezone.now)
    end_date = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    is_cancelled = models.BooleanField(default=False)
    plan_name = models.CharField(max_length=50, default='Practice Monthly')
    plan_price = models.DecimalField(max_digits=6, decimal_places=2, default=5.00)
    credits_allocated = models.IntegerField(default=100)
    payment_id = models.CharField(max_length=255, null=True, blank=True)
    stripe_subscription_id = models.CharField(max_length=255, null=True, blank=True)
    subscription_type = models.CharField(
        max_length=20,
        choices=[
            ('general', 'General'), # recurring
            ('oet', 'OET'), # one-off
            ('general_oet', 'General + OET (Recurring)'), # recurring
        ],
        default='general'
    )

    def __str__(self):
        return f"{self.user.username} - {self.plan_name} ({'Active' if self.is_active else 'Inactive'})"

class Credit(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    amount = models.IntegerField()
    created_at = models.DateTimeField(default=timezone.now)
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.user.username}: {self.amount} ({self.description})"
    


class Plan(models.Model):
    name = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    payment_link = models.URLField(max_length=255)
    credits_allocated = models.IntegerField()
    features_included = models.JSONField(default=list) # list of text lines
    features_excluded = models.JSONField(default=list) # list of text lines
    pricing_id = models.CharField(max_length=255, null=True, blank=True)
    price_id = models.CharField(max_length=255, unique=True, null=True, blank=True)

    # month or year or week or day or tri-month or quarter
    frequency = models.CharField(max_length=50, help_text="will not use to check any condition, only for display purposes") # will not use to check any condition, only for display purposes

    # fill only if oet
    one_off_months = models.IntegerField(default=1, help_text="every 1 month or 3 months or 6 months or 12 months (only for one-off payments)") # every 1 month or 3 months or 6 months or 12 months
    plan_type = models.CharField(
        max_length=20,
        choices=[
            ('general', 'General (Recurring) '), # recurring
            ('oet', 'OET (One-off)'), # one-off
            ('general_oet', 'General + OET (Recurring)'), # recurring
        ],
        default='general'
    )

    def __str__(self):
        return self.name