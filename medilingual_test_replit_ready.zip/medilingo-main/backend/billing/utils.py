from django.db import transaction
from .models import Credit
import logging

logger = logging.getLogger(__name__)

def reduce_user_credits(user, amount=1):
    try:
        with transaction.atomic():
            credit, created = Credit.objects.get_or_create(
                user=user,
                defaults={'amount': 0}
            )

            if credit.amount == 0:
                # Update user's credit availability status
                user.has_available_credits = credit.amount > 0
                user.save(update_fields=['has_available_credits'])
            
            # Check if user has enough credits
            if credit.amount < amount:
                logger.warning(f"User {user.email} has insufficient credits. Available: {credit.amount}, Required: {amount}")
                return False, "Insufficient credits"
            
            # Reduce credits
            credit.amount -= amount
            credit.save()
            
            
            
            logger.info(f"Successfully reduced {amount} credits for user {user.email}. New balance: {credit.amount}")
            return True, "Credits reduced successfully"
            
    except Exception as e:
        logger.error(f"Error reducing credits for user {user.email}: {str(e)}")
        return False, f"Error reducing credits: {str(e)}" 