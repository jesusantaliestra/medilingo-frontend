import graphene
from graphql import GraphQLError
from .models import Subscription
import stripe
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

stripe.api_key = settings.STRIPE_SECRET_KEY

class CancelSubscription(graphene.Mutation):
    class Meta:
        description = "Cancel a user's active subscription"

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to cancel your subscription")

        try:
            # Get user's active subscription
            subscription = Subscription.objects.filter(
                user=info.context.user,
                is_active=True
            ).first()

            if not subscription:
                return CancelSubscription(
                    success=False,
                    message="No active subscription found"
                )

            if not subscription.stripe_subscription_id:
                return CancelSubscription(
                    success=False,
                    message="No Stripe subscription ID found"
                )

            # Cancel the subscription in Stripe
            stripe.Subscription.modify(
                subscription.stripe_subscription_id,
                cancel_at_period_end=True
            )

            # We'll let the webhook handle the status updates
            return CancelSubscription(
                success=True,
                message="Subscription will be cancelled at the end of the billing period"
            )

        except stripe.error.StripeError as e:
            logger.error(f"Stripe error: {str(e)}")
            return CancelSubscription(
                success=False,
                message=str(e)
            )
        except Exception as e:
            logger.error(f"Error cancelling subscription: {str(e)}")
            return CancelSubscription(
                success=False,
                message="An error occurred while cancelling the subscription"
            )

class CreateCustomerPortalSession(graphene.Mutation):
    class Meta:
        description = "Create a Stripe Customer Portal session for subscription management"

    url = graphene.String()
    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to access the customer portal")

        try:
            # Get user's active subscription
            subscription = Subscription.objects.filter(
                user=info.context.user,
                is_active=True
            ).first()

            if not subscription:
                logger.warning(f"No active subscription found for user {info.context.user.email}")
                return CreateCustomerPortalSession(
                    success=False,
                    message="No active subscription found",
                    url=None
                )

            if not subscription.stripe_subscription_id:
                logger.warning(f"No Stripe subscription ID found for subscription {subscription.id}")
                return CreateCustomerPortalSession(
                    success=False,
                    message="No Stripe subscription ID found",
                    url=None
                )

            logger.info(f"Retrieving Stripe subscription {subscription.stripe_subscription_id}")
            
            try:
                # Get the Stripe subscription to find the customer
                stripe_subscription = stripe.Subscription.retrieve(subscription.stripe_subscription_id)
                customer_id = stripe_subscription.customer
                
                logger.info(f"Found customer ID: {customer_id}")

                # Verify the customer exists
                try:
                    stripe.Customer.retrieve(customer_id)
                except stripe.error.InvalidRequestError as e:
                    error_msg = f"Customer {customer_id} not found in Stripe: {str(e)}"
                    logger.error(error_msg)
                    return CreateCustomerPortalSession(
                        success=False,
                        message=error_msg,
                        url=None
                    )

                
    

                # Create the portal session
                logger.info(f"Creating portal session for customer {customer_id}")
                session = stripe.billing_portal.Session.create(
                    customer=customer_id,
                    return_url=settings.FRONTEND_URL + '/settings'
                )

                logger.info(f"Portal session created successfully: {session.url}")
                return CreateCustomerPortalSession(
                    success=True,
                    message="Portal session created successfully",
                    url=session.url
                )

            except stripe.error.InvalidRequestError as e:
                error_msg = f"Invalid Stripe subscription ID {subscription.stripe_subscription_id}: {str(e)}"
                logger.error(error_msg)
                return CreateCustomerPortalSession(
                    success=False,
                    message=error_msg,
                    url=None
                )

        except stripe.error.StripeError as e:
            error_msg = f"Stripe error: {str(e)}"
            logger.error(error_msg)
            return CreateCustomerPortalSession(
                success=False,
                message=error_msg,
                url=None
            )
        except Exception as e:
            error_msg = f"Unexpected error: {str(e)}"
            logger.error(error_msg)
            logger.exception(e)  # This will log the full stack trace
            return CreateCustomerPortalSession(
                success=False,
                message=error_msg,
                url=None
            )

class BillingMutation(graphene.ObjectType):
    cancel_subscription = CancelSubscription.Field()
    create_customer_portal_session = CreateCustomerPortalSession.Field() 