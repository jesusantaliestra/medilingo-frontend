from django.urls import path
from .views import StripeSubscriptionWebhook, StripePaymentList

urlpatterns = [
    path('stripe/webhook/', StripeSubscriptionWebhook.as_view(), name='stripe-webhook'),
    path('stripe/payments/', StripePaymentList.as_view(), name='stripe-payments'),
] 