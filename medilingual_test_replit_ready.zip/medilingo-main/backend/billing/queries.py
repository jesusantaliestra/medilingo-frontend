import graphene
from .types import PlanType, SubscriptionType, CreditType
from .models import Plan, Subscription, Credit

class BillingQuery(graphene.ObjectType):
    all_plans = graphene.List(PlanType)
    plan = graphene.Field(PlanType, id=graphene.ID())
    my_active_subscription = graphene.Field(SubscriptionType)
    my_active_oet_subscription = graphene.Field(SubscriptionType)
    my_credit_balance = graphene.Field(CreditType)

    def resolve_all_plans(self, info):
        return Plan.objects.all()

    def resolve_plan(self, info, id):
        return Plan.objects.get(pk=id)

    def resolve_my_active_subscription(self, info):
        user = info.context.user
        if user.is_anonymous:
            return None
        return Subscription.objects.filter(
            user=user,
            is_active=True,
            subscription_type__in=['general', 'general_oet'],
        ).order_by('-start_date').first() 
    
    def resolve_my_active_oet_subscription(self, info):
        user = info.context.user
        if user.is_anonymous:
            return None
        return Subscription.objects.filter(
            user=user,
            is_active=True,
            subscription_type='oet',
        ).order_by('-start_date').first() 

    def resolve_my_credit_balance(self, info):
        user = info.context.user
        if user.is_anonymous:
            return None
        credit, created = Credit.objects.get_or_create(
            user=user,
            defaults={'amount': 0}
        )
        return credit 