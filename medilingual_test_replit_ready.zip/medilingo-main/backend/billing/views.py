from django.shortcuts import render
import stripe
from django.conf import settings
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from user.models import User
from .models import Credit, Subscription, Plan
from datetime import timedelta
from django.utils import timezone
from rest_framework.permissions import IsAuthenticated
import logging
import pytz

logger = logging.getLogger(__name__)

stripe.api_key = settings.STRIPE_SECRET_KEY

@method_decorator(csrf_exempt, name='dispatch')
class StripeSubscriptionWebhook(APIView):
    authentication_classes = []  # Webhooks are unauthenticated
    permission_classes = []

    def post(self, request, *args, **kwargs):
        payload = request.body
        sig_header = request.META.get('HTTP_STRIPE_SIGNATURE')
        endpoint_secret = settings.STRIPE_WEBHOOK_SECRET

        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, endpoint_secret
            )
            logger.info(f"Received Stripe webhook event: {event['type']}")
        except ValueError as e:
            logger.error(f"Invalid payload: {str(e)}")
            return Response({'error': 'Invalid payload'}, status=400)
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"Invalid signature: {str(e)}")
            return Response({'error': 'Invalid signature'}, status=400)

        # Handle the event
        try:
            if event['type'] == 'checkout.session.completed':
                logger.info("Processing checkout.session.completed event")
                self._handle_checkout_session_completed(event)
            elif event['type'] == 'invoice.paid':
                logger.info("Processing invoice.paid event")
                self._handle_invoice_paid(event)
            elif event['type'] == 'customer.subscription.deleted':
                logger.info("Processing customer.subscription.deleted event")
                self._handle_subscription_deleted(event)
            elif event['type'] == 'customer.subscription.updated':
                logger.info("Processing customer.subscription.updated event")
                self._handle_subscription_updated(event)
            
            return Response({'status': 'success'})
        except Exception as e:
            logger.error(f"Error processing webhook: {str(e)}")
            return Response({'error': str(e)}, status=500)

    def _handle_checkout_session_completed(self, event):
        session = event['data']['object']
        logger.info(f"Processing checkout session: {session.get('id')}")
        
        try:
            # Get client reference ID which contains user_id
            client_reference_id = session.get('client_reference_id')
            if not client_reference_id:
                logger.error("No client reference ID found in session")
                raise ValueError("No client reference ID found in session")
            
            logger.info(f"Client reference ID (user_id): {client_reference_id}")
            
            try:
                user = User.objects.get(id=client_reference_id)
                
                # Get the subscription ID and retrieve subscription details
                subscription_id = session.get('subscription')
                plan = None  # Initialize plan variable
                
                if subscription_id:
                    # Retrieve the subscription to get the price ID
                    stripe_subscription = stripe.Subscription.retrieve(subscription_id)
                    subscription_items = stripe_subscription.get('items', {}).get('data', [])
                    if subscription_items:
                        price_id = subscription_items[0].get('price', {}).get('id')
                        logger.info(f"Found price ID from subscription: {price_id}")
                        plan = Plan.objects.get(price_id=price_id)
                        logger.info(f"Found user: {user.email} and plan: {plan.name}")
                    else:
                        logger.error("No subscription items found")
                        raise ValueError("No subscription items found")
                else:
                    # For one-off payments, get plan from line items
                    logger.info("No subscription ID found in session, checking line items for one-off payment")
                    line_items = stripe.checkout.Session.list_line_items(session.id, limit=1)
                    if line_items and line_items.data:
                        price_id = line_items.data[0].price.id
                        logger.info(f"Found price ID from line items: {price_id}")
                        try:
                            plan = Plan.objects.get(price_id=price_id)
                            logger.info(f"Found plan from line items: {plan.name}")
                        except Plan.DoesNotExist:
                            logger.error(f"Plan not found for price_id: {price_id}")
                            raise
                    else:
                        logger.error("No line items found in session")
                        raise ValueError("No line items found in session")

            except (User.DoesNotExist, Plan.DoesNotExist) as e:
                logger.error(f"User or Plan not found: {str(e)}")
                raise

            # Get payment details
            payment_intent = session.get('payment_intent')
            session_id = session.get('id')
            payment_status = session.get('payment_status')
            
            logger.info(f"Session details - payment_intent: {payment_intent}, session_id: {session_id}, payment_status: {payment_status}")

            # Calculate subscription period based on plan type
            start_date = timezone.now()
            
            if not plan:
                logger.error("Plan not found in session")
                raise ValueError("Plan not found in session")

            if plan.plan_type == 'oet':
                # For OET one-off payments
                end_date = start_date + timedelta(days=30 * plan.one_off_months)
                subscription_type = 'oet'
                if payment_status == 'paid':
                    user.has_valid_oet_subscription = True
                    logger.info(f"OET payment successful - setting has_valid_oet_subscription to True")
                else:
                    logger.warning(f"OET payment not successful - payment_status: {payment_status}")
            else:
                # For recurring subscriptions (general or general_oet)
                if subscription_id:
                    try:
                        # We already have the stripe_subscription from earlier
                        start_timestamp = stripe_subscription.get('current_period_start')
                        end_timestamp = stripe_subscription.get('current_period_end')
                        
                        if start_timestamp and end_timestamp:
                            start_date = timezone.datetime.fromtimestamp(start_timestamp).replace(tzinfo=pytz.UTC)
                            end_date = timezone.datetime.fromtimestamp(end_timestamp).replace(tzinfo=pytz.UTC)
                            logger.info(f"Using subscription period: {start_date} to {end_date}")
                        else:
                            logger.warning("Missing timestamps in subscription, using default period")
                            end_date = start_date + timedelta(days=30)
                    except Exception as e:
                        logger.error(f"Error getting subscription dates: {str(e)}")
                        end_date = start_date + timedelta(days=30)
                else:
                    logger.warning("No subscription_id found in session, using default period")
                    end_date = start_date + timedelta(days=30)
                
                subscription_type = plan.plan_type
                # Update subscription status based on plan type
                if plan.plan_type == 'general_oet':
                    user.subscription_valid = True
                    user.has_valid_oet_subscription = True
                    logger.info("Setting both general and OET subscriptions to valid")
                else:  # general type
                    user.subscription_valid = True
                    logger.info("Setting general subscription to valid")

            # Store the payment ID (try payment_intent first, then session ID)
            payment_id = payment_intent or session_id
            logger.info(f"Using payment_id: {payment_id} for subscription storage")

            # Create or update subscription
            try:
                sub, created = Subscription.objects.get_or_create(
                    user=user,
                    defaults={
                        'start_date': start_date,
                        'end_date': end_date,
                        'plan_name': plan.name,
                        'plan_price': plan.price,
                        'credits_allocated': plan.credits_allocated,
                        'payment_id': payment_id,
                        'is_active': True,
                        'subscription_type': subscription_type,
                        'stripe_subscription_id': subscription_id if subscription_type in ['general', 'general_oet'] else None
                    }
                )

                if not created:
                    logger.info(f"Updating existing subscription for user: {user.email}")
                    sub.is_active = True
                    sub.start_date = start_date
                    sub.end_date = end_date
                    sub.plan_name = plan.name
                    sub.plan_price = plan.price
                    sub.credits_allocated = plan.credits_allocated
                    sub.payment_id = payment_id
                    sub.subscription_type = subscription_type
                    sub.stripe_subscription_id = subscription_id if subscription_type in ['general', 'general_oet'] else None
                    sub.save()
                else:
                    logger.info(f"Created new subscription for user: {user.email}")

                # Create or update user credits
                credit, created = Credit.objects.get_or_create(
                    user=user,
                    defaults={'amount': plan.credits_allocated}
                )

                if not created:
                    # Add the new credits to existing balance
                    credit.amount += plan.credits_allocated
                    credit.save()
                    logger.info(f"Updated credit balance for user {user.email}: {credit.amount}")
                else:
                    logger.info(f"Created new credit balance for user {user.email}: {credit.amount}")

                # Update user subscription and credit status
                user.has_available_credits = credit.amount > 0
                user.save()
                
                logger.info(f"Updated user status - subscription_valid: {user.subscription_valid}, has_valid_oet_subscription: {user.has_valid_oet_subscription}, has_available_credits: {user.has_available_credits}")

            except Exception as e:
                logger.error(f"Error saving subscription: {str(e)}")
                logger.exception(e)
                raise

        except Exception as e:
            logger.error(f"Error in checkout session completion: {str(e)}")
            logger.exception(e)
            raise

    def _handle_invoice_paid(self, event):
        invoice = event['data']['object']
        logger.info(f"Processing invoice: {invoice.get('id')}")
        
        subscription_id = invoice.get('subscription')
        customer_id = invoice.get('customer')
        payment_intent = invoice.get('payment_intent')
        
        logger.info(f"Invoice details - subscription_id: {subscription_id}, customer_id: {customer_id}, payment_intent: {payment_intent}")
        
        if subscription_id:
            try:
                # Get subscription details from Stripe
                stripe_subscription = stripe.Subscription.retrieve(subscription_id)
                customer = stripe.Customer.retrieve(customer_id)
                customer_email = customer.get('email')
                
                logger.info(f"Retrieved customer email from Stripe: {customer_email}")
                
                if customer_email:
                    logger.info(f"Processing invoice.paid for customer email: {customer_email}")
                    user = User.objects.get(email=customer_email)
                    logger.info(f"Found user in database: {user.email}")
                    
                    # Try to find subscription by payment_id which could be either payment_intent or session id
                    subscription = None
                    possible_payment_ids = [
                        payment_intent,
                        invoice.get('id'),
                        subscription_id
                    ]
                    
                    logger.info(f"Attempting to find subscription with payment_ids: {possible_payment_ids}")
                    
                    # First try exact match
                    for payment_id in possible_payment_ids:
                        if payment_id:
                            subscription = Subscription.objects.filter(
                                user=user,
                                payment_id=payment_id,
                            ).first()
                            if subscription:
                                logger.info(f"Found subscription with payment_id: {payment_id}")
                                break
                            else:
                                logger.info(f"No subscription found with payment_id: {payment_id}")
                    
                    # If no exact match, try to find any active subscription for the user
                    if not subscription:
                        subscription = Subscription.objects.filter(
                            user=user,
                            is_active=True
                        ).order_by('-start_date').first()
                        if subscription:
                            logger.info(f"Found active subscription for user with payment_id: {subscription.payment_id}")
                    
                    if subscription:
                        # Update subscription status and stripe_subscription_id
                        subscription.is_active = True
                        subscription.stripe_subscription_id = subscription_id  # Store the Stripe subscription ID
                        subscription.save()
                        
                        # Get plan from subscription items
                        subscription_items = stripe_subscription.get('items', {}).get('data', [])
                        if subscription_items:
                            price_id = subscription_items[0].get('price', {}).get('id')
                            if price_id:
                                try:
                                    plan = Plan.objects.get(price_id=price_id)
                                    logger.info(f"Found plan from price_id: {plan.name}")
                                    
                                    # Create or update user credits
                                    credit, created = Credit.objects.get_or_create(
                                        user=user,
                                        defaults={'amount': plan.credits_allocated}
                                    )

                                    if not created:
                                        # Add the new credits to existing balance
                                        credit.amount += plan.credits_allocated
                                        credit.save()
                                        logger.info(f"Updated credit balance for user {user.email}: {credit.amount}")
                                    else:
                                        logger.info(f"Created new credit balance for user {user.email}: {credit.amount}")

                                    # Update user status
                                    user.subscription_valid = True
                                    user.has_available_credits = credit.amount > 0
                                    if plan.plan_type == 'general_oet':
                                        user.has_valid_oet_subscription = True
                                    user.save()
                                    
                                    logger.info(f"Updated user status - subscription_valid: {user.subscription_valid}, has_valid_oet_subscription: {user.has_valid_oet_subscription}, has_available_credits: {user.has_available_credits}")
                                except Plan.DoesNotExist:
                                    logger.error(f"Plan not found for price_id: {price_id}")
                        else:
                            logger.warning("No subscription items found in Stripe subscription")
                    else:
                        logger.warning(f"No subscription found for user {user.email}")
                else:
                    logger.error("No customer email found in Stripe data")
            except User.DoesNotExist:
                logger.error(f"User not found for email: {customer_email}")
            except stripe.error.StripeError as e:
                logger.error(f"Stripe error while processing invoice.paid: {str(e)}")
            except Exception as e:
                logger.error(f"Unexpected error processing invoice.paid: {str(e)}")
                logger.exception(e)  # This will log the full stack trace
        else:
            logger.warning("No subscription_id found in invoice.paid event")

    def _handle_subscription_deleted(self, event):
        subscription = event['data']['object']
        try:
            user_subscription = Subscription.objects.get(
                stripe_subscription_id=subscription.get('id')
            )
            logger.info(f"Processing subscription deletion for user: {user_subscription.user.email}")
            
            user_subscription.is_cancelled = True
            user_subscription.is_active = False
            user_subscription.save()
            
            user = user_subscription.user
            
            # Update subscription flags based on subscription type
            if user_subscription.subscription_type == 'oet':
                user.has_valid_oet_subscription = False
            elif user_subscription.subscription_type == 'general_oet':
                user.has_valid_oet_subscription = False
                user.subscription_valid = False
            else:  # general type
                user.subscription_valid = False
            
            # Check if user still has any active subscriptions
            has_active_subscription = Subscription.objects.filter(
                user=user,
                is_active=True
            ).exists()
            
            if not has_active_subscription:
                # If no active subscriptions, set credit balance to 0
                credit, created = Credit.objects.get_or_create(
                    user=user,
                    defaults={'amount': 0}
                )
                if not created:
                    credit.amount = 0
                    credit.save()
                user.has_available_credits = False
            
            user.save()
            
            logger.info(f"Updated user status after subscription deletion - subscription_valid: {user.subscription_valid}, has_valid_oet_subscription: {user.has_valid_oet_subscription}, has_available_credits: {user.has_available_credits}")
        except Subscription.DoesNotExist:
            logger.warning(f"Subscription not found for ID: {subscription.get('id')}")

    def _handle_subscription_updated(self, event):
        subscription = event['data']['object']
        try:
            user_subscription = Subscription.objects.get(
                stripe_subscription_id=subscription.get('id')
            )
            
            # For OET one-off payments, we don't need to check subscription status
            if user_subscription.subscription_type == 'oet':
                logger.info(f"OET one-off payment subscription - no need to check status")
                return
            
            # Update subscription dates
            start_timestamp = subscription['current_period_start']
            end_timestamp = subscription['current_period_end']
            user_subscription.start_date = timezone.datetime.fromtimestamp(start_timestamp).replace(tzinfo=pytz.UTC)
            user_subscription.end_date = timezone.datetime.fromtimestamp(end_timestamp).replace(tzinfo=pytz.UTC)
            
            # Check if subscription is cancelled
            cancel_at_period_end = subscription.get('cancel_at_period_end', False)
            is_active = subscription['status'] == 'active'
            
            # If subscription is cancelled but still active, it means it will be cancelled at period end
            if cancel_at_period_end and is_active:
                logger.info(f"Subscription {subscription.get('id')} will be cancelled at period end")
                # We keep is_active as True until the period ends
                user_subscription.is_cancelled = True
            else:
                user_subscription.is_active = is_active
                
            user_subscription.save()
            
            # Update user subscription status - only for general subscriptions
            user = user_subscription.user
            user.subscription_valid = is_active
            user.has_valid_oet_subscription = is_active
                
           
            user.save()
            
            logger.info(f"Updated subscription status - is_active: {is_active}, cancel_at_period_end: {cancel_at_period_end}, subscription_type: {user_subscription.subscription_type}")
            
        except Subscription.DoesNotExist:
            logger.warning(f"Subscription not found for ID: {subscription.get('id')}")

    def get(self, request):
        # GET not allowed
        return Response({'error': 'GET not allowed'}, status=405)

class StripePaymentList(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        payments = stripe.PaymentIntent.list(limit=20)
        return Response(payments['data'])
