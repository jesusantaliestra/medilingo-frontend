import graphene
from graphene_django import DjangoObjectType
from .models import Plan, Subscription, Credit
from urllib.parse import urlencode

class PlanType(DjangoObjectType):
    features_included = graphene.List(graphene.String)
    features_excluded = graphene.List(graphene.String)
    payment_link = graphene.String()

    class Meta:
        model = Plan
        fields = ('id', 'name', 'price', 'credits_allocated', 'features_included', 'features_excluded', 'frequency')

    def resolve_features_included(self, info):
        return self.features_included or []

    def resolve_features_excluded(self, info):
        return self.features_excluded or []
    
    def resolve_payment_link(self, info):
        if not info.context.user.is_authenticated:
            return self.payment_link
        
        user = info.context.user
        client_reference_id = str(user.id)  # Only use user ID
        base_url = self.payment_link
        
        # Add query parameters
        params = {
            'client_reference_id': client_reference_id,
            'prefilled_email': user.email
        }
        
        # Construct the URL with query parameters
        return f"{base_url}?{urlencode(params)}"

class SubscriptionType(DjangoObjectType):
    class Meta:
        model = Subscription
        fields = ('id', 'user', 'start_date', 'end_date', 'is_active', 'is_cancelled', 'plan_name', 'plan_price', 'credits_allocated', 'payment_id')

class CreditType(DjangoObjectType):
    class Meta:
        model = Credit
        fields = ('id', 'user', 'amount', 'created_at', 'description') 