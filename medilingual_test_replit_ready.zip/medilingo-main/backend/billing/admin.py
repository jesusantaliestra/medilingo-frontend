from django.contrib import admin
from .models import Subscription, Credit, Plan

# Register your models here.

@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ('user', 'plan_name', 'start_date', 'end_date', 'is_active', 'credits_allocated')
    list_filter = ('is_active', 'plan_name', 'start_date')
    search_fields = ('user__username', 'user__email', 'plan_name')
    readonly_fields = ('start_date',)
    fieldsets = (
        ('User Information', {
            'fields': ('user', 'is_active', 'is_cancelled',)
        }),
        ('Subscription Details', {
            'fields': ('plan_name', 'plan_price', 'credits_allocated', 'start_date', 'end_date', 'subscription_type',)
        }),
        ('Payment Information', {
            'fields': ('payment_id', "stripe_subscription_id")
        }),
    )

@admin.register(Credit)
class CreditAdmin(admin.ModelAdmin):
    list_display = ('user', 'amount', 'created_at', 'description')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'user__email', 'description')
    readonly_fields = ('created_at',)

@admin.register(Plan)
class PlanAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'credits_allocated', 'frequency')
    list_filter = ('frequency',)
    search_fields = ('name',)
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'price', 'frequency', 'one_off_months', 'plan_type', 'price_id',)
        }),
        ('Plan Details', {
            'fields': ('credits_allocated', 'payment_link')
        }),
        ('Features', {
            'fields': ('features_included', 'features_excluded'),
            'description': 'Enter features as a list of text lines'
        }),
    )
