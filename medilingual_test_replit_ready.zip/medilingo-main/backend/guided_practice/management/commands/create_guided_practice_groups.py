from django.core.management.base import BaseCommand
from guided_practice.models import GuidedPraticeGroup, GuidedPractice
from practice.models import Level, Speciality
from django.db import IntegrityError

class Command(BaseCommand):
    help = 'Add practices to existing guided practice groups'

    def handle(self, *args, **options):
        # Get the existing group
        level2 = Level.objects.filter(slug='level-2').first()
        emergency_speciality = Speciality.objects.filter(name='Emergency Doctor').first()

        if not level2 or not emergency_speciality:
            self.stdout.write(self.style.ERROR('Required level or speciality not found'))
            return

        # Get the existing group
        group = GuidedPraticeGroup.objects.filter(
            level=level2,
            speciality=emergency_speciality,
            name='Trauma Assessment'
        ).first()

        if not group:
            self.stdout.write(self.style.ERROR('Guided practice group not found. Please run initialize_practice_data first.'))
            return

        # Add practices under this group
        practices = [
            {
                'title': 'Chest Pain Evaluation',
                'content': 'A 45-year-old male presents with acute chest pain...',
                'group': group
            },
            {
                'title': 'Abdominal Pain Assessment',
                'content': 'A 32-year-old female presents with severe abdominal pain...',
                'group': group
            },
            {
                'title': 'Respiratory Distress Management',
                'content': 'A 60-year-old patient presents with acute respiratory distress...',
                'group': group
            }
        ]

        created_count = 0
        for practice_data in practices:
            try:
                GuidedPractice.objects.create(**practice_data)
                created_count += 1
                self.stdout.write(self.style.SUCCESS(f'Successfully created practice: {practice_data["title"]}'))
            except IntegrityError:
                self.stdout.write(self.style.WARNING(f'Practice already exists: {practice_data["title"]}'))

        self.stdout.write(self.style.SUCCESS(f'Finished creating {created_count} practices')) 