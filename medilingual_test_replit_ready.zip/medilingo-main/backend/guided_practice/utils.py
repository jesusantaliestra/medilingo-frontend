from typing import List, Tuple
from openai import OpenAI
from django.conf import settings
import json

from practice.language_code import get_language_native_name_by_code
from practice.models import Level, Speciality
from .models import GuidedPraticeGroup, GuidedPractice

def generate_guided_practice_content(
    level: 'Level',
    language: str,
    speciality: 'Speciality',
    n_conversations: int = 5
) -> Tuple[GuidedPraticeGroup, List[GuidedPractice]]:
    """
    Generate guided practice content using OpenAI API.
    
    Args:
        level: Level instance for the practice
        language: Language code (e.g., 'en', 'es')
        speciality: Speciality instance for the practice
        n_conversations: Number of doctor-patient conversations to generate
        
    Returns:
        Tuple containing the created GuidedPracticeGroup and list of GuidedPractice instances
    """
    # Initialize OpenAI client
    client = OpenAI(api_key=settings.OPENAI_API_KEY)
    
    # First, generate the practice group name and description
    group_prompt = f"""Generate a name and description for a medical practice group in {get_language_native_name_by_code(language)}.
    This is for {speciality.name} speciality at {speciality.category.name} category.
    
    You must return a valid JSON object with exactly these fields:
    {{
        "name": "string",
        "description": "string"
    }}
    
    The name should be concise and descriptive, and the description should explain the purpose of this practice group.
    Do not include any other text or explanation, only the JSON object.
    """
    
    try:
        # Generate practice group content
        group_response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a medical education expert. You must respond with valid JSON only."},
                {"role": "user", "content": group_prompt}
            ],
            temperature=0.7,
            max_tokens=500,
            response_format={ "type": "json_object" }
        )
        
        group_data = json.loads(group_response.choices[0].message.content)
        
        # Create the practice group
        practice_group = GuidedPraticeGroup.objects.create(
            name=group_data['name'],
            description=group_data['description'],
            speciality=speciality,
            level=level,
            language=language
        )
        
        # Generate conversations
        conversations_prompt = f"""Generate {n_conversations} doctor-patient conversations in {get_language_native_name_by_code(language)}.
        These conversations should be appropriate for {speciality.name} speciality at {level.name} level.
        
        You must return a valid JSON object with a 'conversations' array containing {n_conversations} objects, where each object has exactly these fields:
        {{
            "conversations": [
                {{
                    "doctor_message": "string",
                    "patient_message": "string",
                    "sequence": number
                }},
                ...
            ]
        }}
        
        The conversations should be realistic and educational, focusing on common scenarios in {speciality.name}.
        The sequence should start from 0 and increment by 1 for each conversation.
        Do not include any other text or explanation, only the JSON object.
        """
        
        conversations_response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a medical education expert. You must respond with valid JSON only."},
                {"role": "user", "content": conversations_prompt}
            ],
            temperature=0.7,
            max_tokens=2000,
            response_format={ "type": "json_object" }
        )
        
        conversations_data = json.loads(conversations_response.choices[0].message.content)
        
        # Create GuidedPractice instances
        practice_items = []
        for conv_data in conversations_data['conversations']:
            practice = GuidedPractice.objects.create(
                doctor_message=conv_data['doctor_message'],
                patient_message=conv_data['patient_message'],
                sequence=conv_data['sequence'],
                practice_group=practice_group
            )
            practice_items.append(practice)
            
        return practice_group, practice_items
        
    except Exception as e:
        raise Exception(f"Error generating guided practice content: {str(e)}") 