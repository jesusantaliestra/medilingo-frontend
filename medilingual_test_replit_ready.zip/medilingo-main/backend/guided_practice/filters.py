import django_filters
from .models import GuidedPractice, GuidedPraticeGroup

class GuidedPracticeFilterSet(django_filters.FilterSet):
    class Meta:
        model = GuidedPractice
        fields = ['id', 'doctor_message', 'patient_message', 'sequence', 'practice_group']

class GuidedPracticeGroupFilterSet(django_filters.FilterSet):
    class Meta:
        model = GuidedPraticeGroup
        fields = ['id', 'name', 'slug', 'description', 'speciality', 'level'] 