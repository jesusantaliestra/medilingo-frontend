import graphene
from graphene_django import DjangoObjectType
from graphene import relay
from graphene_django.filter import DjangoFilterConnectionField
from .models import GuidedPraticeGroup, GuidedPractice, UserGuidedPracticeAttempt
from .filters import GuidedPracticeFilterSet



class GuidedPracticeType(DjangoObjectType):
    class Meta:
        model = GuidedPractice
        interfaces = (relay.Node,)
        fields = ('id', 'doctor_message', 'patient_message', 'sequence', 'practice_group')


class GuidedPracticeGroupType(DjangoObjectType):
    guided_practices = DjangoFilterConnectionField(
        GuidedPracticeType,
        filterset_class=GuidedPracticeFilterSet
    )
    
    class Meta:
        model = GuidedPraticeGroup
        interfaces = (relay.Node,)
        fields = ('id', 'name', 'slug', 'description', 'speciality', 'level')
        filter_fields = {
            'level__slug': ['exact'],
            'speciality': ['exact']
        }

    def resolve_guided_practices(self, info, **kwargs):
        print(self.name, 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx')
        return GuidedPractice.objects.filter(practice_group=self)


class UserGuidedPracticeAttemptType(DjangoObjectType):
    class Meta:
        model = UserGuidedPracticeAttempt
        interfaces = (relay.Node,)
        fields = ('id', 'user', 'guided_group', 'score')