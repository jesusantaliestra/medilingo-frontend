from django.db import models
from django_extensions.db.fields import AutoSlugField
from user import LanguageChoices
from user.models import User
from practice.models import Level, Speciality

class GuidedPraticeGroup(models.Model):
    """Guided practice group model"""
    name = models.CharField(max_length=200, verbose_name="Group Name")
    slug = AutoSlugField(populate_from='name', unique=True, verbose_name="Slug")
    description = models.TextField(verbose_name="Description")
    speciality = models.ForeignKey(Speciality, on_delete=models.CASCADE, verbose_name="Medical Speciality", related_name='guided_practice_groups', null=True, blank=True)
    level = models.ForeignKey(Level, on_delete=models.CASCADE, verbose_name="Level", related_name='guided_practice_groups')
    language = models.CharField(max_length=3, choices=LanguageChoices, default=LanguageChoices.ENGLISH)



    def __str__(self):
        return f"{self.name} - {self.speciality.name} - {self.language}"

    class Meta:
        verbose_name = "Guided Practice Group"
        verbose_name_plural = "Guided Practice Groups"
        ordering = ['name']
        # unique_together = ('level', 'speciality')

class GuidedPractice(models.Model):
    """Guided practice model"""
    doctor_message = models.TextField(verbose_name="Doctor Message", default="")
    patient_message = models.TextField(verbose_name="Patient Message", default="")
    sequence = models.IntegerField(verbose_name="Sequence", default=0)
    practice_group = models.ForeignKey(GuidedPraticeGroup, on_delete=models.CASCADE, verbose_name="Practice Group")

    def __str__(self):
        return f"{self.doctor_message[:50]}... - {self.practice_group.language}"

    class Meta:
        verbose_name = "Guided Practice"
        verbose_name_plural = "Guided Practices"
        ordering = ['sequence']



class UserGuidedPracticeAttempt(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="User", related_name='user_guided_practice')
    guided_group = models.ForeignKey(GuidedPraticeGroup, on_delete=models.CASCADE, verbose_name="Vocabulary", related_name='guided_group')
    score = models.IntegerField(default=0, verbose_name="Score")
    
    class Meta:
        unique_together = ('user', 'guided_group')
        verbose_name = "User Guided Practice Attempt"
        verbose_name_plural = "User Guided Practice Attempts"

    def __str__(self):
        return f"{self.user.username} - {self.guided_group.name}"