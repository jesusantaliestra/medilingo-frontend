import graphene
from graphene_django.filter import DjangoFilterConnectionField
from .models import GuidedPraticeGroup, GuidedPractice, Level
from .types import GuidedPracticeType, GuidedPracticeGroupType
from .filters import GuidedPracticeFilterSet, GuidedPracticeGroupFilterSet
from .utils import generate_guided_practice_content

class GuidedPracticeQuery(graphene.ObjectType):
    guided_practice_groups = DjangoFilterConnectionField(
        GuidedPracticeGroupType,
        filterset_class=GuidedPracticeGroupFilterSet
    )
    guided_practice_group = graphene.Field(GuidedPracticeGroupType, level_slug=graphene.String())
    guided_practices = DjangoFilterConnectionField(
        GuidedPracticeType,
        filterset_class=GuidedPracticeFilterSet,
        group_slug=graphene.String()
    )

    def resolve_guided_practice_groups(self, info, **kwargs):
        # Get the authenticated user
        user = info.context.user
        if not user.is_authenticated:
            return GuidedPraticeGroup.objects.none()
        
        # Get the user's speciality
        user_speciality = user.speciality
        if not user_speciality:
            return GuidedPraticeGroup.objects.none()
        
        # Start with the base queryset filtered by user's speciality
        return GuidedPraticeGroup.objects.filter(speciality=user_speciality)

    def resolve_guided_practice_group(self, info, level_slug):
        user = info.context.user
        if not user.is_authenticated:
            return None
        
        try:
            speciality = user.speciality
            if not speciality:
                return None
            
            # Get the level instance
            level = Level.objects.get(slug=level_slug)
            
            # Check how many practice groups exist for this combination
            existing_groups = GuidedPraticeGroup.objects.filter(
                level=level,
                speciality=speciality,
                language=user.language_to_learn
            )
            
            # If we have less than 3 groups, generate new ones
            if existing_groups.count() < 3:
                # Generate new practice groups until we have at least 3
                groups_to_generate = 3 - existing_groups.count()
                for _ in range(groups_to_generate):
                    generate_guided_practice_content(
                        level=level,
                        language=user.language_to_learn,
                        speciality=speciality,
                        n_conversations=5
                    )
            
            # Now get the next available practice group for the user
            return GuidedPraticeGroup.objects.filter(
                level__slug=level_slug,
                speciality=speciality,
                language=user.language_to_learn
            ).exclude(
                guided_group__user=user
            ).first()
            
        except (GuidedPraticeGroup.DoesNotExist, Level.DoesNotExist):
            return None

    def resolve_guided_practices(self, info, group_slug, **kwargs):
        user = info.context.user
        if not user.is_authenticated:
            return GuidedPractice.objects.none()
        
        try:
            group = GuidedPraticeGroup.objects.get(slug=group_slug, speciality=user.speciality)
            return GuidedPractice.objects.filter(practice_group=group)
        except GuidedPraticeGroup.DoesNotExist:
            return GuidedPractice.objects.none() 