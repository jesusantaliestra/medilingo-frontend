from django.contrib import admin
from .models import GuidedPraticeGroup, GuidedPractice, UserGuidedPracticeAttempt

@admin.register(GuidedPraticeGroup)
class GuidedPraticeGroupAdmin(admin.ModelAdmin):
    list_display = ('name', 'speciality', 'level', 'slug')
    list_filter = ('speciality', 'level')
    search_fields = ('name', 'description')

@admin.register(GuidedPractice)
class GuidedPracticeAdmin(admin.ModelAdmin):
    list_display = ('doctor_message', 'patient_message', 'sequence', 'practice_group')
    list_filter = ('practice_group',)
    search_fields = ('doctor_message', 'patient_message')

@admin.register(UserGuidedPracticeAttempt)
class UserGuidedPracticeAttemptAdmin(admin.ModelAdmin):
    list_display = ('user', 'guided_group', 'score')
    list_filter = ('guided_group',)
    search_fields = ('user__username', 'guided_group__name')
