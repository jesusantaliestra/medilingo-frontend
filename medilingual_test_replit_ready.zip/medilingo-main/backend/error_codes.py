from django.db import models
from django.utils.translation import gettext_lazy as _

class ErrorCodes(models.TextChoices):
    UNAUTHORIZED = "AUTH_001", _("You are not authorized to access this resource")
    INVALID_SUBSCRIPTION = "SUB_001", _("You need to have a valid subscription to access this resource")
    NO_CREDITS = "SUB_002", _("You have no remaining credits for this operation")
    SUBSCRIPTION_EXPIRED = "SUB_003", _("Your subscription has expired")
    INVALID_OET_SUBSCRIPTION = "SUB_004", _("You need to have a valid OET subscription to access this resource")

    @property
    def message(self):
        return str(self.label)

    @property
    def code(self):
        return self.value