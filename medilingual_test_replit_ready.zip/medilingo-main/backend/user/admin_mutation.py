import graphene
from graphene_django.types import DjangoObjectType
from django.contrib.auth import get_user_model
from graphql import GraphQLError

from user.types import UserType



class CreateUser(graphene.Mutation):
    class Arguments:
        first_name = graphene.String(required=True)
        last_name = graphene.String(required=True)
        username = graphene.String(required=True)
        email = graphene.String(required=True)
        password = graphene.String(required=True)

    user = graphene.Field(UserType)

    def mutate(self, info, first_name, last_name, username, email, password):
        User = get_user_model()

        user = User(
            first_name=first_name,
            last_name=last_name,
            username=username,
            email=email,
            is_superuser=False,
            is_staff=False
        )
        user.set_password(password)
        user.save()
        return CreateUser(user=user)

class UpdateUser(graphene.Mutation):
    class Arguments:
        id = graphene.ID(required=True)
        first_name = graphene.String()
        last_name = graphene.String()
        email = graphene.String()

    user = graphene.Field(UserType)

    def mutate(self, info, id, first_name=None, last_name=None, email=None):
        User = get_user_model()
        user = User.objects.filter(id=id).first()
        if not user:
            raise GraphQLError("User not found.")

        if first_name:
            user.first_name = first_name
        if last_name:
            user.last_name = last_name
        if email:
            user.email = email
        
        user.save()
        return UpdateUser(user=user)


class UserAdminMutation(graphene.ObjectType):
    create_user = CreateUser.Field()
    update_user = UpdateUser.Field()

