from django.db import models
from django.contrib.auth.models import AbstractUser, AbstractBaseUser
import uuid
from datetime import datetime
from oet import OETProfession
from practice.models import Category, Speciality


class User(AbstractUser):
    """Custom user model with role-based permissions"""
    # Additional fields from signup form
    speciality = models.ForeignKey(Speciality, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Medical Speciality")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Medical Category")
    language = models.CharField(max_length=10, blank=True, null=True) # My language / user native language
    language_to_learn = models.CharField(max_length=10, default='en')
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    profession = models.CharField(max_length=50, choices=OETProfession, default=OETProfession.MEDICINE.value)
    subscription_valid = models.BooleanField(default=False)
    has_available_credits = models.BooleanField(default=False)
    has_valid_oet_subscription = models.BooleanField(default=False)

    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip()

   