from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from user.models import User

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    # Customize the list display
    list_display = ('username', 'full_name', 'email', 'speciality', 'language', 'language_to_learn' ,'is_staff', 'is_active', 'date_joined')
    list_filter = ('is_staff', 'is_active', 'speciality', 'language', 'date_joined')
    search_fields = ('username', 'first_name', 'last_name', 'email', 'speciality__name')
    date_hierarchy = 'date_joined'
    
    # Customize the add/change forms
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal Info', {
            'fields': ('first_name', 'last_name', 'email', 'speciality', 'language', 'phone_number', 'subscription_valid', 'has_available_credits', 'has_valid_oet_subscription',),
            'classes': ('wide',)
        }),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'user_permissions'),
            'classes': ('collapse',)
        }),
        ('Important Dates', {
            'fields': ('last_login', 'date_joined'),
            'classes': ('collapse',)
        }),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'password1', 'password2', 'speciality', 'language'),
        }),
    )
    
    # Custom ordering
    ordering = ('-date_joined',)
    
    def full_name(self, obj):
        return obj.full_name()
    full_name.short_description = 'Full Name'
    full_name.admin_order_field = 'first_name'  # Allows sorting

    def get_readonly_fields(self, request, obj=None):
        if obj:  # editing an existing object
            return ('date_joined',)
        return ()
