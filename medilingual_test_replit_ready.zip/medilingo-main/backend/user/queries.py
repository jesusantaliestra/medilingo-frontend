import graphene
from graphene_django.filter import DjangoFilterConnectionField
from graphql import GraphQLError
from user.types import UserType
from user.models import User

class UserAdminQuery(graphene.ObjectType):
    users = DjangoFilterConnectionField(UserType)
    user = graphene.Field(UserType, id=graphene.ID(required=True))
    me = graphene.Field(UserType)

    def resolve_user(self, info, id, **kwargs):
        return User.objects.get(id=id)

    def resolve_me(self, info):
        if not info.context.user.is_authenticated:
            return None
        return info.context.user
