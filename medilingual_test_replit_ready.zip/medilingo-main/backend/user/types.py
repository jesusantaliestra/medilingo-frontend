import graphene
from graphene_django import DjangoObjectType
from practice.types import SpecialityType
from user.models import User


class UserType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    speciality = graphene.Field(SpecialityType)
    profession = graphene.String()
    
    class Meta:
        model = User
        interfaces = (graphene.relay.Node,)
        exclude = ('password', 'is_superuser', 'is_staff', 'is_active', 'groups', 'user_permissions')
        filter_fields = {
            'username': ['exact', 'icontains'],
            'email': ['exact', 'icontains'],
        }