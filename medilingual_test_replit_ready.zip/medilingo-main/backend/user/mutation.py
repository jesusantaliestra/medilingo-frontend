import graphene
from django.contrib.auth import authenticate, get_user_model
from rest_framework import serializers
from django.contrib.auth.models import Permission

from django.conf import settings
from graphql import GraphQLError

from practice.models import Speciality
from user.models import User
from user.jwt_manager import JWTManager

class JwtBasicUserSerializer(serializers.ModelSerializer):
    languageToLearn = serializers.CharField(source='language_to_learn')

    class Meta:
        model = User
        fields = ('id', 'username', 'full_name', 'language', 'languageToLearn', 'profession')

class AdminTokenType(graphene.ObjectType):
    access = graphene.String()
    refresh = graphene.String()
    expiresIn = graphene.Int()
    refreshExpiresIn = graphene.Int()

class AdminLoginUserType(graphene.ObjectType):
    id = graphene.ID()
    email = graphene.String()
    username = graphene.String()
    firstName = graphene.String()
    lastName = graphene.String()
    full_name = graphene.String()
    language = graphene.String()
    languageToLearn = graphene.String()
    profession = graphene.String()

class AdminLoginResponse(graphene.ObjectType):
    user = graphene.Field(AdminLoginUserType)
    token = graphene.Field(AdminTokenType)

class AdminLoginMutation(graphene.Mutation):
    class Arguments:
        email = graphene.String(required=True)
        password = graphene.String(required=True)

    login = graphene.Field(AdminLoginResponse)

    def mutate(self, info, email, password):
        jwt_manager = JWTManager()

        user = authenticate(email=email, password=password)
        print(user)

        if user:
            if not user.is_active:
                raise Exception("User is not active.")

            access_token = jwt_manager.generate_access_token(user)
            refresh_token = jwt_manager.generate_refresh_token(user)

            user_data = JwtBasicUserSerializer(user).data
            user_data['language'] = user.language  # Add language to user data

            response = AdminLoginResponse(
                user=AdminLoginUserType(**user_data),
                token=AdminTokenType(
                    access=access_token,
                    refresh=refresh_token,
                    expiresIn=jwt_manager.access_token_expiration_seconds,
                    refreshExpiresIn=jwt_manager.refresh_token_expiration_seconds
                )
            )

            return AdminLoginMutation(login=response)
        else:
            raise Exception("Invalid credentials")

class AdminTokenRefreshMutation(graphene.Mutation):
    class Arguments:
        refresh_token = graphene.String(required=True)

    token = graphene.Field(AdminTokenType)

    def mutate(self, info, refresh_token):
        jwt_manager = JWTManager()
        user = jwt_manager.verify_jwt_token(refresh_token)

        if user:
            access_token = jwt_manager.generate_access_token(user)
            refresh_token = jwt_manager.generate_refresh_token(user)

            return AdminTokenRefreshMutation(
                token=AdminTokenType(
                    access=access_token,
                    refresh=refresh_token,
                    expiresIn=jwt_manager.access_token_expiration_seconds,
                    refreshExpiresIn=jwt_manager.refresh_token_expiration_seconds
                )
            )
        else:
            raise Exception("Invalid refresh token")

class SignupMutation(graphene.Mutation):
    class Arguments:
        email = graphene.String(required=True)
        password = graphene.String(required=True)
        fullName = graphene.String(required=True)
        speciality = graphene.ID(required=True)
        language = graphene.String(required=True)
        languageToLearn = graphene.String(required=True)
        phoneNumber = graphene.String()

    login = graphene.Field(AdminLoginResponse)

    def mutate(self, info, email, password, fullName, speciality, language, languageToLearn, phoneNumber=None):
        jwt_manager = JWTManager()
        User = get_user_model()

        # Check if user already exists
        if User.objects.filter(email=email).exists():
            raise GraphQLError("User with this email already exists")

        # Split full name into first and last name
        name_parts = fullName.split(' ', 1)
        first_name = name_parts[0]
        last_name = name_parts[1] if len(name_parts) > 1 else ""

        speciality_instance = Speciality.objects.get(id=speciality)
        category = speciality_instance.category

        # Create new user
        user = User(
            email=email,
            username=email,  # Using email as username
            first_name=first_name,
            last_name=last_name,
            is_active=True,
            speciality_id=speciality,
            category=category,
            language=language,
            language_to_learn=languageToLearn,
            phone_number=phoneNumber
        )
        user.set_password(password)
        user.save()

        # Generate tokens
        access_token = jwt_manager.generate_access_token(user)
        refresh_token = jwt_manager.generate_refresh_token(user)

        user_data = JwtBasicUserSerializer(user).data

        response = AdminLoginResponse(
            user=AdminLoginUserType(**user_data),
            token=AdminTokenType(
                access=access_token,
                refresh=refresh_token,
                expiresIn=jwt_manager.access_token_expiration_seconds,
                refreshExpiresIn=jwt_manager.refresh_token_expiration_seconds
            )
        )

        return SignupMutation(login=response)

class UpdateUserLanguage(graphene.Mutation):
    class Arguments:
        language = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, language):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to update your language")

        try:
            user = info.context.user
            user.language = language
            user.save()
            return UpdateUserLanguage(success=True, message="Language updated successfully")
        except Exception as e:
            raise GraphQLError(str(e))

class UpdateUserLanguageToLearn(graphene.Mutation):
    class Arguments:
        languageToLearn = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, languageToLearn):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to update your language to learn")

        try:
            user = info.context.user
            user.language_to_learn = languageToLearn
            user.save()
            return UpdateUserLanguageToLearn(success=True, message="Language to learn updated successfully")
        except Exception as e:
            raise GraphQLError(str(e))

class UpdatePassword(graphene.Mutation):
    class Arguments:
        currentPassword = graphene.String(required=True)
        newPassword = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, currentPassword, newPassword):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to update your password")

        user = info.context.user
        
        # Verify current password
        if not user.check_password(currentPassword):
            return UpdatePassword(success=False, message="Current password is incorrect")
        
        try:
            # Set new password
            user.set_password(newPassword)
            user.save()
            return UpdatePassword(success=True, message="Password updated successfully")
        except Exception as e:
            raise GraphQLError(str(e))

class UpdateUserSpecialty(graphene.Mutation):
    class Arguments:
        specialty = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, specialty):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to update your specialty")

        try:
            from practice.models import Speciality
            
            # Get the specialty by slug
            specialty_obj = Speciality.objects.filter(slug=specialty).first()
            if not specialty_obj:
                return UpdateUserSpecialty(success=False, message="Specialty not found")
            
            user = info.context.user
            user.speciality = specialty_obj
            user.save()
            return UpdateUserSpecialty(success=True, message="Specialty updated successfully")
        except Exception as e:
            raise GraphQLError(str(e))

class UpdateUserProfession(graphene.Mutation):
    class Arguments:
        profession = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, profession):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to update your profession")

        try:
            user = info.context.user
            user.profession = profession.lower()  # Convert to lowercase before saving
            user.save()
            return UpdateUserProfession(success=True, message="Profession updated successfully")
        except Exception as e:
            raise GraphQLError(str(e))

class UpdateUserCategory(graphene.Mutation):
    class Arguments:
        category = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()

    def mutate(self, info, category):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to update your category")

        try:
            from practice.models import Category
            
            # Get the category by slug
            category_obj = Category.objects.filter(slug=category).first()
            if not category_obj:
                return UpdateUserCategory(success=False, message="Category not found")
            
            user = info.context.user
            user.category = category_obj
            user.save()
            return UpdateUserCategory(success=True, message="Category updated successfully")
        except Exception as e:
            raise GraphQLError(str(e))

class UserMutation(graphene.ObjectType):
    login = AdminLoginMutation.Field()
    signup = SignupMutation.Field()
    refresh_token = AdminTokenRefreshMutation.Field()
    update_user_language = UpdateUserLanguage.Field()
    update_user_language_to_learn = UpdateUserLanguageToLearn.Field()
    update_password = UpdatePassword.Field()
    update_user_specialty = UpdateUserSpecialty.Field()
    update_user_profession = UpdateUserProfession.Field()
    update_user_category = UpdateUserCategory.Field()

    