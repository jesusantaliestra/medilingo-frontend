from django.db import models


class LanguageChoices(models.TextChoices):
    ENGLISH = 'en', 'English'
    SPANISH = 'es', 'Spanish'
    FRENCH = 'fr', 'French'
    GERMAN = 'de', 'German'
    PORTUGUESE = 'pt', 'Portuguese'