from django.db import models
from user import LanguageChoices
from user.models import User
from practice.models import Level, Speciality

class Vocabulary(models.Model):
    """Vocabulary model"""
    term = models.CharField(max_length=200, verbose_name="Medical Term")
    definition = models.TextField(verbose_name="Definition")
    speciality = models.ForeignKey(Speciality, on_delete=models.CASCADE, verbose_name="Medical Speciality", related_name='vocabulary_items')
    level = models.ForeignKey(Level, on_delete=models.CASCADE, verbose_name="Level", related_name='vocabulary_items')
    language = models.CharField(max_length=3, choices=LanguageChoices, default=LanguageChoices.ENGLISH)

    def __str__(self):
        return f"{self.term} - {self.speciality.name} - {self.language}"

    class Meta:
        verbose_name = "Vocabulary"
        verbose_name_plural = "Vocabulary Words"
        ordering = ['term']



class UserVocabularyAttempt(models.Model):
    """User Vocabulary model"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="User", related_name='user_vocabulary')
    vocabulary = models.ForeignKey(Vocabulary, on_delete=models.CASCADE, verbose_name="Vocabulary", related_name='user_vocabulary')
    score = models.IntegerField(default=0, verbose_name="Score")
    completed = models.BooleanField(default=False, verbose_name="Completed")
    
    class Meta:
        unique_together = ('user', 'vocabulary')
        verbose_name = "User Vocabulary Attempt"
        verbose_name_plural = "User Vocabulary Attempts"

    def __str__(self):
        return f"{self.user.username} - {self.vocabulary.term}"