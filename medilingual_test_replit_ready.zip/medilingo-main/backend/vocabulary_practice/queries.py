import graphene
from graphene_django.filter import DjangoFilterConnectionField

from vocabulary_practice.utils import generate_vocabulary_terms
from practice.models import Level, Speciality
from .types import VocabularyType, VocabularyStatisticsType, VocabularyWithStatisticsType
from .models import Vocabulary, UserVocabularyAttempt

class VocabularyPracticeQuery(graphene.ObjectType):
    vocabulary = DjangoFilterConnectionField(VocabularyType)  # For backward compatibility
    vocabulary_items = DjangoFilterConnectionField(VocabularyType)
    vocabulary_item = graphene.Field(VocabularyType, id=graphene.ID())
    available_vocabulary_items = graphene.Field(
        VocabularyWithStatisticsType,
        level_slug=graphene.String(),
    )

    def resolve_vocabulary(self, info, **kwargs):
        # Get the authenticated user
        user = info.context.user
        if not user.is_authenticated:
            return Vocabulary.objects.none()
        
        # Get the user's speciality
        user_speciality = user.speciality
        if not user_speciality:
            return Vocabulary.objects.none()
        
        # Start with the base queryset filtered by user's speciality
        return Vocabulary.objects.filter(speciality=user_speciality)

    def resolve_vocabulary_items(self, info, **kwargs):
        # Get the authenticated user
        user = info.context.user
        if not user.is_authenticated:
            return Vocabulary.objects.none()
        
        # Get the user's speciality
        user_speciality = user.speciality
        if not user_speciality:
            return Vocabulary.objects.none()
        
        # Start with the base queryset filtered by user's speciality
        return Vocabulary.objects.filter(speciality=user_speciality)

    def resolve_vocabulary_item(self, info, id):
        try:
            return Vocabulary.objects.get(id=id)
        except Vocabulary.DoesNotExist:
            return None 
        
    def resolve_available_vocabulary_items(self, info, level_slug):
        expected_count = 100
        user = info.context.user
        if not user.is_authenticated:
            return None
            
        if not user.speciality:
            return None
            
        try:
            level = Level.objects.get(slug=level_slug)
        except Level.DoesNotExist:
            return None
       
        # Get all vocabulary items for this speciality and level
        vocabulary_queryset = Vocabulary.objects.filter(
            speciality=user.speciality,
            level=level,
            language=user.language_to_learn
        )
        
        # Get total count
        total_count = vocabulary_queryset.count()

        if total_count < expected_count:
            # Generate more vocabulary items
            generate_vocabulary_terms(level, user.language_to_learn, user.speciality,  10)
  
        
        # Calculate completed vocabulary items
        completed_vocabulary_count = 0
        completed_vocabulary_ids = []
        
        if user.is_authenticated:
            completed_vocabulary = UserVocabularyAttempt.objects.filter(
                user=user,
                vocabulary__in=vocabulary_queryset,
                completed=True
            )
            completed_vocabulary_ids = list(completed_vocabulary.values_list('vocabulary__id', flat=True))
            completed_vocabulary_count = len(completed_vocabulary_ids)
            
        # Calculate remaining count and completion percentage
        remaining_count = total_count - completed_vocabulary_count
        completion_percentage = 0
        if total_count > 0:
            completion_percentage = (completed_vocabulary_count / total_count) * 100
            
        # Exclude vocabulary items that the user has already mastered (score >= 75%)
        if completed_vocabulary_ids:
            vocabulary_queryset = vocabulary_queryset.exclude(
                id__in=completed_vocabulary_ids
            )
        
        next_vocabulary_item = vocabulary_queryset.first()
        
        # Create statistics object
        statistics = VocabularyStatisticsType(
            completedCount=completed_vocabulary_count,
            totalCount=total_count,
            remainingCount=remaining_count,
            completionPercentage=completion_percentage
        )
        
        # Return combined result
        return VocabularyWithStatisticsType(
            vocabularyItem=next_vocabulary_item,
            statistics=statistics
        )
    