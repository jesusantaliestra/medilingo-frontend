import graphene
from graphene_django import DjangoObjectType
from graphene import relay
from .models import Vocabulary

class VocabularyType(DjangoObjectType):
    class Meta:
        model = Vocabulary
        interfaces = (relay.Node,)
        fields = ('id', 'term', 'definition', 'speciality', 'level')
        filter_fields = {
            'level__slug': ['exact'],
            'speciality': ['exact']
        } 

class VocabularyStatisticsType(graphene.ObjectType):
    completedCount = graphene.Int(description="Number of vocabulary items completed by the user")
    totalCount = graphene.Int(description="Total number of vocabulary items for the level")
    remainingCount = graphene.Int(description="Number of vocabulary items remaining to complete")
    completionPercentage = graphene.Float(description="Percentage of vocabulary items completed")

class VocabularyWithStatisticsType(graphene.ObjectType):
    vocabularyItem = graphene.Field(VocabularyType, description="The next vocabulary item to practice")
    statistics = graphene.Field(VocabularyStatisticsType, description="Statistics about vocabulary completion") 