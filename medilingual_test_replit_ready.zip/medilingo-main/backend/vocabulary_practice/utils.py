from typing import List
from openai import OpenAI
from django.conf import settings

from practice.language_code import get_language_native_name_by_code
from practice.models import Level, Speciality
from .models import Vocabulary

def generate_vocabulary_terms(
    level: 'Level',
    language: str,
    speciality: 'Speciality',
    n: int
) -> List[Vocabulary]:
    """
    Generate medical vocabulary terms using OpenAI API.
    
    Args:
        level: Level instance for the vocabulary terms
        language: Language code (e.g., 'en', 'es')
        speciality: Speciality instance for the vocabulary terms
        n: Number of terms to generate
        
    Returns:
        List of created Vocabulary instances
    """
    # Initialize OpenAI client
    client = OpenAI(api_key=settings.OPENAI_API_KEY)

    phrase_or_vocabulary = 'most frequenty asked medical questions asked by doctors/{speciality.category.name} to patients' if level.slug == 'special-vocabulary' else 'vocabulary term'
    
    # Create prompt for OpenAI
    prompt = f"""Generate {n} medical {phrase_or_vocabulary} and their definitions for {speciality.name} speciality.
    IMPORTANT: All {phrase_or_vocabulary} and definitions MUST be in  {get_language_native_name_by_code(language)} language only.
    The {phrase_or_vocabulary} should be appropriate for {speciality.category.name}.
    
    For example, if {language} is {get_language_native_name_by_code(language)}, generate German terms like:
    [
        {{"term": "An {phrase_or_vocabulary} in {get_language_native_name_by_code(language)}", "definition": "A definition of the word in {get_language_native_name_by_code(language)}"}},
        ...
    ]
    
    Format each term and definition as a JSON object with 'term' and 'definition' fields.
    Return the response as a JSON array of these objects.
    """
    
    try:
        # Call OpenAI API using new format
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a medical education expert."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=1000
        )
        
        # Parse the response
        import json
        content = response.choices[0].message.content
        terms_data = json.loads(content)
        
        # Create Vocabulary instances
        vocabulary_items = []
        for term_data in terms_data:
            vocabulary = Vocabulary.objects.create(
                term=term_data['term'],
                definition=term_data['definition'],
                speciality=speciality,
                level=level,
                language=language
            )
            vocabulary_items.append(vocabulary)
            
        return vocabulary_items
        
    except Exception as e:
        raise Exception(f"Error generating vocabulary terms: {str(e)}") 