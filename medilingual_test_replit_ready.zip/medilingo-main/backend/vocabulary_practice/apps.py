from django.apps import AppConfig


class VocabularyPracticeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vocabulary_practice'

    def ready(self):
        pass
