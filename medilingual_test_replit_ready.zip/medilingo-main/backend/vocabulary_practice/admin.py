from django.contrib import admin
from .models import Vocabulary, UserVocabularyAttempt

@admin.register(Vocabulary)
class VocabularyAdmin(admin.ModelAdmin):
    list_display = ('term', 'speciality', 'level', 'get_definition_preview')
    list_filter = ('speciality', 'level')
    search_fields = ('term', 'definition')
    fieldsets = (
        ('Vocabulary Information', {
            'fields': ('term', 'definition', 'language')
        }),
        ('Relations', {
            'fields': ('speciality', 'level')
        })
    )

    def get_definition_preview(self, obj):
        return obj.definition[:100] + '...' if len(obj.definition) > 100 else obj.definition
    get_definition_preview.short_description = 'Definition Preview'



admin.site.register(UserVocabularyAttempt)