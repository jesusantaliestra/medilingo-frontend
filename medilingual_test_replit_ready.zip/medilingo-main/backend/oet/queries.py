import graphene
from graphene_django import DjangoConnectionField, DjangoObjectType
from graphql import GraphQLError

from oet.generate_reading_test_part_c import create_part_c_reading_test
from oet.generate_reading_test_part_b import create_part_b_reading_test
from oet.generate_reading_test_part_a import generate_fill_the_gap_content, create_fill_the_gap_reading_test
from oet.generate_reading_test import create_reading_test
from oet.generate_listening_test import create_listening_test
from oet.generate_speaking_test import create_speaking_test
from oet.generate_writing_test import create_writing_test
from .models import ReadingSection, ReadingQuestion, ReadingTry, SpeakingTry, WritingSection, SpeakingSection, ListeningSection, ListeningQuestion, ListeningTry, WritingTry, AudioExcerpt
from .types import ReadingSectionProgressionType, ReadingSectionType, ReadingQuestionType, SpeakingTryType, WritingSectionType, SpeakingSectionType, ListeningSectionType, ListeningQuestionType, ReadingTryType, ListeningTryType, ListeningSectionProgressionType, AudioExcerptType
import json



class ReadingQuery(graphene.ObjectType):
    # Get all reading sections
    all_reading_sections = graphene.List(ReadingSectionType)
    
    # Get reading section by ID
    reading_section = graphene.Field(ReadingSectionType, id=graphene.ID())
    
    # Get reading section by part
    reading_sections_by_part = graphene.List(ReadingSectionType, part=graphene.String())
    
    # Get published reading sections
    published_reading_sections = graphene.List(ReadingSectionType)

    # Get reading test questions for user progress
    reading_test_section = graphene.Field(
        ReadingSectionType,
        part=graphene.String(required=True)
    )

    # Get reading test results
    reading_test_results = graphene.Field(
        ReadingTryType,
        tryId=graphene.ID(required=True)
    )

    # Get latest reading test results for user
    latest_reading_results = graphene.Field(ReadingTryType)

    reading_questions = DjangoConnectionField(ReadingQuestionType)

    # Get reading section progression
    reading_section_progression = graphene.Field(ReadingSectionProgressionType)

    def resolve_reading_section_progression(self, info):
        user = info.context.user
        if not user.is_authenticated:
            return None

        # Check completion status for each part
        part_a_completed = ReadingTry.objects.filter(
            user=user,
            reading_section__part='A',
            has_submitted=True
        ).exists()

        part_b_completed = ReadingTry.objects.filter(
            user=user,
            reading_section__part='B',
            has_submitted=True
        ).exists()

        part_c_completed = ReadingTry.objects.filter(
            user=user,
            reading_section__part='C',
            has_submitted=True
        ).exists()

        return ReadingSectionProgressionType(
            a=part_a_completed,
            b=part_b_completed,
            c=part_c_completed
        )

    def resolve_all_reading_sections(self, info):
        return ReadingSection.objects.filter(profession=info.context.user.profession)

    def resolve_reading_section(self, info, id):
        return ReadingSection.objects.get(pk=id, profession=info.context.user.profession)

    def resolve_reading_sections_by_part(self, info, part):
        return ReadingSection.objects.filter(part=part, profession=info.context.user.profession)

    def resolve_published_reading_sections(self, info):
        return ReadingSection.objects.filter(is_published=True, profession=info.context.user.profession)

    def resolve_reading_test_section(self, info, part: str) -> ReadingSectionType:
        part = part.upper()
        try:
            section = ReadingSection.objects.prefetch_related('text_contents', 'text_contents__questions').get(part=part, profession=info.context.user.profession)
        except ReadingSection.DoesNotExist:
            if part == 'A':
                section = create_fill_the_gap_reading_test(part, info.context.user.profession)
            elif part == 'B':
                section = create_part_b_reading_test(part, info.context.user.profession)
            elif part == 'C':
                section = create_part_c_reading_test(part, info.context.user.profession)
            else:
                section = create_reading_test(part, info.context.user.profession)
        
        return section

    def resolve_reading_test_results(self, info, tryId: str):
        try:
            reading_try = ReadingTry.objects.get(id=tryId, user=info.context.user)
            return reading_try
        except ReadingTry.DoesNotExist:
            return None

    def resolve_latest_reading_results(self, info):
        try:
            return ReadingTry.objects.filter(user=info.context.user).latest('created_at')
        except ReadingTry.DoesNotExist:
            return None
           
    def resolve_reading_questions(self, info, part: str):
        return ReadingQuestion.objects.filter(part=part)

class WritingQuery(graphene.ObjectType):
    # Get writing test section for user progress
    writing_test_section = graphene.Field(
        WritingSectionType,
    )

    # Get writing test results
    get_writing_section = graphene.Field(
        graphene.JSONString,
        progress_id=graphene.ID(required=True)
    )

    def resolve_writing_test_section(self, info) -> WritingSectionType:
        try:
            print("Starting writing test section resolution")
            
            # Check if user has profession set
            if not info.context.user.profession:
                print("User has no profession set")
                return None
                
            print(f"User profession: {info.context.user.profession}")
            
            # Try to get existing section
            section = WritingSection.objects.filter(is_published=True, profession=info.context.user.profession).first()
            print(f"Existing section found: {section is not None}")
            
            if not section:
                print("No existing section found, creating new section")
                # Generate new section if none exists
                section = create_writing_test(info.context.user.profession)
                print(f"New section created: {section is not None}")
            
            if not section:
                print("Section creation failed")
                return None
                
            print(f"Creating/getting user progress for section: {section.id}")
            # Get or create user progress
            user_progress, created = WritingTry.objects.get_or_create(
                user=info.context.user,
                writing_section=section
            )
            print(f"User progress created: {created}")
            
            # Verify the section is accessible
            if not user_progress.writing_section:
                print("Writing section not found in user progress")
                return None
                
            return user_progress.writing_section
            
        except Exception as e:
            print(f"Error resolving writing test section: {str(e)}")
            import traceback
            print(traceback.format_exc())
            return None

    def resolve_get_writing_section(self, info, progress_id: str):
        try:
            # Get user progress
            user_progress = WritingTry.objects.get(id=progress_id, user=info.context.user)
            
            # Get writing section from progress
            writing_section = user_progress.writing_section
            
            if not writing_section:
                return None
            
            # Get writing progress
            writing_progress = user_progress.result or {}
            
            # Return combined data
            return {
                'section': {
                    'id': str(writing_section.id),
                    'title': writing_section.title,
                    'description': writing_section.description,
                    'case_notes': writing_section.case_notes,
                    'task_instructions': writing_section.task_instructions,
                    'time_limit_minutes': writing_section.time_limit_minutes,
                    'word_limit': writing_section.word_limit,
                    'profession': writing_section.profession,
                    'letter_type': writing_section.letter_type
                },
                'submission': {
                    'letter_content': writing_progress.get('letter_content', ''),
                    'completed_at': writing_progress.get('completed_at', ''),
                    'section_id': str(writing_section.id),
                    'score': writing_progress.get('score', 0),
                    'band': writing_progress.get('band', ''),
                    'criteria_scores': writing_progress.get('criteria_scores', {
                        'task_fulfillment': 0,
                        'grammar': 0,
                        'vocabulary': 0,
                        'coherence': 0,
                        'format': 0
                    }),
                    'feedback': writing_progress.get('feedback', [])
                }
            }
            
        except WritingTry.DoesNotExist:
            return None

class SpeakingQuery(graphene.ObjectType):
    # Get speaking test section for user progress
    speaking_test_section = graphene.Field(
        SpeakingSectionType,
        role_sequence=graphene.String(required=True)
    )

    # Get speaking test results
    speaking_test_results = graphene.Field(
        SpeakingTryType,
        role_sequence=graphene.String(required=True)
    )

    def resolve_speaking_test_section(self, info, role_sequence):
        try:
            # Try to get existing section
            section = SpeakingSection.objects.filter(
                profession=info.context.user.profession,
                role_sequence=role_sequence.lower()
            ).first()
            
            if not section:
                # print('generating new section==================================================')
                # Generate new section if none exists (default to 'first')
                section = create_speaking_test(info.context.user.profession, role_sequence)
            
            # Get or create user progress
            user_progress, created = SpeakingTry.objects.get_or_create(
                user=info.context.user,
                speaking_section=section
            )
            
            return section
            
        except Exception as e:
            print(f"Error resolving speaking test section: {str(e)}")
            return None

    def resolve_speaking_test_results(self, info, role_sequence: str):
        try:
            speaking_try = SpeakingTry.objects.filter(
                speaking_section__role_sequence=role_sequence,
                speaking_section__profession=info.context.user.profession,
                user=info.context.user
            ).order_by('-created_at').first()
            return speaking_try
        except Exception as e:
            print(f"Error resolving speaking test results: {str(e)}")
            return None

class ListeningQuery(graphene.ObjectType):
    # Get all listening sections
    all_listening_sections = graphene.List(ListeningSectionType)
    
    # Get listening section by ID
    listening_section = graphene.Field(ListeningSectionType, id=graphene.ID())
    
    # Get listening section by part
    listening_sections_by_part = graphene.List(ListeningSectionType, part=graphene.String())
    
    # Get published listening sections
    published_listening_sections = graphene.List(ListeningSectionType)

    # Get listening test questions for user progress
    listening_test_section = graphene.Field(
        ListeningSectionType,
        part=graphene.String(required=True)
    )

    # Get all audio excerpts for a section
    audio_excerpts_by_section = graphene.List(lambda: AudioExcerptType, section_id=graphene.ID(required=True))

    # Get listening test results
    listening_test_results = graphene.Field(
        ListeningTryType,
        try_id=graphene.ID(required=True)
    )

    # Get latest listening test results for user
    latest_listening_results = graphene.Field(ListeningTryType)

    # Get listening section progression
    listening_section_progression = graphene.Field(ListeningSectionProgressionType)

    def resolve_listening_section_progression(self, info):
        user = info.context.user
        if not user.is_authenticated:
            return None

        # Check completion status for each part
        part_a_completed = ListeningTry.objects.filter(
            user=user,
            listening_section__part='A',
            has_submitted=True
        ).exists()

        part_b_completed = ListeningTry.objects.filter(
            user=user,
            listening_section__part='B',
            has_submitted=True
        ).exists()

        part_c_completed = ListeningTry.objects.filter(
            user=user,
            listening_section__part='C',
            has_submitted=True
        ).exists()

        return ListeningSectionProgressionType(
            a=part_a_completed,
            b=part_b_completed,
            c=part_c_completed
        )

    def resolve_all_listening_sections(self, info):
        return ListeningSection.objects.filter(profession=info.context.user.profession)

    def resolve_listening_section(self, info, id):
        return ListeningSection.objects.get(pk=id, profession=info.context.user.profession)

    def resolve_listening_sections_by_part(self, info, part):
        return ListeningSection.objects.filter(part=part, profession=info.context.user.profession)

    def resolve_published_listening_sections(self, info):
        return ListeningSection.objects.filter(is_published=True, profession=info.context.user.profession)

    def resolve_listening_test_section(self, info, part: str) -> ListeningSectionType:
        part = part.upper()
        try:
            # Try to get existing section
            try:
                section = ListeningSection.objects.get(part=part, profession=info.context.user.profession)
            except ListeningSection.DoesNotExist:
                # Generate new section if it doesn't exist
                # section = create_listening_test(part, info.context.user.profession)
                raise GraphQLError("Listening section does not exist")
            
            return section
            
        except Exception as e:
            print(f"Error resolving listening test section: {str(e)}")
            return None

    def resolve_audio_excerpts_by_section(self, info, section_id):
        return AudioExcerpt.objects.filter(listening_section_id=section_id)

    def resolve_listening_test_results(self, info, try_id: str):
        try:
            listening_try = ListeningTry.objects.get(id=try_id, user=info.context.user)
            return listening_try
        except ListeningTry.DoesNotExist:
            return None

    def resolve_latest_listening_results(self, info):
        try:
            return ListeningTry.objects.filter(user=info.context.user).latest('created_at')
        except ListeningTry.DoesNotExist:
            return None
