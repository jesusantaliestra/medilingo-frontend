import os
from openai import OpenAI
import json
from .models import ReadingSection, TextContent, ReadingQuestion
from concurrent.futures import ThreadPoolExecutor, as_completed

def generate_reading_part_b_mcq(profession: str, part: str) -> dict:
    """
    Generate a reading passage with 4 MCQ questions (3 options each) for OET Part B.
    """
    prompt = f"""Generate a reading passage for the OET {part} test for {profession} professionals.
The output should include:
1. A title for the passage.
2. A main passage (at least 120 words) that is professional, relevant to healthcare, and contains clinical scenarios or cases related to {profession}.
3. 6 multiple-choice questions (MCQ), each based on the passage. Each question should:
   - Present a question about the passage.
   - Provide exactly 3 answer options (as a list of strings).
   - Clearly indicate the correct answer (must match one of the options).
   - Provide a brief explanation for why that answer is correct in the context of the passage.

Format the response as JSON with the following structure:
{{
    "title": "string",
    "passage": "A passage",
    "questions": [
        {{
            "question_number": int,
            "question_text": "string",
            "options": ["string", "string", "string"],
            "correct_answer": "string",
            "explanation": "string"
        }}
    ]
}}
"""

    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": f"You are an expert OET test content creator for {profession} professionals."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )

    try:
        content = json.loads(response.choices[0].message.content)
        return content
    except json.JSONDecodeError:
        raise Exception("Failed to parse AI generated MCQ content for Part B")

def create_part_b_reading_test(part: str, profession: str, n_text_content: int = 6) -> ReadingSection:
    """
    Create a reading test section with n_text_content passages, each with 4 MCQ questions (3 options each).
    Args:
        part (str): The OET reading test part (should be 'B')
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        n_text_content (int): Number of passages to generate (default 4)
    Returns:
        ReadingSection: The created reading section with MCQ questions
    """
    # Create reading section (no title)
    reading_section = ReadingSection.objects.create(
        part=part,
        profession=profession,
        is_published=True
    )

    # Generate n_text_content passages in parallel
    contents = []
    with ThreadPoolExecutor() as executor:
        futures = [executor.submit(generate_reading_part_b_mcq, profession, part) for _ in range(n_text_content)]
        for future in as_completed(futures):
            contents.append(future.result())

    # Create text content and questions for each passage
    for content in contents:
        text_content = TextContent.objects.create(
            title=content['title'],
            text=content['passage'],
            section=reading_section
        )
        for idx, question in enumerate(content['questions'], 1):
            ReadingQuestion.objects.create(
                text_content=text_content,
                question_text=question['question_text'],
                question_type='MCQ',
                correct_answer=question['correct_answer'],
                marks=1,
                question_number=idx,
                options=question['options'],
                explanation=question['explanation']
            )

    return reading_section 
