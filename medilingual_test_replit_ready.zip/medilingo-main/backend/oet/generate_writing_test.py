import os
from django.conf import settings
from .models import WritingSection
from openai import OpenAI
import json

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def generate_writing_content(profession: str) -> dict:
    """
    Generate writing content using OpenAI API based on profession
    """
    if not os.getenv('OPENAI_API_KEY'):
        raise ValueError("OPENAI_API_KEY environment variable is not set")
        
    prompt = f"""You are an expert OET test content creator.
Generate a high-quality OET writing task for a healthcare professional in the field of {profession}.

The generated task should closely follow this structure and level of detail:

Example:
You are a doctor at Newtown Medical Clinic. Mr Barry Jones is a regular patient of yours.

Writing Task:
Using the information in the case notes, write a letter to Ms Jane Graham, an occupational therapist, detailing Mr Jones' situation and requesting an assessment of his workplace.
Address the letter to:
Ms Jane Graham
Newtown Occupational Therapy
10 Johnston St
Newtown

Case notes (relevant summary):
- Patient: Mr Barry Jones, 46 years old
- Occupation: Forklift driver - prolonged sitting, occasional heavy lifting
- Injury: Lower back strain (severe), 4 days ago after lifting a heavy box
- Treatment:
 - Exercise: gradual walking
 - Physio: painful but compliant
 - Medication: Naproxen, Carisoprodol
 - Extended time off work: 30 days + reviewed again on 30 August 2019
- Progress (30 August):
 - Recovering well but still in pain
 - Still stiff, but range of motion improved
 - Tiring after 30 minutes sitting or lying
 - Walking 30 minutes daily
 - Wants to return to work, discouraged
 - Fit for work if duties exclude lifting and include regular breaks

Instructions:
- Use letter format
- Expand the case notes into full sentences
- Write approximately 180-200 words
- Do not use note form

---

Now, generate a similar OET writing task for a {profession} professional. The task should be professional, relevant to healthcare, and include:
1. A title
2. Case notes (patient information, diagnosis, treatment, etc.) in bullet points, with realistic details
3. Task instructions, including recipient, address, and what the candidate must do
4. Letter type (e.g., Referral, Discharge, Transfer)
5. Writing task: a paragraph of text that details the case and the writing instructions

Format the response as JSON with the following structure:
{{
    "title": "string",
    "case_notes": "string",
    "writing_task": "string",
    "task_instructions": "string",
    "letter_type": "string"
}}

Ensure the generated content is realistic, detailed, and matches the quality and structure of the example above. The writing task should instruct the candidate to write a letter of approximately 180-200 words, expanding the case notes into full sentences, and not using note form in the letter itself."""
    
    try:
        print("Making OpenAI API call...")
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert OET test content creator."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7
        )
        
        if not response.choices:
            raise ValueError("No response from OpenAI API")
            
        content_str = response.choices[0].message.content
        print(f"Raw API response: {content_str}")
        
        try:
            content = json.loads(content_str)
        except json.JSONDecodeError as e:
            print(f"Failed to parse JSON response: {str(e)}")
            raise ValueError(f"Invalid JSON response from API: {content_str}")
            
        # Validate required fields
        required_fields = ['title', 'case_notes', 'task_instructions', 'letter_type']
        missing_fields = [field for field in required_fields if field not in content]
        if missing_fields:
            raise ValueError(f"Missing required fields in API response: {missing_fields}")
            
        return content
        
    except Exception as e:
        print(f"Error in generate_writing_content: {str(e)}")
        import traceback
        print(traceback.format_exc())
        raise

def create_writing_test(profession: str) -> WritingSection:
    """
    Create a writing test section for the specified profession
    
    Args:
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        
    Returns:
        WritingSection: The created writing section
    """
    try:
        print(f"Generating writing content for profession: {profession}")
        # Generate content using AI
        content = generate_writing_content(profession)
        print(f"Generated content: {content}")
        
        if not content or not all(key in content for key in ['title', 'case_notes', 'task_instructions', 'letter_type']):
            print("Generated content is missing required fields")
            raise ValueError("Generated content is incomplete")
        
        # Create writing section
        writing_section = WritingSection.objects.create(
            title=content['title'],
            case_notes=content['case_notes'],
            writing_task=content['writing_task'],
            task_instructions=content['task_instructions'],
            letter_type=content['letter_type'],
            time_limit_minutes=45,  # Standard OET writing time limit
            word_limit=180,  # Standard OET writing word limit
            profession=profession,
            is_published=True
        )
        
        print(f"Created writing section with ID: {writing_section.id}")
        return writing_section
        
    except Exception as e:
        print(f"Error in create_writing_test: {str(e)}")
        import traceback
        print(traceback.format_exc())
        raise 