import graphene
from graphene_django import DjangoConnectionField, DjangoObjectType
from .models import ReadingSection, ReadingQuestion, SpeakingTry, WritingSection, SpeakingSection, ListeningSection, ListeningQuestion, ReadingTry, ListeningTry, TextContent, AudioExcerpt
from graphene import relay
from django.db.models import QuerySet

class ReadingQuestionType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    class Meta:
        model = ReadingQuestion
        fields = '__all__'
        interfaces = (relay.Node,)
        filter_fields = ['text_content']

class TextContentType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    questions = DjangoConnectionField(ReadingQuestionType)
    title = graphene.String()
    
    class Meta:
        model = TextContent
        fields = '__all__'
        interfaces = (relay.Node,)
        filter_fields = ['section']
        connection_class = relay.Connection

    def resolve_questions(self, info, **kwargs):
        return self.questions.all().order_by('question_number')

class ReadingSectionType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    text_contents = DjangoConnectionField(TextContentType)
    
    class Meta:
        model = ReadingSection
        fields = '__all__'
        interfaces = (relay.Node,)
        connection_class = relay.Connection

    def resolve_text_contents(self, info, **kwargs):
        return self.text_contents.all()

class ReadingTryType(DjangoObjectType):
    class Meta:
        model = ReadingTry
        fields = '__all__'

class WritingSectionType(DjangoObjectType):
    caseNotes = graphene.String(source='case_notes')
    taskInstructions = graphene.String(source='task_instructions')
    timeLimitMinutes = graphene.Int(source='time_limit_minutes')
    wordLimit = graphene.Int(source='word_limit')
    letterType = graphene.String(source='letter_type')

    class Meta:
        model = WritingSection
        fields = '__all__'
        interfaces = (graphene.relay.Node,)

class SpeakingSectionType(DjangoObjectType):
    class Meta:
        model = SpeakingSection
        fields = '__all__'
        interfaces = (graphene.relay.Node,)


class SpeakingTryType(DjangoObjectType):
    class Meta:
        model = SpeakingTry
        fields = '__all__'

class ListeningQuestionType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    audio_excerpt = graphene.String()
    class Meta:
        model = ListeningQuestion
        fields = '__all__'
        interfaces = (graphene.relay.Node,)
        filter_fields = ['part']

    def resolve_audio_excerpt(self, info):
        if self.audio_excerpt:
            request = info.context
            return request.build_absolute_uri(self.audio_excerpt.url)
        return None

class ListeningSectionType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    audio_excerpts = graphene.List(lambda: AudioExcerptType)
    questions = DjangoConnectionField(ListeningQuestionType)
    question_by_part = graphene.List(ListeningQuestionType, part=graphene.String())
    
    class Meta:
        model = ListeningSection
        fields = '__all__'

    def resolve_questions(self, info):
        return self.questions.all().order_by('question_number')
        
    def resolve_question_by_part(self, info, part):
        return self.questions.filter(listening_section__part=part).order_by('question_number')
    
    def resolve_audio_excerpts(self, info):
        return list(self.audio_excerpts.all())

class ListeningTryType(DjangoObjectType):
    class Meta:
        model = ListeningTry
        fields = '__all__'


class ReadingSectionProgressionType(graphene.ObjectType):
    a = graphene.Boolean()
    b = graphene.Boolean()
    c = graphene.Boolean()

    def resolve_a(self, info):
        return ReadingTry.objects.filter(user=info.context.user, reading_section__part='A', has_submitted=True).exists()

    def resolve_b(self, info):
        return ReadingTry.objects.filter(user=info.context.user, reading_section__part='B', has_submitted=True).exists()

    def resolve_c(self, info):
        return ReadingTry.objects.filter(user=info.context.user, reading_section__part='C', has_submitted=True).exists()

class ListeningSectionProgressionType(graphene.ObjectType):
    a = graphene.Boolean()
    b = graphene.Boolean()
    c = graphene.Boolean()

    def resolve_a(self, info):
        return ListeningTry.objects.filter(user=info.context.user, listening_section__part='A', has_submitted=True).exists()

    def resolve_b(self, info):
        return ListeningTry.objects.filter(user=info.context.user, listening_section__part='B', has_submitted=True).exists()

    def resolve_c(self, info):
        return ListeningTry.objects.filter(user=info.context.user, listening_section__part='C', has_submitted=True).exists()

class AudioExcerptType(DjangoObjectType):
    db_id = graphene.ID(source='id')
    questions = graphene.List(lambda: ListeningQuestionType)
    audio_text = graphene.String()
    audio_excerpt = graphene.String()

    class Meta:
        model = AudioExcerpt
        fields = '__all__'
        interfaces = (relay.Node,)

    def resolve_audio_excerpt(self, info):
        if self.audio_excerpt:
            request = info.context
            return request.build_absolute_uri(self.audio_excerpt.url)
        return None

    def resolve_questions(self, info):
        return list(self.questions.all().order_by('question_number'))