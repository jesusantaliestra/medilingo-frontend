import graphene
from graphene_django import DjangoObjectType
import logging

from practice.services import MedicalConversationService
from billing.utils import reduce_user_credits
from error_codes import ErrorCodes
from .models import ReadingSection, ReadingQuestion, WritingSection, SpeakingSection, ListeningSection, ListeningQuestion, ReadingTry, WritingTry, ListeningTry, SpeakingTry
from .types import ReadingSectionType, ReadingQuestionType
from django.utils import timezone
import json
import openai
from django.conf import settings
from graphql import GraphQLError
from .services import SpeechToTextService
from graphql_relay import from_global_id
from datetime import datetime
import base64
from guided_practice.models import GuidedPraticeGroup, UserGuidedPracticeAttempt
from guided_practice.types import UserGuidedPracticeAttemptType

logger = logging.getLogger(__name__)

class MessageInput(graphene.InputObjectType):
    role = graphene.String(required=True)
    content = graphene.String(required=True)



class GenerateListeningAudio(graphene.Mutation):
    class Arguments:
        text = graphene.String(required=True)

    audio_data = graphene.String()

    def mutate(self, info, text):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")

        try:
            client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            response = client.audio.speech.create(
                model="tts-1",
                voice="alloy",
                input=text,
                speed=1.0,
                response_format="mp3"
            )
            
            # Convert the audio data to base64
            audio_data = base64.b64encode(response.content).decode('utf-8')
            return GenerateListeningAudio(audio_data=audio_data)
        except Exception as e:
            raise GraphQLError(str(e))

class SubmitGuidedPracticeAttempt(graphene.Mutation):
    class Arguments:
        guided_group_id = graphene.ID(required=True)
        score = graphene.Int(required=True)

    success = graphene.Boolean()
    attempt = graphene.Field(UserGuidedPracticeAttemptType)
    message = graphene.String()

    def mutate(self, info, guided_group_id, score):
        user = info.context.user
        if not user.is_authenticated:
            return SubmitGuidedPracticeAttempt(success=False, attempt=None, message="Authentication required.")
        try:
            group_db_id = from_global_id(guided_group_id)[1]
            guided_group = GuidedPraticeGroup.objects.get(id=group_db_id)
            attempt, created = UserGuidedPracticeAttempt.objects.update_or_create(
                user=user,
                guided_group=guided_group,
                defaults={'score': score}
            )
            return SubmitGuidedPracticeAttempt(success=True, attempt=attempt, message="Attempt saved.")
        except GuidedPraticeGroup.DoesNotExist:
            return SubmitGuidedPracticeAttempt(success=False, attempt=None, message="Guided group not found.")
        except Exception as e:
            return SubmitGuidedPracticeAttempt(success=False, attempt=None, message=str(e))

class SubmitReadingTest(graphene.Mutation):
    class Arguments:
        part = graphene.String(required=True)
        answers = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()
    tryId = graphene.ID(description="The ID of the reading attempt")

    def mutate(self, info, part, answers):
        if not info.context.user.is_authenticated:
            return SubmitReadingTest(success=False, message="Authentication required.")

        try:
            # Get the reading section
            section = ReadingSection.objects.prefetch_related('text_contents', 'text_contents__questions').get(
                part=part.upper(), 
                profession=info.context.user.profession
            )
            
            # Create a new reading try
            reading_try, created = ReadingTry.objects.get_or_create(
                user=info.context.user,
                reading_section=section
            )

            # Parse answers
            answers_dict = json.loads(answers)

            print(answers_dict)
            
            # Calculate score
            total_marks = 0
            earned_marks = 0
            
            # Iterate through all text contents and their questions
            for text_content in section.text_contents.all():
                for question in text_content.questions.all():
                    total_marks += question.marks
                    if str(question.id) in answers_dict:
                        if answers_dict[str(question.id)].strip().lower() == question.correct_answer.strip().lower():
                            earned_marks += question.marks

            # Calculate percentage and grade
            percentage = (earned_marks / total_marks * 100) if total_marks > 0 else 0
            
            if percentage >= 90:
                grade = 'A'
            elif percentage >= 80:
                grade = 'B'
            elif percentage >= 70:
                grade = 'C+'
            elif percentage >= 60:
                grade = 'C'
            elif percentage >= 50:
                grade = 'D'
            else:
                grade = 'E'

            # Update reading try
            reading_try.overall_score = earned_marks
            reading_try.grade = grade
            reading_try.feedback = f"Score: {earned_marks}/{total_marks} ({percentage:.1f}%)"
            reading_try.updated_at = timezone.now()
            reading_try.has_submitted = True
            reading_try.save()

            return SubmitReadingTest(
                success=True, 
                message="Test submitted successfully.",
                tryId=reading_try.id
            )

        except ReadingSection.DoesNotExist:
            return SubmitReadingTest(success=False, message="Reading section not found.")
        except json.JSONDecodeError:
            return SubmitReadingTest(success=False, message="Invalid answers format.")
        except Exception as e:
            return SubmitReadingTest(success=False, message=str(e))

class SubmitWritingTest(graphene.Mutation):
    class Arguments:
        section_id = graphene.ID(required=True)
        letter_content = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()
    tryId = graphene.ID(description="The ID of the writing attempt")

    def mutate(self, info, section_id, letter_content):
        if not info.context.user.is_authenticated:
            return SubmitWritingTest(success=False, message="Authentication required.")

        try:
            # Convert global ID to database ID
            _, db_id = from_global_id(section_id)
            
            # Get the writing section
            section = WritingSection.objects.get(id=db_id, profession=info.context.user.profession)
            
            # Create or get writing try
            writing_try, created = WritingTry.objects.get_or_create(
                user=info.context.user,
                writing_section=section
            )

            # Use OpenAI to evaluate the letter
            client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            
            prompt = f"""You are an expert OET writing examiner. Evaluate this medical letter based on OET criteria.

Task Details:
- Letter Type: {section.letter_type}
- Case Notes: {section.case_notes}
- Task Instructions: {section.task_instructions}

Student's Letter:
{letter_content}

Evaluate based on these criteria and provide scores out of 10 for each:
1. Task Fulfillment & Purpose: Assess how well the letter addresses the task requirements and communicates the purpose
2. Grammar: Evaluate grammatical accuracy and appropriateness for medical communication
3. Vocabulary: Assess medical terminology usage and general vocabulary appropriateness
4. Coherence & Organization: Evaluate the logical flow and organization of information
5. Professional Format: Assess adherence to medical letter writing conventions

Provide your evaluation in the following JSON format only:
{{
    "criteria_scores": {{
        "task_fulfillment": <score 0-10>,
        "grammar": <score 0-10>,
        "vocabulary": <score 0-10>,
        "coherence": <score 0-10>,
        "format": <score 0-10>
    }},
    "band": "<grade A/B/C+/C/D/E>",
    "feedback": [
        "<specific feedback point 1>",
        "<specific feedback point 2>",
        "<specific feedback point 3>"
    ]
}}

Important: Return ONLY the JSON response, no additional text."""

            logger.info(f"Sending evaluation request to OpenAI for writing try {writing_try.id}")
            
            try:
                response = client.chat.completions.create(
                    model="gpt-4-turbo-preview",
                    messages=[
                        {"role": "system", "content": "You are an expert OET writing examiner. Provide evaluation in JSON format only."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.7,
                    response_format={ "type": "json_object" }
                )
                
                response_content = response.choices[0].message.content
                logger.info(f"Received response from OpenAI: {response_content}")
                
                # Parse AI evaluation
                evaluation = json.loads(response_content)
                
                # Validate the response structure
                required_fields = ['criteria_scores', 'band', 'feedback']
                required_scores = ['task_fulfillment', 'grammar', 'vocabulary', 'coherence', 'format']
                
                if not all(field in evaluation for field in required_fields):
                    raise ValueError(f"Missing required fields in AI response. Got: {evaluation.keys()}")
                
                if not all(score in evaluation['criteria_scores'] for score in required_scores):
                    raise ValueError(f"Missing required scores in AI response. Got: {evaluation['criteria_scores'].keys()}")
                
                # Calculate overall score (average of criteria scores)
                criteria_scores = evaluation['criteria_scores']
                overall_score = sum(criteria_scores.values()) / len(criteria_scores)

                # Update writing try with results
                writing_try.result = {
                    'letter_content': letter_content,
                    'completed_at': timezone.now().isoformat(),
                    'section_id': str(section.id),
                    'score': overall_score,
                    'band': evaluation['band'],
                    'criteria_scores': criteria_scores,
                    'feedback': evaluation['feedback']
                }
                writing_try.updated_at = timezone.now()
                writing_try.save()

                return SubmitWritingTest(
                    success=True,
                    message="Writing test submitted and evaluated successfully.",
                    tryId=writing_try.id
                )
                
            except openai.OpenAIError as e:
                logger.error(f"OpenAI API error: {str(e)}")
                return SubmitWritingTest(success=False, message=f"AI evaluation service error: {str(e)}")
            except json.JSONDecodeError as e:
                logger.error(f"JSON parsing error: {str(e)}, Response content: {response_content}")
                return SubmitWritingTest(success=False, message="Invalid response format from AI evaluation")
            except ValueError as e:
                logger.error(f"Validation error: {str(e)}")
                return SubmitWritingTest(success=False, message=f"AI evaluation validation error: {str(e)}")

        except WritingSection.DoesNotExist:
            logger.error(f"Writing section not found: {db_id}")
            return SubmitWritingTest(success=False, message="Writing section not found.")
        except Exception as e:
            logger.error(f"Unexpected error in writing submission: {str(e)}")
            return SubmitWritingTest(success=False, message=str(e))

class SubmitListeningTest(graphene.Mutation):
    class Arguments:
        part = graphene.String(required=True)
        answers = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()
    tryId = graphene.ID(description="The ID of the listening attempt")

    def mutate(self, info, part, answers):
        if not info.context.user.is_authenticated:
            return SubmitListeningTest(success=False, message="Authentication required.")

        try:
            # Get the listening section
            section = ListeningSection.objects.get(part=part.upper(), profession=info.context.user.profession)
            
            # Create a new listening try
            listening_try, created = ListeningTry.objects.get_or_create(
                user=info.context.user,
                listening_section=section
            )

            # Parse answers
            answers_dict = json.loads(answers)

            print(answers_dict)
            
            # Calculate score
            total_marks = 0
            earned_marks = 0
            
            # Iterate through all audio excerpts and their questions
            for audio_excerpt in section.audio_excerpts.all():
                for question in audio_excerpt.questions.all():
                    total_marks += question.marks
                    if str(question.id) in answers_dict:
                        if answers_dict[str(question.id)].strip().lower() == question.correct_answer.strip().lower():
                            earned_marks += question.marks

            # Calculate percentage and grade
            percentage = (earned_marks / total_marks * 100) if total_marks > 0 else 0
            
            if percentage >= 90:
                grade = 'A'
            elif percentage >= 80:
                grade = 'B'
            elif percentage >= 70:
                grade = 'C+'
            elif percentage >= 60:
                grade = 'C'
            elif percentage >= 50:
                grade = 'D'
            else:
                grade = 'E'

            # Update listening try
            listening_try.overall_score = earned_marks
            listening_try.grade = grade
            listening_try.feedback = f"Score: {earned_marks}/{total_marks} ({percentage:.1f}%)"
            listening_try.updated_at = timezone.now()
            listening_try.has_submitted = True
            listening_try.save()

            return SubmitListeningTest(
                success=True, 
                message="Test submitted successfully.",
                tryId=listening_try.id
            )

        except ListeningSection.DoesNotExist:
            return SubmitListeningTest(success=False, message="Listening section not found.")
        except json.JSONDecodeError:
            return SubmitListeningTest(success=False, message="Invalid answers format.")
        except Exception as e:
            return SubmitListeningTest(success=False, message=str(e))

class SubmitSpeakingTest(graphene.Mutation):
    class Arguments:
        conversationHistory = graphene.JSONString(required=True)
        rolePlayType = graphene.String(required=True)
        role_sequence = graphene.String(required=True)

    success = graphene.Boolean()
    message = graphene.String()
    tryId = graphene.ID()
    score = graphene.Float()
    feedback = graphene.JSONString()

    def mutate(self, info, conversationHistory, rolePlayType, role_sequence):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to submit a speaking test")

        try:
            # Get the speaking section by roleSequence and profession
            section = SpeakingSection.objects.get(role_sequence=role_sequence, profession=info.context.user.profession)

            # Create or get speaking try
            speaking_try, created = SpeakingTry.objects.get_or_create(
                user=info.context.user,
                speaking_section=section
            )

            # Initialize OpenAI client
            client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)

            # Prepare the evaluation prompt
            prompt = f"""You are an expert OET speaking examiner. Evaluate this medical conversation based on OET criteria.

Role Play Type: {rolePlayType}
Scenario: {section.role_play_scenario}
Instructions: {section.instructions}

Conversation History:
{json.dumps(conversationHistory, indent=2)}

Evaluate based on these criteria and provide scores out of 10 for each:
1. Fluency & Coherence: Assess the flow and clarity of communication
2. Pronunciation: Evaluate clarity and accuracy of pronunciation
3. Grammar & Vocabulary: Assess grammatical accuracy and appropriate use of medical terminology
4. Interactive Communication: Evaluate how well the candidate engages with the patient
5. Professional Tone: Assess the appropriateness of tone and manner

Provide your evaluation in the following JSON format only:
{{
    "criteria_scores": {{
        "fluency": <score 0-10>,
        "pronunciation": <score 0-10>,
        "grammar": <score 0-10>,
        "interaction": <score 0-10>,
        "tone": <score 0-10>
    }},
    "band": "<grade A/B/C+/C/D/E>",
    "feedback": [
        "<specific feedback point 1>",
        "<specific feedback point 2>",
        "<specific feedback point 3>"
    ]
}}

Important: Return ONLY the JSON response, no additional text."""

            logger.info(f"Sending evaluation request to OpenAI for speaking try {speaking_try.id}")
            try:
                response = client.chat.completions.create(
                    model="gpt-4-turbo-preview",
                    messages=[
                        {"role": "system", "content": "You are an expert OET speaking examiner. Provide evaluation in JSON format only."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.7,
                    response_format={ "type": "json_object" }
                )
                response_content = response.choices[0].message.content
                logger.info(f"Received response from OpenAI: {response_content}")
                evaluation = json.loads(response_content)
                required_fields = ['criteria_scores', 'band', 'feedback']
                required_scores = ['fluency', 'pronunciation', 'grammar', 'interaction', 'tone']
                if not all(field in evaluation for field in required_fields):
                    raise ValueError(f"Missing required fields in AI response. Got: {evaluation.keys()}")
                if not all(score in evaluation['criteria_scores'] for score in required_scores):
                    raise ValueError(f"Missing required scores in AI response. Got: {evaluation['criteria_scores'].keys()}")
                criteria_scores = evaluation['criteria_scores']
                overall_score = sum(criteria_scores.values()) / len(criteria_scores)
                speaking_try.result = {
                    'conversation_history': conversationHistory,
                    'completed_at': timezone.now().isoformat(),
                    'section_id': str(section.id),
                    'score': overall_score,
                    'band': evaluation['band'],
                    'criteria_scores': criteria_scores,
                    'feedback': evaluation['feedback']
                }
                speaking_try.overall_score = int(overall_score * 10)
                speaking_try.grade = evaluation['band']
                speaking_try.updated_at = timezone.now()
                speaking_try.save()
                return SubmitSpeakingTest(
                    success=True,
                    message="Speaking test submitted and evaluated successfully.",
                    tryId=speaking_try.id,
                    score=overall_score,
                    feedback=json.dumps(evaluation)
                )
            except openai.OpenAIError as e:
                logger.error(f"OpenAI API error: {str(e)}")
                return SubmitSpeakingTest(success=False, message=f"AI evaluation service error: {str(e)}")
            except json.JSONDecodeError as e:
                logger.error(f"JSON parsing error: {str(e)}, Response content: {response_content}")
                return SubmitSpeakingTest(success=False, message="Invalid response format from AI evaluation")
            except ValueError as e:
                logger.error(f"Validation error: {str(e)}")
                return SubmitSpeakingTest(success=False, message=f"AI evaluation validation error: {str(e)}")
        except SpeakingSection.DoesNotExist:
            logger.error(f"Speaking section not found for roleSequence: {role_sequence} and profession: {info.context.user.profession}")
            return SubmitSpeakingTest(success=False, message="Speaking section not found.")
        except Exception as e:
            logger.error(f"Unexpected error in speaking submission: {str(e)}")
            return SubmitSpeakingTest(success=False, message=str(e))

class ReadingMutation(graphene.ObjectType):
    generate_listening_audio = GenerateListeningAudio.Field()
    submit_guided_practice_attempt = SubmitGuidedPracticeAttempt.Field()
    submit_reading_test = SubmitReadingTest.Field()
    submit_writing_test = SubmitWritingTest.Field()
    submit_listening_test = SubmitListeningTest.Field()
    submit_speaking_test = SubmitSpeakingTest.Field()

