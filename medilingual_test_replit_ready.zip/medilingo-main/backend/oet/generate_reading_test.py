import os
from django.conf import settings
from .models import ReadingSection, ReadingQuestion, TextContent
from openai import OpenAI
import json

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def generate_reading_content(profession: str, part: str) -> dict:
    """
    Generate reading content using OpenAI API based on profession and part
    """
    prompt = f"""Generate a reading passage for OET {part} test for {profession} professionals.
    The passage should be professional, relevant to healthcare, and include:
    1. A title
    2. The main passage text related to {profession} professionals
    3. 5 questions with:
       - Question text
       - 4 options (for MCQ)
       - Correct answer
       - Explanation
    Format the response as JSON with the following structure:
    {{
        "title": "string",
        "passage": "string",
        "questions": [
            {{
                "question_text": "string",
                "options": ["string", "string", "string", "string"],
                "correct_answer": "string",
                "explanation": "string"
            }}
        ]
    }}
    """
    
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert OET reading test content creator for {profession} professionals."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )
    
    try:
        content = json.loads(response.choices[0].message.content)
        return content
    except json.JSONDecodeError:
        raise Exception("Failed to parse AI generated content")

def create_reading_test(part: str, profession: str) -> ReadingSection:
    """
    Create a reading test section with questions for the specified part and profession
    
    Args:
        part (str): The OET reading test part (A, B, or C)
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        
    Returns:
        ReadingSection: The created reading section with questions
    """
    # Generate content using AI
    content = generate_reading_content(profession, part)
    
    # Create reading section (no title)
    reading_section = ReadingSection.objects.create(
        part=part,
        profession=profession,
        is_published=True
    )
    
    # Create text content (with title)
    text_content = TextContent.objects.create(
        title=content['title'],
        text=content['passage'],
        section=reading_section
    )
    
    # Create questions
    for idx, question_data in enumerate(content['questions'], 1):
        ReadingQuestion.objects.create(
            text_content=text_content,
            question_text=question_data['question_text'],
            question_type='MCQ',
            correct_answer=question_data['correct_answer'],
            marks=1,
            question_number=idx,
            options=question_data['options'],
            explanation=question_data['explanation']
        )
    
    return reading_section 