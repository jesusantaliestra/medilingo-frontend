from django.db import models

class OETProfession(models.TextChoices):
    MEDICINE = 'medicine', 'Medicine'
    NURSING = 'nursing', 'Nursing'
    DENTISTRY = 'dentistry', 'Dentistry'
    PHARMACY = 'pharmacy', 'Pharmacy'
    VETERINARY_SCIENCE = 'veterinary_science', 'Veterinary Science'
    DIETETICS = 'dietetics', 'Dietetics'
    OCCUPATIONAL_THERAPY = 'occupational_therapy', 'Occupational Therapy'
    OPTOMETRY = 'optometry', 'Optometry'
    PHYSIOTHERAPY = 'physiotherapy', 'Physiotherapy'
    PODIATRY = 'podiatry', 'Podiatry'
    RADIOGRAPHY = 'radiography', 'Radiography'
    SPEECH_PATHOLOGY = 'speech_pathology', 'Speech Pathology'
