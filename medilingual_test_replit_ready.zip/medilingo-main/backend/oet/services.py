import openai
from django.conf import settings
import base64
import tempfile
import os

class SpeechToTextService:
    def __init__(self):
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)

    def transcribe_audio(self, audio_data: str) -> dict:
        """
        Transcribe audio data using OpenAI's Whisper API
        
        Args:
            audio_data (str): Base64 encoded audio data
            
        Returns:
            dict: Transcription result with text and confidence
        """
        try:
            # Decode base64 audio data
            audio_bytes = base64.b64decode(audio_data)
            
            # Create a temporary file to store the audio
            with tempfile.NamedTemporaryFile(delete=False, suffix='.webm') as temp_audio:
                temp_audio.write(audio_bytes)
                temp_audio_path = temp_audio.name
            
            # Open the audio file and transcribe
            with open(temp_audio_path, 'rb') as audio_file:
                transcription = self.client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    response_format="json"
                )
            
            # Clean up the temporary file
            os.unlink(temp_audio_path)
            
            return {
                'text': transcription.text,
                'confidence': transcription.confidence if hasattr(transcription, 'confidence') else None
            }
            
        except Exception as e:
            raise Exception(f"Error transcribing audio: {str(e)}") 