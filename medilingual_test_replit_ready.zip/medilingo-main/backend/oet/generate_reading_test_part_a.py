import os
from openai import OpenAI
import json
from .models import ReadingSection, TextContent, ReadingQuestion
from concurrent.futures import ThreadPoolExecutor, as_completed

def generate_fill_the_gap_content(profession: str, part: str) -> dict:
    """
    Generate a reading passage with fill-the-gap questions for OET Part on profession and part.
    """
    prompt = f"""Generate a reading passage for the OET {part} test for {profession} professionals.
The output should include:
1. A title for the passage.
2. A main passage (at least 120 words) that is professional, relevant to healthcare, and contains clinical scenarios or cases related to {profession}.
3. 5 fill-the-gap questions, each based on the passage. Each question should:
   - Present a sentence from the passage with a single word removed, shown as a blank (e.g., 'lorem ipsum ___').
   - Clearly indicate the correct answer for the gap (the missing word from the passage).
   - Provide a brief explanation for why that answer is correct in the context of the passage.

Format the response as JSON with the following structure:
{{
    "title": "string",
    "passage": "A passage",
    "gaps": [
        {{
            "gap_number": int,
            "question_text": "Sentence from the passage with a blank (e.g., lorem ipsum ___)",
            "correct_answer": "string",
            "explanation": "string"
        }}
    ]
}}
"""

    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert OET test content creator for {profession} professionals."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )

    try:
        content = json.loads(response.choices[0].message.content)
        return content
    except json.JSONDecodeError:
        raise Exception("Failed to parse AI generated fill-the-gap content")

def create_fill_the_gap_reading_test(part: str, profession: str, n_text_content: int = 4) -> ReadingSection:
    """
    Create a reading test section with n_text_content passages, each with 5 fill-the-gap questions.
    Args:
        part (str): The OET reading test part (should be 'A')
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        n_text_content (int): Number of passages to generate (default 5)
    Returns:
        ReadingSection: The created reading section with fill-the-gap questions
    """
    # Create reading section (no title)
    reading_section = ReadingSection.objects.create(
        part=part,
        profession=profession,
        is_published=True
    )

    # Generate n_text_content passages in parallel
    contents = []
    with ThreadPoolExecutor() as executor:
        futures = [executor.submit(generate_fill_the_gap_content, profession, part) for _ in range(n_text_content)]
        for future in as_completed(futures):
            contents.append(future.result())

    # Create text content and questions for each passage
    for content in contents:
        text_content = TextContent.objects.create(
            title=content['title'],
            text=content['passage'],
            section=reading_section
        )
        for gap in content['gaps']:
            ReadingQuestion.objects.create(
                text_content=text_content,
                question_text=gap['question_text'],
                question_type='FILL',
                correct_answer=gap['correct_answer'],
                marks=1,
                question_number=gap['gap_number'],
                options=None,
                explanation=gap['explanation']
            )

    return reading_section 
