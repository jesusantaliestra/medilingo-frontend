import os
from django.conf import settings
from .models import SpeakingSection
from openai import OpenAI
import json

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def generate_speaking_content(profession: str) -> dict:
    """
    Generate speaking content using OpenAI API based on profession
    
    Args:
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        
    Returns:
        dict: Generated speaking test content
    """
    prompt = f"""Generate a speaking test scenario for OET test for {profession} professionals.
    The scenario should be professional, relevant to healthcare, and include:
    1. A title
    2. Role play type (e.g., 'Patient Consultation', 'Handover', 'Discharge Planning')
    3. Role play scenario (A clinical case)
    4. Instructions for the candidate
    5. Initial conversation starter
    6. Expected key points to cover
    7. Medical terminology to use
    8. Professional phrases to incorporate
    
    Format the response as JSON with the following structure:
    {{
        "title": "string",
        "role_play_type": "string",
        "role_play_scenario": "string",
        "instructions": "string",
        "audio_text": "string",
        "key_points": ["string"],
        "medical_terms": ["string"],
        "professional_phrases": ["string"]
    }}
    """
    
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert OET test content creator."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )
    
    try:
        content = json.loads(response.choices[0].message.content)
        return content
    except json.JSONDecodeError:
        raise Exception("Failed to parse AI generated content")

def create_speaking_test(profession: str, role_sequence: str) -> SpeakingSection:
    """
    Create a speaking test section for the specified profession
    
    Args:
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        
    Returns:
        SpeakingSection: The created speaking section
    """
    # Generate content using AI
    content = generate_speaking_content(profession)
    
    # Create speaking section
    speaking_section = SpeakingSection.objects.create(
        title=content['title'],
        role_play_type=content['role_play_type'],
        role_play_scenario=content['role_play_scenario'],
        instructions=content['instructions'],
        preparation_time=3,  # 3 minutes preparation time
        time_limit=5,  # 5 minutes speaking time
        time_limit_minutes=5,  # for admin display
        score=0.0,
        profession=profession,
        is_published=True,
        role_sequence=role_sequence,
    )
    
    return speaking_section 