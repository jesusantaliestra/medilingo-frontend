from django.contrib import admin
from .models import (
    ListeningTry, ReadingSection, ReadingQuestion, ReadingTry, TextContent,
    WritingSection,
    SpeakingSection,
    ListeningSection, ListeningQuestion,
    AudioExcerpt,
)

@admin.register(ReadingSection)
class ReadingSectionAdmin(admin.ModelAdmin):
    list_display = ('part', 'time_limit_minutes', 'is_published', 'created_at', 'profession')
    list_filter = ('part', 'is_published', 'created_at', 'profession')
    search_fields = ('description', 'text_content')
    readonly_fields = ('created_at',)
    fieldsets = (
        ('Basic Information', {
            'fields': ('description', 'part', 'is_published', 'profession')
        }),
        ('Content', {
            'fields': ('text_content',)
        }),
        ('Timing', {
            'fields': ('time_limit_minutes',)
        }),
        ('Metadata', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(ReadingQuestion)
class ReadingQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_number',  'question_type', 'marks')
    list_filter = ('question_type', )
    search_fields = ('question_text', 'correct_answer')
   
    fieldsets = (
        ('Question Details', {
            'fields': ( 'question_number', 'question_type', 'marks')
        }),
        ('Content', {
            'fields': ('question_text', 'correct_answer', 'options', 'explanation')
        }),
    )

@admin.register(WritingSection)
class WritingSectionAdmin(admin.ModelAdmin):
    list_display = ('title', 'letter_type', 'time_limit_minutes', 'is_published', 'profession')
    list_filter = ('letter_type', 'is_published', 'profession')
    search_fields = ('title', 'description', 'case_notes', 'task_instructions')
    readonly_fields = ('created_at',)
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'description', 'letter_type', 'is_published', 'profession')
        }),
        ('Content', {
            'fields': ('case_notes', 'task_instructions')
        }),
        ('Limits', {
            'fields': ('time_limit_minutes', 'word_limit')
        }),
        ('Metadata', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(SpeakingSection)
class SpeakingSectionAdmin(admin.ModelAdmin):
    list_display = ('title', 'role_play_type', 'time_limit_minutes', 'is_published', 'created_at', 'profession')
    list_filter = ('role_play_type', 'is_published', 'profession')
    search_fields = ('title', 'role_play_scenario', 'instructions')
    readonly_fields = ('created_at', 'score')
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'role_play_type', 'is_published', 'profession')
        }),
        ('Content', {
            'fields': ('role_play_scenario', 'instructions')
        }),
        ('Timing', {
            'fields': ('preparation_time', 'time_limit', 'time_limit_minutes')
        }),
        ('Results', {
            'fields': ('score', 'created_at')
        }),
    )

@admin.register(ListeningSection)
class ListeningSectionAdmin(admin.ModelAdmin):
    list_display = ('title', 'part', 'time_limit_minutes', 'is_published', 'profession')
    list_filter = ('part', 'is_published', 'profession')
    search_fields = ('title', 'description')
    readonly_fields = ('created_at',)
    fieldsets = (
        ('Basic Information', {
            'fields': ('title', 'description', 'part', 'is_published', 'profession')
        }),
        ('Timing', {
            'fields': ('time_limit_minutes',)
        }),
        ('Metadata', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

@admin.register(AudioExcerpt)
class AudioExcerptAdmin(admin.ModelAdmin):
    list_display = ('listening_section', 'audio_excerpt')
    search_fields = ('audio_text',)
    list_filter = ('listening_section',)

@admin.register(ListeningQuestion)
class ListeningQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_number', 'audio_excerpt', 'question_type', 'marks', 'time_marker')
    list_filter = ('question_type', 'audio_excerpt__listening_section__part', 'audio_excerpt__listening_section__profession')
    search_fields = ('question_text', 'correct_answer')
    list_select_related = ('audio_excerpt',)
    fieldsets = (
        ('Question Details', {
            'fields': ('audio_excerpt', 'question_number', 'question_type', 'marks', 'time_marker')
        }),
        ('Content', {
            'fields': ('question_text', 'correct_answer', 'options', 'explanation')
        }),
    )

@admin.register(TextContent)
class TextContentAdmin(admin.ModelAdmin):
    list_display = ('title', 'section')
    search_fields = ('title', 'text')

admin.site.register(ReadingTry)
admin.site.register(ListeningTry)