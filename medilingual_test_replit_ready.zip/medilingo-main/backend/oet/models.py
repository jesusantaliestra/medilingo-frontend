from django.db import models
from oet import OETProfession
from user.models import User
from django.utils import timezone


#=====================================
# Reading section and questions
# =======================================

class ReadingSection(models.Model):
    PART_CHOICES = [
        ('A', 'Part A'),
        ('B', 'Part B'),
        ('C', 'Part C'),
    ]
    
    description = models.TextField(null=True, blank=True)
    part = models.CharField(max_length=1, choices=PART_CHOICES, default='A')
    time_limit_minutes = models.IntegerField(
        default=15 if part == 'A' else 45,
        help_text="Part A: 15 minutes, Part B: 45 minutes"
    )
    created_at = models.DateTimeField(default=timezone.now)
    is_published = models.BooleanField(default=False)
    profession = models.CharField(max_length=50, choices=OETProfession, default=OETProfession.MEDICINE.value)

    class Meta:
        unique_together = ('part', 'profession')

    def __str__(self):
        return f"Reading {self.part}"
    
class TextContent(models.Model):
    title = models.CharField(max_length=200, default='')
    text = models.TextField(default='')
    section = models.ForeignKey(ReadingSection, on_delete=models.CASCADE, related_name='text_contents')
    
    def __str__(self):
        return self.title

class ReadingQuestion(models.Model):
    QUESTION_TYPES = [
        ('MCQ', 'Multiple Choice'),
        ('FILL', 'Fill in the blank'),
        ('TRUE_FALSE', 'True/False'),
    ]
    
    # reading_section = models.ForeignKey(ReadingSection, on_delete=models.CASCADE, related_name='questions')
    text_content = models.ForeignKey(TextContent, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField(default='')
    question_type = models.CharField(max_length=10, choices=QUESTION_TYPES, default='MCQ')
    correct_answer = models.TextField(default='')
    marks = models.IntegerField(default=1)
    question_number = models.IntegerField(default=1)
    options = models.JSONField(null=True, blank=True, help_text="For MCQ questions, store options as JSON array")
    explanation = models.TextField(null=True, blank=True)


    class Meta:
        ordering = ['question_number']

    def __str__(self):
        return f"Q{self.question_number}: {self.question_text[:50]}..."
    

class BaseTry(models.Model):
    GRADE_CHOICES = [
        ('A', 'A'),
        ('B', 'B'),
        ('C+', 'C+'),
        ('C', 'C'),
        ('D', 'D'),
        ('E', 'E'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    overall_score = models.IntegerField(default=0)
    feedback = models.TextField(null=True, blank=True)
    grade = models.CharField(max_length=2, choices=GRADE_CHOICES, default='E')
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(default=timezone.now)
    has_submitted = models.BooleanField(default=False)

    class Meta:
        abstract = True


class ReadingTry(BaseTry):
    reading_section = models.ForeignKey(ReadingSection, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.user.username}'s attempt at {self.reading_section} ({self.created_at})"


#=====================================
# Writing section and questions
# =======================================
class WritingSection(models.Model):
    title = models.CharField(max_length=200, default='')
    description = models.TextField(null=True, blank=True)
    case_notes = models.TextField(default='')
    task_instructions = models.TextField(default='')
    time_limit_minutes = models.IntegerField(default=45)
    word_limit = models.IntegerField(default=180)
    letter_type = models.CharField(max_length=50, help_text="Type of letter (e.g., referral, discharge, etc.)", null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    is_published = models.BooleanField(default=False)
    profession = models.CharField(max_length=50, choices=OETProfession, default=OETProfession.MEDICINE.value)
    writing_task = models.TextField(default='')

    def __str__(self):
        return f"Writing - {self.title}"
    

class WritingTry(BaseTry):
    writing_section = models.ForeignKey(WritingSection, on_delete=models.CASCADE)
    result = models.JSONField(default=dict)

    def __str__(self):
        return f"{self.user.username}'s writing attempt ({self.created_at})"


#=====================================
# Speaking section and questions
# =======================================
class SpeakingSection(models.Model):
    title = models.CharField(max_length=200, default='')
    role_play_type = models.CharField(max_length=100, default='')
    role_play_scenario = models.TextField(default='')
    instructions = models.TextField(default='')
    preparation_time = models.IntegerField(default=3)  # in minutes
    time_limit = models.IntegerField(default=5)  # in minutes
    time_limit_minutes = models.IntegerField(default=5)  # for admin display
    role_sequence_choices = [
        ('first', 'First'),
        ('second', 'Second'),
    ]
    role_sequence = models.CharField(max_length=6, choices=role_sequence_choices, default='first')
    score = models.FloatField(default=0.0)
    created_at = models.DateTimeField(default=timezone.now)
    is_published = models.BooleanField(default=False)
    profession = models.CharField(max_length=50, choices=OETProfession, default=OETProfession.MEDICINE.value)

    def __str__(self):
        return f"Speaking - {self.title}"

   
    

class SpeakingTry(BaseTry):
    speaking_section = models.ForeignKey(SpeakingSection, on_delete=models.CASCADE)
    result = models.JSONField(default=dict, help_text="Stores evaluation results including scores, feedback, and conversation history")

    def __str__(self):
        return f"{self.user.username}'s speaking attempt ({self.created_at})"


#=====================================
# Listening section and questions
# =======================================

class ListeningSection(models.Model):
    PART_CHOICES = [
        ('A', 'Part A'),
        ('B', 'Part B'),
        ('C', 'Part C'),
    ]
    
    title = models.CharField(max_length=200, default='')
    description = models.TextField(null=True, blank=True)
    part = models.CharField(max_length=1, choices=PART_CHOICES, default='A')
    time_limit_minutes = models.IntegerField(
        default=30 if part == 'A' else 45,
        help_text="Part A: 30 minutes, Part B: 45 minutes"
    )
    created_at = models.DateTimeField(default=timezone.now)
    is_published = models.BooleanField(default=False)
    profession = models.CharField(max_length=50, choices=OETProfession, default=OETProfession.MEDICINE.value)
    # class Meta:
    #     unique_together = ('title', 'part')

    def __str__(self):
        return f"Listening {self.part} - {self.title}"
    
class AudioExcerpt(models.Model):
    listening_section = models.ForeignKey(ListeningSection, on_delete=models.CASCADE, related_name='audio_excerpts')
    audio_text = models.TextField(help_text="Transcript of the audio", null=True, blank=True)
    audio_excerpt = models.FileField(upload_to='audio_excerpt/', null=True, blank=True)

    def __str__(self):
        return f"AudioExcerpt for {self.listening_section} + {self.id}"



class ListeningQuestion(models.Model):
    QUESTION_TYPES = [
        ('MCQ', 'Multiple Choice'),
        ('FILL', 'Fill in the blank'),
        ('TRUE_FALSE', 'True/False'),
    ]
    
    audio_excerpt = models.ForeignKey(AudioExcerpt, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField(default='')
    question_type = models.CharField(max_length=10, choices=QUESTION_TYPES, default='MCQ')
    correct_answer = models.TextField(default='')
    marks = models.IntegerField(default=1)
    time_marker = models.IntegerField(default=0, help_text="Time in seconds when this question should be shown")
    question_number = models.IntegerField(default=1)
    options = models.JSONField(null=True, blank=True, help_text="For MCQ questions, store options as JSON array")
    explanation = models.TextField(null=True, blank=True)

    class Meta:
        ordering = ['question_number']

    def __str__(self):
        return f"Q{self.question_number}: {self.question_text[:50]}..."
    

class ListeningTry(BaseTry):
    listening_section = models.ForeignKey(ListeningSection, on_delete=models.CASCADE)

