import os
from django.conf import settings
from .models import ListeningSection, ListeningQuestion
from openai import OpenAI
import json

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def generate_listening_content(profession: str, part: str) -> dict:
    """
    Generate listening content using OpenAI API based on profession and part
    """
    prompt = f"""Generate a listening passage for OET {part} test for {profession} professionals.
    The passage should be professional, relevant to healthcare, and written as a conversation between two people (for example, a Doctor and a Patient). Use alternating lines for each speaker, clearly indicating who is speaking (e.g., 'Doctor:' and 'Patient:').

    Include:
    1. A title
    2. The main passage text as a conversation (this will be converted to audio)
    3. 5 questions with:
       - Question text
       - 4 options (for MCQ)
       - Correct answer
       - Explanation
       - Time marker (in seconds when this question should be shown)
    Format the response as JSON with the following structure:
    {{
        "title": "string",
        "passage": "string",
        "questions": [
            {{
                "question_text": "string",
                "options": ["string", "string", "string", "string"],
                "correct_answer": "string",
                "explanation": "string",
                "time_marker": integer
            }}
        ]
    }}
    """
    
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are an expert OET test content creator."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )
    
    try:
        content = json.loads(response.choices[0].message.content)
        return content
    except json.JSONDecodeError:
        raise Exception("Failed to parse AI generated content")

def create_listening_test(part: str, profession: str) -> ListeningSection:
    """
    Create a listening test section with questions for the specified part and profession
    
    Args:
        part (str): The OET listening test part (A, B, or C)
        profession (str): The healthcare profession (e.g., 'Nursing', 'Medicine')
        
    Returns:
        ListeningSection: The created listening section with questions
    """
    # Generate content using AI
    content = generate_listening_content(profession, part)
    
    # Create listening section
    listening_section = ListeningSection.objects.create(
        title=content['title'],
        audio_text=content['passage'],
        part=part,
        profession=profession,
        is_published=True
    )
    
    # Create questions
    for idx, question_data in enumerate(content['questions'], 1):
        ListeningQuestion.objects.create(
            listening_section=listening_section,
            question_text=question_data['question_text'],
            question_type='MCQ',
            correct_answer=question_data['correct_answer'],
            marks=1,
            question_number=idx,
            options=question_data['options'],
            explanation=question_data['explanation'],
            time_marker=question_data['time_marker']
        )
    
    return listening_section 