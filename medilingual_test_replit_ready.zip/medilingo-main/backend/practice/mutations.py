import graphene
from graphql import GraphQLError
from error_codes import ErrorCodes
from billing.utils import reduce_user_credits
from vocabulary_practice.models import UserVocabularyAttempt, Vocabulary
from practice.services import MedicalConversationService, SpeechToTextService, TranslationService, VoiceAccuracyService
from graphql_relay import from_global_id

class MessageInput(graphene.InputObjectType):
    role = graphene.String(required=True)
    content = graphene.String(required=True)

class VitalSignsInput(graphene.InputObjectType):
    bloodPressure = graphene.String(required=True)
    heartRate = graphene.String(required=True)
    respiratoryRate = graphene.String(required=True)
    temperature = graphene.String(required=True)

class PatientInfoInput(graphene.InputObjectType):
    age = graphene.Int(required=True)
    gender = graphene.String(required=True)
    chiefComplaint = graphene.String(required=True)
    history = graphene.String(required=True)
    vitalSigns = graphene.Field(VitalSignsInput, required=True)

class ClinicalCaseInput(graphene.InputObjectType):
    description = graphene.String(required=True)

class GenerateAiMessage(graphene.Mutation):
    class Arguments:
        conversation_history = graphene.List(MessageInput, required=True)
        clinical_case = ClinicalCaseInput(required=True)

    response = graphene.String()

    def mutate(self, info, conversation_history, clinical_case):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")

        try:
            service = MedicalConversationService()
            response = service.generate_response(conversation_history, clinical_case)
            return GenerateAiMessage(response=response)
        except Exception as e:
            raise GraphQLError(str(e))

class TranscribeAudio(graphene.Mutation):
    class Arguments:
        audio_data = graphene.String(required=True)

    text = graphene.String()
    score = graphene.Int()
    feedback = graphene.List(graphene.String)

    def mutate(self, info, audio_data):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")

        try:
            service = SpeechToTextService()
            result = service.transcribe_audio(audio_data)
            return TranscribeAudio(
                text=result["text"],
                score=result["score"],
                feedback=result["feedback"]
            )
        except Exception as e:
            raise GraphQLError(str(e))

class TranslateText(graphene.Mutation):
    class Arguments:
        text = graphene.String(required=True)
        target_language = graphene.String(required=True)

    translated_text = graphene.String()

    def mutate(self, info, text, target_language):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")
        
        success, message = reduce_user_credits(info.context.user)
        if not success:
            raise GraphQLError(
                message,
                extensions={
                    "code": ErrorCodes.NO_CREDITS,
                }
            )

        try:
            service = TranslationService()
            translated_text = service.translate_text(text, target_language)
            return TranslateText(translated_text=translated_text)
        except Exception as e:
            raise GraphQLError(str(e))

class TestVocabularyPronucatin(graphene.Mutation):
    class Arguments:
        expected_term = graphene.String(required=True)
        audio_data = graphene.String(required=True)
        vocabulary_id = graphene.ID(required=True)

    spoken_text = graphene.String()
    matching_accuracy = graphene.Float()
    pronunciation_score = graphene.Float()
    feedback = graphene.String()
    confidence_score = graphene.Int()
    vocabulary_id = graphene.ID()

    def mutate(self, info, expected_term, audio_data, vocabulary_id):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")
        
        if not info.context.user.subscription_valid:
            raise GraphQLError("You must have a valid subscription to use this feature")
        
        success, message = reduce_user_credits(info.context.user)
        if not success:
            raise GraphQLError(
                message,
                extensions={
                    "code": ErrorCodes.NO_CREDITS,
                }
            )

        try:
            service = VoiceAccuracyService()
            result = service.test_pronunciation(expected_term, audio_data)

            _, vocabulary_id = from_global_id(vocabulary_id)
            vocabulary = Vocabulary.objects.get(id=vocabulary_id)

        
            attempt, created = UserVocabularyAttempt.objects.get_or_create(
                user=info.context.user,
                vocabulary=vocabulary,
                defaults={'score': result["pronunciation_score"]}
            )
            
            # If attempt exists, update the score
            if not created:
                attempt.score = result["pronunciation_score"]
                attempt.save()

            return TestVocabularyPronucatin(
                spoken_text=result["spoken_text"],
                matching_accuracy=result["matching_accuracy"],
                pronunciation_score=result["pronunciation_score"],
                feedback=result["feedback"],
                confidence_score=result["confidence_score"],
                vocabulary_id=vocabulary_id
            )
        
           
        except Exception as e:
            raise GraphQLError(str(e))
        

class TestPronucatin(graphene.Mutation): # unversal/common
    class Arguments:
        expected_term = graphene.String(required=True)
        audio_data = graphene.String(required=True)

    spoken_text = graphene.String()
    matching_accuracy = graphene.Float()
    pronunciation_score = graphene.Float()
    feedback = graphene.String()
    confidence_score = graphene.Int()

    def mutate(self, info, expected_term, audio_data):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")
        
        if not info.context.user.subscription_valid:
            raise GraphQLError("You must have a valid subscription to use this feature")
        
        success, message = reduce_user_credits(info.context.user)
        if not success:
            raise GraphQLError(
                message,
                extensions={
                    "code": ErrorCodes.NO_CREDITS,
                }
            )

        user_lanauge_to_learn = info.context.user.language_to_learn
        try:
            service = VoiceAccuracyService()
            result = service.test_pronunciation(expected_term, audio_data, language=user_lanauge_to_learn)


            return TestVocabularyPronucatin(
                spoken_text=result["spoken_text"],
                matching_accuracy=result["matching_accuracy"],
                pronunciation_score=result["pronunciation_score"],
                feedback=result["feedback"],
                confidence_score=result["confidence_score"],
            )
        
           
        except Exception as e:
            raise GraphQLError(str(e))

class ProcessAudioAndGenerateResponse(graphene.Mutation):
    class Arguments:
        audio_data = graphene.String(required=True)
        conversation_history = graphene.List(MessageInput, required=True)
        clinical_case = ClinicalCaseInput(required=True)
        is_complex_practice = graphene.Boolean(default_value=False)

    text = graphene.String()
    score = graphene.Int()
    feedback = graphene.List(graphene.String)
    response = graphene.String()
    voiceResponse = graphene.String()

    def mutate(self, info, audio_data, conversation_history, clinical_case, is_complex_practice):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")
        
        if not info.context.user.subscription_valid:
            raise GraphQLError("You must have a valid subscription to use this feature")
        
        success, message = reduce_user_credits(info.context.user)
        if not success:
            raise GraphQLError(
                message,
                extensions={
                    "code": ErrorCodes.NO_CREDITS,
                }
            )

        try:
            conversation_service = MedicalConversationService()
            
            # If audio_data is empty, this is a text-only chat
            if not audio_data:
                # Get the last message from conversation history (the user's text input)
                last_message = conversation_history[-1]
                text = last_message["content"]
                
                # Generate AI response
                ai_response = conversation_service.generate_response(conversation_history, clinical_case)
                
                return ProcessAudioAndGenerateResponse(
                    text=text,
                    score=100,  # No pronunciation score for text
                    feedback=[],  # No feedback for text
                    response=ai_response,
                    voiceResponse=None  # No voice response for text
                )
            
            # For voice input, process as before
            speech_service = SpeechToTextService()
            transcription_result = speech_service.transcribe_audio(audio_data)
            
            # Add the transcribed text to conversation history
            new_conversation = [
                *conversation_history,
                {
                    "role": "doctor",
                    "content": transcription_result["text"]
                }
            ]
            
            # Generate AI response
            ai_response = conversation_service.generate_response(new_conversation, clinical_case)
            
            # Generate voice response since this was a voice input
            voice_response = conversation_service.generate_voice_response(ai_response)
            
            # For complex practice, don't return score and feedback
            if is_complex_practice:
                return ProcessAudioAndGenerateResponse(
                    text=transcription_result["text"],
                    score=None,
                    feedback=None,
                    response=ai_response,
                    voiceResponse=voice_response
                )
            
            return ProcessAudioAndGenerateResponse(
                text=transcription_result["text"],
                score=transcription_result["score"],
                feedback=transcription_result["feedback"],
                response=ai_response,
                voiceResponse=voice_response
            )
        except Exception as e:
            raise GraphQLError(str(e))

class GenerateVoice(graphene.Mutation):
    class Arguments:
        text = graphene.String(required=True)

    audio_data = graphene.String()

    def mutate(self, info, text):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")
        
        success, message = reduce_user_credits(info.context.user)
        if not success:
            raise GraphQLError(
                message,
                extensions={
                    "code": ErrorCodes.NO_CREDITS,
                }
            )

        try:
            service = MedicalConversationService()
            audio_data = service.generate_voice_response(text)
            return GenerateVoice(audio_data=audio_data)
        except Exception as e:
            raise GraphQLError(str(e))

class MarkVocabularyTestAsCompleted(graphene.Mutation):
    class Arguments:
        vocabulary_id = graphene.ID(required=True)

    success = graphene.Boolean()
    vocabulary_id = graphene.ID()

    def mutate(self, info, vocabulary_id):
        if not info.context.user.is_authenticated:
            raise GraphQLError("You must be logged in to use this feature")

        try:
            _, vocabulary_id = from_global_id(vocabulary_id)
            vocabulary = Vocabulary.objects.get(id=vocabulary_id)

            attempt, created = UserVocabularyAttempt.objects.get_or_create(
                user=info.context.user,
                vocabulary=vocabulary,
                defaults={'completed': True}
            )
            
            # If attempt exists, update completed status
            if not created:
                attempt.completed = True
                attempt.save()

            return MarkVocabularyTestAsCompleted(
                success=True,
                vocabulary_id=vocabulary_id
            )
        except Exception as e:
            raise GraphQLError(str(e))

class PracticeMutation(graphene.ObjectType):
    generate_ai_message = GenerateAiMessage.Field()
    transcribe_audio = TranscribeAudio.Field()
    translate_text = TranslateText.Field()
    test_vocabulary_pronunciation = TestVocabularyPronucatin.Field()
    test_pronunciation = TestPronucatin.Field() # universal/common
    process_audio_and_generate_response = ProcessAudioAndGenerateResponse.Field()
    generate_voice = GenerateVoice.Field()
    mark_vocabulary_test_as_completed = MarkVocabularyTestAsCompleted.Field() 