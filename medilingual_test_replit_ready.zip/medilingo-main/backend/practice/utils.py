from django.db.models import QuerySet
from complex_practice.models import PatientCase

def get_user_speciality_cases(user) -> QuerySet:
    """
    Get patient cases filtered by user's speciality.
    Returns empty queryset if user is not authenticated or has no speciality.
    """
    if not user.is_authenticated:
        return PatientCase.objects.none()
    
    user_speciality = user.speciality
    if not user_speciality:
        return PatientCase.objects.none()
    
    return PatientCase.objects.filter(speciality=user_speciality) 