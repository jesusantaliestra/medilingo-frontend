import graphene
from graphene_django import DjangoObjectType
from .models import Level, Category, Speciality
from complex_practice.models import PatientCase
from vocabulary_practice.models import Vocabulary
from guided_practice.models import GuidedPraticeGroup
from django.db import connection

class LevelType(DjangoObjectType):
    total_practice = graphene.Int()
    total_completed = graphene.Int()
    
    class Meta:
        model = Level
        fields = ('id', 'name', 'title', 'slug', 'description', 'is_top_level', 'sublevels', 'level_type')
    
    def resolve_total_practice(self, info):
        user = info.context.user
        if not user.is_authenticated or not user.speciality:
            return 0
            
        if self.level_type == 'vocabulary':
            return Vocabulary.objects.filter(
                level=self,
                speciality=user.speciality,
                language=user.language_to_learn
            ).count()
        elif self.level_type == 'guided_case':
            return GuidedPraticeGroup.objects.filter(
                level=self,
                speciality=user.speciality,
                language=user.language_to_learn
            ).count()
        elif self.level_type == 'complex_case':
            return PatientCase.objects.filter(
                level=self,
                speciality=user.speciality,
                language=user.language_to_learn
            ).count()
        return 0
    
    def resolve_total_completed(self, info):
        user = info.context.user
        if not user.is_authenticated or not user.speciality:
            return 0
            
        if self.level_type == 'vocabulary':
            from vocabulary_practice.models import UserVocabularyAttempt
            return UserVocabularyAttempt.objects.filter(
                user=user,
                vocabulary__level=self,
                vocabulary__speciality=user.speciality,
                vocabulary__language=user.language_to_learn,
                completed=True
            ).count()
        elif self.level_type == 'guided_case':
            from guided_practice.models import UserGuidedPracticeAttempt
            return UserGuidedPracticeAttempt.objects.filter(
                user=user,
                guided_group__level=self,
                guided_group__speciality=user.speciality,
                guided_group__language=user.language_to_learn,
                score__gt=0  # Consider attempts with score > 0 as completed
            ).count()
        elif self.level_type == 'complex_case':
            try:
                from complex_practice.models import UserPatientCaseAttempt
                return UserPatientCaseAttempt.objects.filter(
                    user=user,
                    patient_case__level=self,
                    patient_case__speciality=user.speciality,
                    patient_case__language=user.language_to_learn,
                    completed=True
                ).count()
            except Exception:
                # If any error occurs (table doesn't exist, etc.), return 0
                return 0
        return 0

class CategoryType(DjangoObjectType):
    class Meta:
        model = Category
        fields = ('id', 'name', 'description', 'specialities', 'slug')

class SpecialityType(DjangoObjectType):
    class Meta:
        model = Speciality
        fields = ('id', 'name', 'description', 'slug', 'category')

class PatientCaseType(DjangoObjectType):
    class Meta:
        model = PatientCase
        fields = ('id', 'slug', 'title', 'content', 'speciality', 'level') 