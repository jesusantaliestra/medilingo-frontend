from django.core.management.base import BaseCommand
from practice.models import Level, Category, Speciality
from vocabulary_practice.models import Vocabulary
from guided_practice.models import GuidedPraticeGroup, GuidedPractice
from complex_practice.models import PatientCase
import logging
from django.db.utils import IntegrityError

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Initialize practice data including levels, categories, specialties, and vocabulary'

    def handle(self, *args, **options):
        self.stdout.write('Initializing practice data...')
        
        # Create default levels
        self.create_default_levels()
        
        # Populate specialties
        self.populate_specialties()
        
      
        
        self.stdout.write(self.style.SUCCESS('Successfully initialized practice data'))

    def create_default_levels(self):
        self.stdout.write('Creating default levels...')
        
        # Create sublevels first
        general_vocab = Level.objects.get_or_create(
            slug='general-vocabulary',
            defaults={
                'name': 'General Vocabulary',
                'title': 'General Medical Vocabulary',
                'description': 'Learn and practice general medical vocabulary and phrases.',
                'is_top_level': False,
                'level_type': 'vocabulary'
            }
        )[0]
        
        special_vocab = Level.objects.get_or_create(
            slug='special-vocabulary',
            defaults={
                'name': 'Special Vocabulary',
                'title': 'Specialized Medical Vocabulary',
                'description': 'Learn and practice specialized medical vocabulary for different medical fields.',
                'is_top_level': False,
                'level_type': 'vocabulary'
            }
        )[0]
        
        # Create main levels
        default_levels = [
            {
                'name': 'Level 1',
                'title': 'Medical Vocabulary',
                'description': 'Learn and practice essential medical vocabulary and phrases.',
                'slug': 'level-1',
                'is_top_level': True,
                'level_type': 'vocabulary',
                'sublevels': [general_vocab, special_vocab]
            },
            {
                'name': 'Level 2',
                'title': 'Guided Clinical Cases',
                'description': 'Practice structured doctor-patient interactions with predefined questions.',
                'slug': 'level-2',
                'is_top_level': True,
                'level_type': 'guided_case'
            },
            {
                'name': 'Level 3',
                'title': 'Complex Clinical Cases',
                'description': 'Engage in open-ended medical consultations with AI-powered patient responses.',
                'slug': 'level-3',
                'is_top_level': True,
                'level_type': 'complex_case'
            }
        ]
        
        for level_data in default_levels:
            level, created = Level.objects.get_or_create(
                slug=level_data['slug'],
                defaults={
                    'name': level_data['name'],
                    'title': level_data['title'],
                    'description': level_data['description'],
                    'is_top_level': level_data['is_top_level'],
                    'level_type': level_data['level_type']
                }
            )
            
            if level.slug == 'level-1' and created:
                level.sublevels.set(level_data['sublevels'])

    def populate_specialties(self):
        self.stdout.write('Populating specialties...')
        
        categories = {
            'Primary Care': [
                {
                    'name': 'Emergency Doctor',
                    'description': 'Practice medical English for emergency medicine scenarios'
                },
                {
                    'name': 'General Practitioner',
                    'description': 'Practice medical English for general practice consultations'
                },
                {
                    'name': 'Pediatrician',
                    'description': 'Practice medical English for pediatric care'
                }
            ],
            'Medical Specialists': [
                {
                    'name': 'Cardiologist',
                    'description': 'Practice medical English for cardiovascular conditions'
                },
                {
                    'name': 'Pulmonologist',
                    'description': 'Practice medical English for respiratory conditions'
                },
                {
                    'name': 'Neurologist',
                    'description': 'Practice medical English for neurological conditions'
                },
                {
                    'name': 'Orthopedist',
                    'description': 'Practice medical English for musculoskeletal conditions'
                }
            ],
            'Surgical Specialists': [
                {
                    'name': 'Ophthalmologist',
                    'description': 'Practice medical English for eye conditions'
                },
                {
                    'name': 'Dentist',
                    'description': 'Practice medical English for dental procedures'
                }
            ],
            'Healthcare Support': [
                {
                    'name': 'Pharmacist',
                    'description': 'Practice medical English for medication management'
                },
                {
                    'name': 'Pathologist',
                    'description': 'Practice medical English for laboratory diagnostics'
                },
                {
                    'name': 'Nurse',
                    'description': 'Practice medical English for nursing care'
                },
                {
                    'name': 'Anesthesiologist',
                    'description': 'Practice medical English for anesthesia care'
                }
            ]
        }

        for category_name, specialties in categories.items():
            category_slug = category_name.lower().replace(' ', '-')
            
            category, _ = Category.objects.get_or_create(
                name=category_name,
                defaults={
                    'slug': category_slug
                }
            )
            
            for specialty_data in specialties:
                specialty_slug = specialty_data['name'].lower().replace(' ', '-')
                
                Speciality.objects.get_or_create(
                    name=specialty_data['name'],
                    defaults={
                        'description': specialty_data['description'],
                        'category': category,
                        'slug': specialty_slug
                    }
                )