from django.core.management.base import BaseCommand
from django.core.management import call_command
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Initialize all data for the application including practice, guided practice, complex practice data, and OET data'

    def add_arguments(self, parser):
        parser.add_argument(
            '--skip-migrations',
            action='store_true',
            help='Skip running migrations before initializing data',
        )

    def handle(self, *args, **options):
        self.stdout.write('Starting initialization of all data...')
        
        
        # Initialize practice data
        self.stdout.write('Initializing practice data...')
        call_command('initialize_practice_data')
        
        
        # Initialize OET dummy data
        self.stdout.write('Initializing OET dummy data...')
        # call_command('create_dummy_oet_data')

        
        self.stdout.write(self.style.SUCCESS('Successfully initialized all data')) 