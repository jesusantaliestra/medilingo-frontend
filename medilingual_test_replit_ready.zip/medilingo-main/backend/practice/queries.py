import graphene
from graphql import GraphQLError

from complex_practice.utils import generate_clinical_case
from error_codes import ErrorCodes
from .types import (
    LevelType, CategoryType, SpecialityType,
    PatientCaseType
)
from .models import Level, Category, Speciality
from complex_practice.models import PatientCase
from .utils import get_user_speciality_cases

# Define error codes


class PracticeQuery(graphene.ObjectType):
    all_levels = graphene.List(LevelType)
    level = graphene.Field(LevelType, slug=graphene.String(required=True))
    sublevels = graphene.List(LevelType, level_slug=graphene.String(required=True))
    categories = graphene.List(CategoryType)
    category = graphene.Field(CategoryType, slug=graphene.String())
    specialities = graphene.List(SpecialityType)
    user_specialities = graphene.List(SpecialityType)
    speciality = graphene.Field(SpecialityType, slug=graphene.String())
    patient_case = graphene.Field(PatientCaseType, level_slug=graphene.String(), speciality_slug=graphene.String())

    def resolve_all_levels(self, info):
        user = info.context.user
        if not user.is_authenticated:
            raise GraphQLError(
                ErrorCodes.UNAUTHORIZED.message,
                extensions={"code": ErrorCodes.UNAUTHORIZED.code}
            )
        
        if not user.subscription_valid:
            raise GraphQLError(
                ErrorCodes.INVALID_SUBSCRIPTION.message,
                extensions={"code": ErrorCodes.INVALID_SUBSCRIPTION.code}
            )

        return Level.objects.filter(is_top_level=True)
        
    def resolve_level(self, info, slug):
        try:
            return Level.objects.get(slug=slug)
        except Level.DoesNotExist:
            return None
            
    def resolve_sublevels(self, info, level_slug):
        try:
            level = Level.objects.get(slug=level_slug)
            return level.sublevels.all()
        except Level.DoesNotExist:
            return None

    def resolve_categories(self, info):
        return Category.objects.all()

    def resolve_category(self, info, slug):
        return Category.objects.get(slug=slug)

    def resolve_specialities(self, info):
        # user = info.context.user
        # if not user.is_authenticated:
        return Speciality.objects.all()
        # else:
        #     return Speciality.objects.filter(
        #         category=user.category
        #     )

    def resolve_user_specialities(self, info):
        user = info.context.user
        if not user.is_authenticated:
            return Speciality.objects.none()
        else:
            return Speciality.objects.filter(category=user.category)

    

    def resolve_speciality(self, info, slug):
        return Speciality.objects.get(slug=slug)

    def resolve_patient_case(self, info, level_slug=None, speciality_slug=None):
        if not info.context.user.is_authenticated:
            return PatientCase.objects.none()
        
        user_speciality = info.context.user.speciality
        if not user_speciality:
            return PatientCase.objects.none()
        
        queryset = PatientCase.objects.filter(speciality=user_speciality)
    
        if level_slug:
            case_instance = queryset.filter(level__slug=level_slug, language=info.context.user.language_to_learn).first()
            if case_instance:
                return case_instance
            else:
                generated_case = generate_clinical_case(
                    level=Level.objects.get(slug=level_slug),
                    language=info.context.user.language_to_learn,
                    speciality=user_speciality
                )
                if generated_case:
                    return generated_case
                else:
                    return None
        return None 