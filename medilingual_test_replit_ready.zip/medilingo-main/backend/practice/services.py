import openai
import requests
import time
from django.conf import settings
import base64
import difflib
import tempfile
import os

class MedicalConversationService:
    def __init__(self):
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        
    def generate_response(self, conversation_history, clinical_case):
        system_prompt = f"""You are a medical patient simulator. You will roleplay as a patient with the following case:
        {clinical_case['description']}
        
        Instructions:
        1. Respond naturally as a patient would, maintaining consistency with the case details.
        2. Keep responses concise but informative.
        3. Always answer the most recent question from the doctor.
        4. Maintain consistency with previous answers.
        5. If asked about something already mentioned, refer to your previous answer.
        6. If the question is unclear, ask for clarification.
        7. Show appropriate emotional responses based on the situation.
        8. Use medical terminology appropriately but explain if needed."""
        
        messages = [{"role": "system", "content": system_prompt}]
        
        # Add conversation history with proper role mapping
        for msg in conversation_history:
            if msg['role'] == 'system':
                continue  # Skip system messages as they're already in the prompt
            role = "assistant" if msg['role'] == 'patient' else "user"
            messages.append({"role": role, "content": msg['content']})
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=messages,
                temperature=0.7,
                max_tokens=150,
                presence_penalty=0.6,  # Encourage diversity in responses
                frequency_penalty=0.6  # Reduce repetition
            )
            return response.choices[0].message.content
        except Exception as e:
            raise Exception(f"Error generating AI response: {str(e)}")

    def generate_voice_response(self, text):
        try:
            response = self.client.audio.speech.create(
                model="tts-1",
                voice="alloy",
                input=text,
                speed=1.0,  # Normal speech rate
                response_format="mp3"  # Use mp3 for faster streaming
            )
            
            # Convert the audio data to base64
            audio_data = base64.b64encode(response.content).decode('utf-8')
            return audio_data
        except Exception as e:
            raise Exception(f"Error generating voice response: {str(e)}")

class SpeechToTextService:
    def __init__(self, language='en'):
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        self.language = language
    def transcribe_audio(self, audio_data):
        try:
            # Decode base64 audio data
            try:
                audio_bytes = base64.b64decode(audio_data)
            except Exception as e:
                raise Exception(f"Failed to decode base64 audio data: {str(e)}")
            
            # Create a temporary file to store the audio
            with tempfile.NamedTemporaryFile(suffix='.webm', delete=False) as temp_file:
                temp_file.write(audio_bytes)
                temp_file_path = temp_file.name
            
            try:
                # Open the audio file and transcribe using Whisper
                with open(temp_file_path, 'rb') as audio_file:
                    transcription = self.client.audio.transcriptions.create(
                        model="whisper-1",
                        file=audio_file,
                        language=self.language,
                        response_format="text",
                        temperature=0.2,  # Lower temperature for faster, more focused transcription
                        prompt="This is a medical conversation. Focus on medical terminology."  # Add context for better accuracy
                    )
                
                # Calculate a confidence score (Whisper doesn't provide one, so we'll use a default high score)
                pronunciation_score = 95
                
                # Generate feedback based on the transcription
                feedback = ["Good pronunciation!", "Clear articulation."]
                
                return {
                    "text": transcription,
                    "score": pronunciation_score,
                    "feedback": feedback
                }
                
            finally:
                # Clean up the temporary file
                os.unlink(temp_file_path)
                
        except Exception as e:
            raise Exception(f"Error in transcription: {str(e)}")

class TranslationService:
    def __init__(self):
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        
    def translate_text(self, text, target_language):
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": f"You are a professional medical translator. Translate the following medical text to {target_language}. Maintain medical terminology accuracy and natural language flow."
                    },
                    {
                        "role": "user",
                        "content": text
                    }
                ],
                temperature=0.3,
                max_tokens=1000
            )
            
            return response.choices[0].message.content.strip()
        except Exception as e:
            raise Exception(f"Translation error: {str(e)}")

class VoiceAccuracyService:
    def __init__(self):
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        
    def test_pronunciation(self, expected_term, audio_data, language='en'):
        try:
            # First, transcribe the audio using AssemblyAI
            speech_service = SpeechToTextService(language=language)
            transcription_result = speech_service.transcribe_audio(audio_data)
            spoken_text = transcription_result["text"].lower()
            expected_term = expected_term.lower()
            
            # Calculate word matching accuracy
            matcher = difflib.SequenceMatcher(None, spoken_text, expected_term)
            matching_accuracy = matcher.ratio() * 100
            
            # Get pronunciation feedback from GPT-4
            feedback_prompt = f"""You are a medical pronunciation expert. Analyze the pronunciation of the medical term.
            Expected term: {expected_term} in {language} language
            Spoken term: {spoken_text} in {language} language
            
            Provide detailed feedback on:
            1. Accuracy of pronunciation
            2. Common mistakes in medical terminology pronunciation
            3. Tips for improvement
            4. Specific syllables or sounds that need work
            
            Keep the feedback constructive and professional."""
            
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": feedback_prompt}
                ],
                temperature=0.3,
                max_tokens=200
            )
            
            pronunciation_feedback = response.choices[0].message.content.strip()
            
            # Calculate overall score (weighted average of matching accuracy and confidence)
            confidence_score = transcription_result.get("score", 0)
            overall_score = (matching_accuracy * 0.6) + (confidence_score * 0.4)
            
            return {
                "spoken_text": spoken_text,
                "matching_accuracy": round(matching_accuracy, 2),
                "pronunciation_score": round(overall_score, 2),
                "feedback": pronunciation_feedback,
                "confidence_score": confidence_score
            }
            
        except Exception as e:
            raise Exception(f"Error in pronunciation testing: {str(e)}") 