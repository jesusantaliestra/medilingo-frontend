from django.db import models
from django_extensions.db.fields import AutoSlugField


class BaseModel(models.Model):
    """Base model with common fields"""
    id = models.AutoField(primary_key=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Created At")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Updated At")

    class Meta:
        abstract = True


class Level(models.Model):
    name = models.CharField(max_length=100, verbose_name="Level Name")
    title = models.CharField(max_length=100, verbose_name="Level Title")
    slug = AutoSlugField(populate_from='name', unique=True, verbose_name="Slug")
    description = models.TextField(verbose_name="Description")
    is_top_level = models.BooleanField(default=False, verbose_name="Is Top Level")
    sublevels = models.ManyToManyField('self', blank=True, verbose_name="Sublevels", related_name='parent_level')
    level_type = models.CharField(max_length=50, choices=[
        ('vocabulary', 'Vocabulary'),
        ('guided_case', 'Guided Case'),
        ('complex_case', 'Complex Case'),
    ], verbose_name="Level Type")

    def __str__(self):
        return f"{self.title} ({self.name})"

    class Meta:
        verbose_name = "Level"
        verbose_name_plural = "Levels"
        ordering = ['name']


class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name="Category Name")
    slug = AutoSlugField(populate_from='name', unique=True, verbose_name="Slug")

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"
        ordering = ['name']


class Speciality(models.Model):
    name = models.CharField(max_length=100, verbose_name="Speciality Name")
    description = models.TextField(verbose_name="Description")
    slug = AutoSlugField(populate_from='name', unique=True, verbose_name="Slug")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='specialities', verbose_name="Category")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.category.name})"

    class Meta:
        verbose_name = "Speciality"
        verbose_name_plural = "Specialities"
        ordering = ['name']