from typing import List, Dict, TypedDict

class Language(TypedDict):
    code: str
    name: str
    native_name: str
    flag_code: str
    origin_country: str

languages_to_learn: List[Language] = [
    {
        "code": "en",
        "name": "English",
        "native_name": "English",
        "flag_code": "us",
        "origin_country": "United States"
    },
    {
        "code": "es",
        "name": "Spanish",
        "native_name": "Español",
        "flag_code": "es",
        "origin_country": "Spain"
    },
    {
        "code": "fr",
        "name": "French",
        "native_name": "Français",
        "flag_code": "fr",
        "origin_country": "France"
    },
    {
        "code": "de",
        "name": "German",
        "native_name": "Deutsch",
        "flag_code": "de",
        "origin_country": "Germany"
    },
    {
        "code": "pt",
        "name": "Portuguese",
        "native_name": "Português",
        "flag_code": "pt",
        "origin_country": "Portugal"
    }
]

# Create a dictionary for O(1) lookups
language_dict: Dict[str, Language] = {lang["code"]: lang for lang in languages_to_learn}


def get_language_native_name_by_code(code: str) -> str:
    """
    Get language native name by its code using dictionary lookup.
    Returns empty string if code not found.
    """
    return language_dict.get(code, {}).get("native_name", "")

