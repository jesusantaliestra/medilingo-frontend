from django.contrib import admin
from django.utils.html import format_html
from .models import Level, Category, Speciality


# Customize admin site
admin.site.site_header = 'MediLingual Administration'
admin.site.site_title = 'MediLingual Admin Portal'
admin.site.index_title = 'Welcome to MediLingual Administration'


@admin.register(Level)
class LevelAdmin(admin.ModelAdmin):
    list_display = ('name', 'title', 'level_type', 'is_top_level', 'slug')
    list_filter = ('level_type', 'is_top_level')
    search_fields = ('name', 'title', 'description')
    filter_horizontal = ('sublevels',)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug')
    search_fields = ('name',)


@admin.register(Speciality)
class SpecialityAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'created_at', 'updated_at')
    list_filter = ('category',)
    search_fields = ('name', 'description')


