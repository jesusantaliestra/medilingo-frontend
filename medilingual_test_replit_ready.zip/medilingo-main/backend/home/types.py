import graphene
from graphene_django import DjangoObjectType
from .models import LegalContent

class LegalContentType(DjangoObjectType):
    class Meta:
        model = LegalContent
        fields = ('id', 'slug', 'title', 'content_type', 'content', 'last_updated') 