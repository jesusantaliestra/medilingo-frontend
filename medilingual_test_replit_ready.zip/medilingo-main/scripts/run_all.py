
import os
import json
import subprocess
from generate_audio_from_dialogue import split_dialogue, generate_audio
from test_generate_listening import generate_listening_content
from upload_to_firebase import merge_audio_segments, upload_to_firebase

# Configuración
PROFESSION = "Medicine"
PART = "A"

# Paso 1: Generar contenido con OpenAI
print("\n🧠 Generando contenido con GPT...")
listening_data = generate_listening_content(profession=PROFESSION, part=PART)
passage_text = listening_data.get("passage", "")
print("✅ Diálogo generado.")

# Paso 2: Crear audios con ElevenLabs
print("\n🎙️ Generando audios con ElevenLabs...")
dialogue = split_dialogue(passage_text)
generate_audio(dialogue)

# Paso 3: Unir segmentos
print("\n🎧 Uniendo segmentos en un solo .mp3...")
final_mp3_path = merge_audio_segments()

# Paso 4: Subir a Firebase
print("\n☁️ Subiendo audio final a Firebase Storage...")
public_url = upload_to_firebase(final_mp3_path, f"oet_tests/oet_listening_{PROFESSION.lower()}_{PART.lower()}.mp3")

# Paso 5: Mostrar resultado final
print("\n🎉 LISTO. Puedes escuchar el audio aquí:")
print(public_url)
