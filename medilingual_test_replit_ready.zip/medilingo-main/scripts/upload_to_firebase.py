
import os
import firebase_admin
from firebase_admin import credentials, storage
from pydub import AudioSegment

from dotenv import load_dotenv
load_dotenv()

# Cargar credenciales
cred_path = os.getenv("FIREBASE_CREDENTIALS")
bucket_name = os.getenv("FIREBASE_BUCKET")

if not firebase_admin._apps:
    cred = credentials.Certificate(cred_path)
    firebase_admin.initialize_app(cred, {"storageBucket": bucket_name})

def merge_audio_segments(folder="output_audio", output_file="final_output/final_audio.mp3"):
    os.makedirs("final_output", exist_ok=True)
    combined = AudioSegment.empty()

    segment_files = sorted(
        [f for f in os.listdir(folder) if f.endswith(".mp3")],
        key=lambda x: int(x.split("_")[1].split(".")[0])
    )

    for f in segment_files:
        segment = AudioSegment.from_mp3(os.path.join(folder, f))
        combined += segment

    combined.export(output_file, format="mp3")
    print(f"✅ Audio final creado: {output_file}")
    return output_file

def upload_to_firebase(filepath, destination_name=None):
    bucket = storage.bucket()
    blob = bucket.blob(destination_name or os.path.basename(filepath))
    blob.upload_from_filename(filepath)
    blob.make_public()
    print(f"✅ Subido a Firebase: {blob.public_url}")
    return blob.public_url

if __name__ == "__main__":
    final_mp3 = merge_audio_segments()
    upload_to_firebase(final_mp3, "oet_tests/oet_listening_test_001.mp3")
