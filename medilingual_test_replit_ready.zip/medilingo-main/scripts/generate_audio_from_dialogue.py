
import os
import requests
import time
import random

ELEVEN_API_KEY = os.getenv("ELEVEN_API_KEY", "sk_...")  # Sustituye si no usas .env

# Voces británicas realistas de ElevenLabs disponibles
VOICES = {
    "female": ["Rachel", "Bella"],
    "male": ["Josh", "Antoni"]
}

VOICE_IDS = {
    "Rachel": "21m00Tcm4TlvDq8ikWAM",
    "Bella": "EXAVITQu4vr4xnSDxMaL",
    "Josh": "TxGEqnHWrfWFTfGW9XjX",
    "Antoni": "ErXwobaYiN019PkySvjV"
}

def get_voice_id(name):
    return VOICE_IDS.get(name)

def synthesize(text, voice_id, output_path):
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    headers = {
        "xi-api-key": ELEVEN_API_KEY,
        "Content-Type": "application/json"
    }
    payload = {
        "text": text,
        "model_id": "eleven_monolingual_v1",
        "voice_settings": {"stability": 0.7, "similarity_boost": 0.8}
    }

    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        with open(output_path, "wb") as f:
            f.write(response.content)
        print(f"✅ Audio guardado en: {output_path}")
    else:
        print("❌ Error:", response.text)

def split_dialogue(passage_text):
    # Divide en líneas tipo "Doctor: ..." y "Patient: ..."
    lines = passage_text.strip().split("\n")
    dialogue = []
    for line in lines:
        if ":" in line:
            speaker, content = line.split(":", 1)
            dialogue.append((speaker.strip(), content.strip()))
    return dialogue

def generate_audio(dialogue, output_folder="output_audio"):
    os.makedirs(output_folder, exist_ok=True)

    used_voices = {
        "Doctor": random.choice(VOICES["male"]),
        "Patient": random.choice(VOICES["female"])
    }

    print(f"🗣️ Voces asignadas: Doctor → {used_voices['Doctor']} | Patient → {used_voices['Patient']}")

    audio_segments = []

    for i, (speaker, sentence) in enumerate(dialogue):
        voice = used_voices.get(speaker, "Josh")
        voice_id = get_voice_id(voice)
        segment_path = os.path.join(output_folder, f"segment_{i+1:02d}.mp3")
        print(f"🎤 Generando segmento {i+1}: {speaker} dice: {sentence}")
        synthesize(sentence, voice_id, segment_path)
        audio_segments.append(segment_path)
        time.sleep(1.2)  # Para evitar throttling

    print("✅ Todos los segmentos generados. Usa ffmpeg o pydub para unirlos si deseas un solo archivo.")

if __name__ == "__main__":
    # Texto de ejemplo generado por GPT
    sample_passage = """Doctor: Good morning, I’m Dr Smith. What brings you in today?
Patient: I’ve been having chest pains for the past few days.
Doctor: Can you describe the pain? Is it sharp or dull?
Patient: It’s a dull ache, and it gets worse when I breathe deeply.
Doctor: Any other symptoms like fever, cough, or shortness of breath?
Patient: Yes, I’ve had a bit of a cough and I feel a little feverish."""

    dialogue = split_dialogue(sample_passage)
    generate_audio(dialogue)
