
import os
import json
from openai import OpenAI

# Asegúrate de que esta API Key esté disponible en tu entorno
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "sk-...")

client = OpenAI(api_key=OPENAI_API_KEY)

QUESTION_COUNTS = {
    "A": 24,
    "B": 6,
    "C": 12
}

OPTION_COUNTS = {
    "A": 0,
    "B": 3,
    "C": 4
}

QUESTION_TYPES = {
    "A": "FILL",
    "B": "MCQ",
    "C": "MCQ"
}

def generate_listening_content(profession: str, part: str) -> dict:
    num_questions = QUESTION_COUNTS.get(part, 5)
    options_count = OPTION_COUNTS.get(part, 4)
    question_type = QUESTION_TYPES.get(part, "MCQ")

    prompt = f"""Generate an OET Listening Part {part} test for {profession} professionals.
- Use British English.
- The passage should be realistic and healthcare-related.
- Write a natural conversation between a healthcare professional and a patient.
- Alternate turns like 'Doctor:' and 'Patient:'.

Include:
1. A title
2. The full passage (to be used for audio)
3. {num_questions} questions of type {question_type}
   {'Each question should have ' + str(options_count) + ' options.' if options_count else 'Each question should expect a fill-in-the-blank answer.'}

Format your response in JSON:
{{
  "title": "string",
  "passage": "string",
  "questions": [
    {{
      "question_text": "string",
      {"\"options\": [\"A\", \"B\", \"C\", \"D\"]," if options_count else ""}
      "correct_answer": "string",
      "explanation": "string",
      "time_marker": int
    }}
  ]
}}
"""

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are an expert in OET exam content."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )

    try:
        result = json.loads(response.choices[0].message.content)
        print(json.dumps(result, indent=2))
    except Exception as e:
        print("❌ Error:", e)

if __name__ == "__main__":
    # Cambia estos valores para probar diferentes profesiones y partes
    generate_listening_content(profession="Medicine", part="B")
