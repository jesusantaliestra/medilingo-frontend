import React, { useState } from 'react';
import { Globe, Check, Search, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import Navbar from './components/Navbar';
import { languages, Language, getLanguageInfo } from './config/languages';
import { useMutation } from '@apollo/client';
import { UPDATE_USER_LANGUAGE } from './graphql/mutations';
import { toast } from 'react-toastify';

export default function ChooseLanguage({ onLanguageSelect, onLogout }) {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [updateUserLanguage] = useMutation(UPDATE_USER_LANGUAGE);
  
  // Initialize selected language from cookies or default to null
  const [selectedLanguage, setSelectedLanguage] = useState<Language | null>(() => {
    try {
      const savedLanguageCode = Cookies.get('current_language');
      if (savedLanguageCode) {
        const language = getLanguageInfo(savedLanguageCode);
        if (language) return language;
      }
      // If no language is set in cookies, return null
      return null;
    } catch (error) {
      console.error('Error reading language from cookie:', error);
      return null;
    }
  });

  // Filter languages based on search query
  const filteredLanguages = languages.filter(lang => 
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleLanguageSelect = async (language: Language) => {
    try {
      const { data } = await updateUserLanguage({
        variables: { language: language.code }
      });

      if (data?.updateUserLanguage?.success) {
        setSelectedLanguage(language);
        // Save only the language code to cookies
        Cookies.set('current_language', language.code, { expires: 365 }); // Expires in 1 year
        if (onLanguageSelect) {
          onLanguageSelect(language.code); // Pass only the language code
        }
        toast.success('Language updated successfully!');
      }
    } catch (error) {
      console.error('Error updating language:', error);
      toast.error('Failed to update language. Please try again.');
    }
  };

  const handleContinue = () => {
    // Navigate to level chooser page only when continue button is clicked
    navigate('/levelchooser');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} title="MediLingual" />

      <main className="flex-grow flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8 mt-16">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-3">
              <Globe className="h-12 w-12" style={{color: 'var(--color-primary)'}} />
            </div>
            <h2 className="text-3xl font-bold" style={{background: 'var(--color-background-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
              Select Your Native Language
            </h2>
            <p className="text-gray-600 mt-2">
              Choose the language you're most comfortable with
            </p>
          </div>

          {/* Search box */}
          <div className="mb-6">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5" style={{color: 'var(--color-primary)'}} />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition-colors duration-200"
                placeholder="Search languages..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          {/* Language grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredLanguages.map((language) => (
              <div
                key={language.code}
                className={`relative p-4 rounded-xl border-2 cursor-pointer transition-all duration-200 ${
                  selectedLanguage?.code === language.code
                    ? 'border-primary shadow-lg'
                    : 'border-gray-200 hover:border-primary hover:shadow-md'
                }`}
                onClick={() => handleLanguageSelect(language)}
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                    <img
                      src={`https://flagcdn.com/w20/${language.flagCode}.png`}
                      alt={`${language.name} flag`}
                      className="w-6 h-4"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{language.name}</h3>
                    <p className="text-sm text-gray-500">{language.nativeName}</p>
                  </div>
                </div>
                {selectedLanguage?.code === language.code && (
                  <div className="absolute top-2 right-2">
                    <Check className="h-5 w-5" style={{color: 'var(--color-primary)'}} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {filteredLanguages.length === 0 && (
            <div className="text-center py-12">
              <div className="flex flex-col items-center text-gray-500">
                <Search className="h-12 w-12 text-gray-300 mb-3" />
                <p className="text-lg">No languages found for "<span className="font-medium">{searchQuery}</span>"</p>
              </div>
            </div>
          )}

          <div className="mt-8 text-center">
            <button
              type="button"
              className={`inline-flex items-center px-6 py-3 text-white font-medium rounded-xl shadow-md transition-all duration-300 transform ${
                selectedLanguage ? 'hover:shadow-lg hover:-translate-y-0.5' : 'opacity-50 cursor-not-allowed'
              }`}
              style={{
                background: 'var(--color-background-gradient)',
                border: 'none'
              }}
              onClick={handleContinue}
              disabled={!selectedLanguage}
            >
              {selectedLanguage ? `Continue with ${selectedLanguage.name}` : 'Select a language to continue'}
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
            <p className="text-xs text-center text-gray-500 mt-3">
              You can change your language anytime in settings
            </p>
          </div>
        </div>
      </main>

      <footer className="bg-white py-4 text-center text-sm text-gray-500">
        © 2025 MediLingual. All rights reserved.
      </footer>
    </div>
  );
}

// Helper function to convert country code to flag emoji
function getFlagEmoji(countryCode: string): string {
  const codePoints = countryCode
    .toUpperCase()
    .split('')
    .map(char => 127397 + char.charCodeAt(0));
  
  return String.fromCodePoint(...codePoints);
}

// Enhanced SVG Logo Component
function MediLingualLogo({ className }: { className: string }) {
  return (
    <svg className={className} viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#2A9D8F" />
          <stop offset="100%" stopColor="#6C63FF" />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="5" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>
      <circle cx="100" cy="100" r="90" fill="white" />
      
      {/* Medical Cross Symbol */}
      <rect x="60" y="90" width="80" height="20" rx="10" fill="url(#logoGradient)" />
      <rect x="90" y="60" width="20" height="80" rx="10" fill="url(#logoGradient)" />
      
      {/* Sound Wave Element (representing pronunciation) */}
      <path 
        d="M60,100 Q70,80 80,100 Q90,120 100,100 Q110,80 120,100 Q130,120 140,100" 
        stroke="url(#logoGradient)" 
        strokeWidth="8" 
        strokeLinecap="round" 
        fill="none" 
        filter="url(#glow)"
      />
      
      {/* Circular Elements */}
      <circle cx="70" cy="70" r="8" fill="#2A9D8F" />
      <circle cx="130" cy="70" r="8" fill="#6C63FF" />
      <circle cx="70" cy="130" r="8" fill="#6C63FF" />
      <circle cx="130" cy="130" r="8" fill="#2A9D8F" />
    </svg>
  );
}