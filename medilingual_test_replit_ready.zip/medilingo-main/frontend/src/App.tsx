import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ApolloProvider } from '@apollo/client';
import { ApolloClient } from './ApolloClient';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import OETPage from './pages/OETPage';
import OETProgressReport from './pages/OETProgressReport';
import OETReadingTest from './routes/oet/OETReadingTest';
import OETReadingResults from './routes/oet/results/OETReadingResults';
import OETWritingTest from './routes/oet/OETWritingTest';
import OETWritingResults from './routes/oet/results/OETWritingResults';
import OETSpeakingTest from './routes/oet/OETSpeakingTest';
import OETSpeakingResults from './routes/oet/results/OETSpeakingResults';
import OETListeningTest from './routes/oet/OETListeningTest';
import OETListeningResults from './routes/oet/results/OETListeningResults';
import { useAuth } from './contexts/AuthContext';

function App() {
  const { isAuthenticated, handleLogout } = useAuth();

  return (
    <ApolloProvider client={ApolloClient}>
      <Router>
        <Routes>
          <Route path="/login" element={!isAuthenticated ? <Login /> : <Navigate to="/dashboard" />} />
          <Route path="/register" element={!isAuthenticated ? <Register /> : <Navigate to="/login" />} />
          <Route path="/dashboard" element={isAuthenticated ? <Dashboard onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet" element={isAuthenticated ? <OETPage onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/progress" element={isAuthenticated ? <OETProgressReport onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/reading/test/:progressId" element={isAuthenticated ? <OETReadingTest onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/reading/results/:progressId" element={isAuthenticated ? <OETReadingResults onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/writing/test/:progressId" element={isAuthenticated ? <OETWritingTest onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/writing/results/:progressId" element={isAuthenticated ? <OETWritingResults onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/speaking/test/:progressId" element={isAuthenticated ? <OETSpeakingTest onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/speaking/results/:progressId" element={isAuthenticated ? <OETSpeakingResults onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/listening/test/:progressId" element={isAuthenticated ? <OETListeningTest onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/oet/listening/results/:progressId" element={isAuthenticated ? <OETListeningResults onLogout={handleLogout} /> : <Navigate to="/login" />} />
          <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} />} />
        </Routes>
      </Router>
    </ApolloProvider>
  );
}

export default App; 