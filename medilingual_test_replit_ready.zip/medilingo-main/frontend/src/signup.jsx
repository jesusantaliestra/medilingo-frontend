import React, { useState, useEffect } from 'react';
import { ChevronRight, Mail, Lock, User, Phone, Globe, Stethoscope, Check, Mic, BookOpen, Award, ArrowRight, Eye, EyeOff, ChevronDown, MessageSquare, Search } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery } from '@apollo/client';
import { SIGNUP_MUTATION } from './graphql/mutations';
import { GET_SPECIALITIES } from './graphql/queries';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';
import { theme } from './theme/theme';
import './styles/theme.css';
import { languages, detectUserLanguage, languageToLearn } from './config/languages';
import AuthSidebar from './components/AuthSidebar';

export default function Signup({ onLogin }) {
  const [showPassword, setShowPassword] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [currentStep, setCurrentStep] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [selectedSpeciality, setSelectedSpeciality] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    password: '',
    speciality: '',
    language: '',
    languageToLearn: '',
    phoneNumber: '',
    acceptTerms: false
  });

  const { data: specialitiesData, loading: specialitiesLoading } = useQuery(GET_SPECIALITIES);
  const [signup, { loading: signupLoading }] = useMutation(SIGNUP_MUTATION);

  // Rotate testimonials automatically
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial(prev => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm({
      ...form,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleLanguageSelect = (language) => {
    setSelectedLanguage(language);
    setForm(prev => ({ ...prev, language: language.code }));
  };

  const handleLanguageUnselect = () => {
    setSelectedLanguage(null);
    setForm(prev => ({ ...prev, language: '' }));
  };

  useEffect(() => {
    const detectLanguage = async () => {
      try {
        const { language } = await detectUserLanguage();
        handleLanguageSelect(language)

      } catch (error) {
        console.error('Error detecting user language:', error);
      }
    };
    detectLanguage();
  }, []);

  const handleSpecialitySelect = (speciality) => {
    setSelectedSpeciality(speciality);
    setForm(prev => ({ ...prev, speciality: speciality.id }));
  };

  const handleLanguageToLearnSelect = (language) => {
    setForm(prev => ({ ...prev, languageToLearn: language.code }));
  };

  const handleNextStep = () => {
    if (currentStep === 1) {
      // Validate basic info and terms acceptance
      if (!form.fullName || !form.email || !form.password) {
        toast.error('Please fill in all required fields');
        return;
      }
      if (!form.acceptTerms) {
        toast.error('Please accept the Terms and Conditions to continue');
        return;
      }
    } else if (currentStep === 2) {
      // Validate language selection
      if (!form.language) {
        toast.error('Please select a language');
        return;
      }
    } else if (currentStep === 3) {
      // Validate language to learn selection
      if (!form.languageToLearn) {
        toast.error('Please select a language to learn');
        return;
      }
    } else if (currentStep === 4) {
      // Validate category selection
      if (!selectedCategory) {
        toast.error('Please select a category');
        return;
      }
    }
    setCurrentStep(currentStep + 1);
  };

  const handlePreviousStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Only proceed with API call if we're on the final step
    if (currentStep !== 5) {
      return;
    }

    // Validate all required fields
    if (!form.fullName || !form.email || !form.password || !form.language || !form.languageToLearn || !form.speciality || !form.acceptTerms) {
      toast.error('Please fill in all required fields and accept the terms and conditions');
      return;
    }
    
    try {
      const { data } = await signup({
        variables: {
          email: form.email,
          password: form.password,
          fullName: form.fullName,
          speciality: form.speciality,
          language: form.language,
          languageToLearn: form.languageToLearn,
          phoneNumber: form.phoneNumber || null
        }
      });

      if (data?.signup?.login?.token) {
        // Store tokens in cookies
        Cookies.set('accessToken', data.signup.login.token.access, { expires: data.signup.login.token.expiresIn / 86400 });
        Cookies.set('refreshToken', data.signup.login.token.refresh, { expires: data.signup.login.token.refreshExpiresIn / 86400 });

        // Set language cookies
        Cookies.set('current_language', form.language, { expires: 365 });
        Cookies.set('accept-language', form.languageToLearn, { expires: 365 });

        // Call onLogin callback with user data
        if (onLogin) {
          onLogin({
            ...data.signup.login.user,
            isNewUser: true
          });
        }

        // Show success toast
        toast.success('Account created successfully! Welcome to MediLingual.');

        // Navigate to level chooser
        navigate('/levelchooser');
      }
    } catch (error) {
      toast.error(error.message || 'Signup failed. Please try again.');
    }
  };
  
  // Filter languages based on search query
  const filteredLanguages = languages.filter(lang => 
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    lang.nativeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filter specialties based on search query
  const filteredSpecialities = specialitiesData?.specialities?.filter(speciality => 
    speciality.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    speciality.description.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Group filtered specialties by category
  const groupedFilteredSpecialities = filteredSpecialities.reduce((acc, speciality) => {
    const categoryName = speciality.category.name;
    if (!acc[categoryName]) {
      acc[categoryName] = [];
    }
    acc[categoryName].push(speciality);
    return acc;
  }, {}) || {};

  // Learning features for promotional display
  const features = [
    {
      icon: <BookOpen className="text-white" size={24} />,
      title: "Medical Vocabulary",
      description: "Learn specialized terminology for patient consultations and clinical practice"
    },
    {
      icon: <Mic className="text-white" size={24} />,
      title: "AI Pronunciation Feedback",
      description: "Perfect your medical English with real-time pronunciation assessment"
    },
    {
      icon: <Stethoscope className="text-white" size={24} />,
      title: "Clinical Case Studies",
      description: "Practice with realistic patient scenarios in a risk-free environment"
    },
    {
      icon: <MessageSquare className="text-white" size={24} />,
      title: "Patient Communication",
      description: "Master effective communication techniques for diverse patient interactions"
    },
    {
      icon: <Award className="text-white" size={24} />,
      title: "Achievement System",
      description: "Track your progress with gamified learning goals and personalized rewards"
    }
  ];

  const testimonials = [
    {
      quote: "MediLingual transformed my confidence when speaking with international patients. The AI pronunciation feedback is incredibly helpful.",
      name: "Dr. Maria Rodriguez",
      title: "Cardiologist",
      country: "Spain",
      avatar: "MR"
    },
    {
      quote: "The clinical scenarios are exactly like my daily interactions. I've improved so much in just two months.",
      name: "Nurse Takashi Yamamoto",
      title: "Emergency Room Nurse",
      country: "Japan",
      avatar: "TY"
    },
    {
      quote: "As a non-native English speaker, MediLingual has been invaluable in helping me communicate precisely with patients and colleagues.",
      name: "Dr. Elena Petrov",
      title: "Neurologist",
      country: "Russia",
      avatar: "EP"
    }
  ];

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  name="fullName"
                  value={form.fullName}
                  onChange={handleInputChange}
                  className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter your full name"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleInputChange}
                  className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter your email"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number (Optional)</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="tel"
                  name="phoneNumber"
                  value={form.phoneNumber}
                  onChange={handleInputChange}
                  className="block w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter your phone number"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={form.password}
                  onChange={handleInputChange}
                  className="block w-full pl-10 pr-10 py-2.5 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Create a password"
                  required
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="terms"
                  name="acceptTerms"
                  type="checkbox"
                  checked={form.acceptTerms}
                  onChange={handleInputChange}
                  className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                  required
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="terms" className="font-medium text-gray-700">
                  I accept the{' '}
                  <a
                    href="/legal/terms-conditions"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:text-primary-dark underline"
                  >
                    Terms and Conditions
                  </a>
                </label>
              </div>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-2">
                <Globe className="h-8 w-8" style={{color: 'var(--color-primary)'}} />
              </div>
              <h2 className="text-2xl font-bold" style={{background: 'var(--color-background-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
                Select Your Native Language
              </h2>
              <p className="text-gray-600 mt-1 text-sm">
                Choose the language you're most comfortable with
              </p>
              
              {selectedLanguage && (
                <div className="mt-3 flex justify-center">
                  <div className="inline-flex items-center px-3 py-1.5 bg-primary bg-opacity-10 rounded-lg border border-primary border-opacity-30">
                    <img
                      src={`https://flagcdn.com/w20/${selectedLanguage.flagCode}.png`}
                      alt={`${selectedLanguage.name} flag`}
                      className="w-5 h-3.5 mr-2"
                    />
                    <span className="text-sm font-medium" style={{color: 'var(--color-primary)'}}>
                      {selectedLanguage.name} ({selectedLanguage.nativeName})
                    </span>
                    <button
                      onClick={handleLanguageUnselect}
                      className="ml-2 p-1 rounded-full hover:bg-primary hover:bg-opacity-20 transition-colors duration-200"
                      aria-label="Unselect language"
                    >
                      <svg
                        className="w-4 h-4"
                        style={{color: 'var(--color-primary)'}}
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </button>
                  </div>
                </div>
              )}
            </div>

            

            {/* Search box */}
            <div className="mb-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                </div>
                <input
                  type="text"
                  className="block w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors duration-200"
                  placeholder="Search languages..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {/* Language grid */}
            <div className="space-y-6 max-h-[400px] overflow-y-auto pr-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {filteredLanguages.map((language) => (
                  <div
                    key={language.code}
                    className={`relative p-3 rounded-lg border cursor-pointer transition-all duration-200 h-full ${
                      selectedLanguage?.code === language.code
                        ? 'border-primary shadow-sm'
                        : 'border-gray-200 hover:border-primary hover:shadow-sm'
                    }`}
                    onClick={() => handleLanguageSelect(language)}
                  >
                    <div className="flex items-center">
                      <div className="flex-shrink-0 w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center mr-2">
                        <img
                          src={`https://flagcdn.com/w20/${language.flagCode}.png`}
                          alt={`${language.name} flag`}
                          className="w-5 h-3.5"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-gray-900">{language.name}</p>
                        <p className="text-xs text-gray-500">{language.nativeName}</p>
                      </div>
                    </div>
                    {selectedLanguage?.code === language.code && (
                      <div className="absolute top-1.5 right-1.5">
                        <Check className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-2">
                <Globe className="h-8 w-8" style={{color: 'var(--color-primary)'}} />
              </div>
              <h2 className="text-2xl font-bold" style={{background: 'var(--color-background-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
                Select Language to Learn
              </h2>
              <p className="text-gray-600 mt-1 text-sm">
                Choose the language you want to learn
              </p>
            </div>

            <div className="space-y-6 max-h-[400px] overflow-y-auto pr-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {languageToLearn.map((language) => (
                  <div
                    key={language.code}
                    className={`relative p-3 rounded-lg border cursor-pointer transition-all duration-200 h-full ${
                      form.languageToLearn === language.code
                        ? 'border-primary shadow-sm'
                        : 'border-gray-200 hover:border-primary hover:shadow-sm'
                    }`}
                    onClick={() => handleLanguageToLearnSelect(language)}
                  >
                    <div className="flex items-center">
                      <div className="flex-shrink-0 w-7 h-7 rounded-full bg-gray-100 flex items-center justify-center mr-2">
                        <img
                          src={`https://flagcdn.com/w20/${language.flagCode}.png`}
                          alt={`${language.name} flag`}
                          className="w-5 h-3.5"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-gray-900">{language.name}</p>
                        <p className="text-xs text-gray-500">{language.nativeName}</p>
                      </div>
                    </div>
                    {form.languageToLearn === language.code && (
                      <div className="absolute top-1.5 right-1.5">
                        <Check className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-2">
                <Stethoscope className="h-8 w-8" style={{color: 'var(--color-primary)'}} />
              </div>
              <h2 className="text-2xl font-bold" style={{background: 'var(--color-background-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
                Select Your Medical Category
              </h2>
              <p className="text-gray-600 mt-1 text-sm">
                Choose your medical field category
              </p>
            </div>

            {/* Search box */}
            <div className="mb-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                </div>
                <input
                  type="text"
                  className="block w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors duration-200"
                  placeholder="Search categories..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-6 max-h-[400px] overflow-y-auto pr-1">
              {Object.keys(groupedFilteredSpecialities).map((category) => (
                <div
                  key={category}
                  className={`relative p-3.5 rounded-lg border cursor-pointer transition-all duration-200 h-full ${
                    selectedCategory === category
                      ? 'border-primary shadow-sm'
                      : 'border-gray-200 hover:border-primary hover:shadow-sm'
                  }`}
                  onClick={() => setSelectedCategory(category)}
                >
                  <h3 className="font-medium text-sm text-gray-900 pr-5">{category}</h3>
                  {selectedCategory === category && (
                    <div className="absolute top-1.5 right-1.5">
                      <Check className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      case 5:
        return (
          <div className="space-y-6">
            <div className="text-center mb-6">
              <div className="flex justify-center mb-2">
                <Stethoscope className="h-8 w-8" style={{color: 'var(--color-primary)'}} />
              </div>
              <h2 className="text-2xl font-bold" style={{background: 'var(--color-background-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent'}}>
                Select Your Medical Specialty
              </h2>
              <p className="text-gray-600 mt-1 text-sm">
                Choose your specific area of medical practice
              </p>
            </div>

            {/* Search box */}
            <div className="mb-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                </div>
                <input
                  type="text"
                  className="block w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors duration-200"
                  placeholder="Search specialties..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-6 max-h-[400px] overflow-y-auto pr-1">
              {groupedFilteredSpecialities[selectedCategory]?.map((speciality) => (
                <div
                  key={speciality.id}
                  className={`relative p-3.5 rounded-lg border cursor-pointer transition-all duration-200 h-full ${
                    selectedSpeciality?.id === speciality.id
                      ? 'border-primary shadow-sm'
                      : 'border-gray-200 hover:border-primary hover:shadow-sm'
                  }`}
                  onClick={() => handleSpecialitySelect(speciality)}
                >
                  <h3 className="font-medium text-sm text-gray-900 pr-5">{speciality.name}</h3>
                  {selectedSpeciality?.id === speciality.id && (
                    <div className="absolute top-1.5 right-1.5">
                      <Check className="h-4 w-4" style={{color: 'var(--color-primary)'}} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <AuthSidebar />

      {/* Right panel with signup form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-4 sm:p-6 md:p-8">
        <div className="w-full max-w-md bg-white rounded-xl shadow-sm p-6">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-2">Create your account</h2>
            <div className="flex items-center space-x-2">
              {[1, 2, 3, 4, 5].map((step) => (
                <React.Fragment key={step}>
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs ${
                      step === currentStep
                        ? 'bg-primary text-white'
                        : step < currentStep
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}
                  >
                    {step}
                  </div>
                  {step < 5 && (
                    <div
                      className={`h-0.5 w-6 ${
                        step < currentStep ? 'bg-green-500' : 'bg-gray-200'
                      }`}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            {renderStepContent()}

            <div className="flex justify-between pt-4">
              {currentStep > 1 && (
                <button
                  type="button"
                  onClick={handlePreviousStep}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-1 focus:ring-primary"
                >
                  Back
                </button>
              )}
              {currentStep < 5 ? (
                <button
                  type="button"
                  onClick={handleNextStep}
                  className={`${currentStep === 1 ? 'w-full' : ''} px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white focus:outline-none focus:ring-1 focus:ring-offset-1 focus:ring-primary`}
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none'
                  }}
                >
                  Continue
                  <ArrowRight className="inline-block ml-2 h-4 w-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="w-full px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white focus:outline-none focus:ring-1 focus:ring-offset-1 focus:ring-primary"
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none'
                  }}
                  disabled={signupLoading}
                >
                  {signupLoading ? 'Creating Account...' : 'Create Account'}
                  {!signupLoading && <ArrowRight className="inline-block ml-2 h-4 w-4" />}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 