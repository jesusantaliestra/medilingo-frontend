import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useParams, useNavigate } from 'react-router-dom';
import Login from './login';
import Signup from './signup';
import LanguagePicker from './chooseLanguage';
import LevelChooserPage from './components/LevelChooserPage';
import VocabularyPracticeRoute from './routes/practice/VocabularyPracticeRoute';
import GuidedClinicalCaseRoute from './routes/practice/GuidedClinicalCaseRoute';
import ComplexClinicalCaseRoute from './routes/practice/ComplexClinicalCaseRoute';
import OETPage from './pages/OETPage';
import OETProgressReport from './pages/OETProgressReport';
import OETModuleTemplate from './routes/oet/OETModuleTemplate';
import OETReadingTest from './routes/oet/OETReadingTest';
import OETWritingTest from './routes/oet/OETWritingTest';
import OETSpeakingTest from './routes/oet/OETSpeakingTest';
import OETListeningTest from './routes/oet/OETListeningTest';
import OETReadingResults from './routes/oet/results/OETReadingResults';
import OETWritingResults from './routes/oet/results/OETWritingResults';
import OETSpeakingResults from './routes/oet/results/OETSpeakingResults';
import OETListeningResults from './routes/oet/results/OETListeningResults';
import Settings from './pages/Settings';
import Cookies from 'js-cookie';
import { useQuery } from '@apollo/client';
import { gql } from '@apollo/client';
import OETReadingTestSelection from './routes/oet/OETReadingTestSelection';
import ProtectedRoute from './components/ProtectedRoute';
import OETListeningTestSelection from './routes/oet/OETListeningTestSelection';
import Pricing from './pages/Pricing';
import PageWrapper from './components/PageWrapper';
import { setNavigateFunction } from './ApolloClient';
import PrivacyPolicy from './pages/legal/PrivacyPolicy';
import TermsOfService from './pages/legal/TermsOfService';
import CookiePolicy from './pages/legal/CookiePolicy';
import RefundPolicy from './pages/legal/RefundPolicy';
import About from './pages/About';

// Create a wrapper component to access useNavigate
function AppWithNavigation() {
  const navigate = useNavigate();
  
  useEffect(() => {
    // Set the navigation function for Apollo Client
    setNavigateFunction(navigate);
  }, [navigate]);

  return <AppContent />;
}

// Move the main App content to a separate component
function AppContent() {
  const [userLanguage, setUserLanguage] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if user is already authenticated
    const accessToken = Cookies.get('accessToken');
    if (accessToken) {
      setIsAuthenticated(true);
      // Initialize language from cookie if it exists
      const savedLanguage = Cookies.get('current_language');
      const savedLanguageToLearn = Cookies.get('accept-language');
      if (savedLanguage) {
        setUserLanguage(savedLanguage);
      }
      if (savedLanguageToLearn) {
        // You can add state for language to learn if needed
        console.log('Language to learn:', savedLanguageToLearn);
      }
    }
    // Mark loading as complete after state initialization
    setIsLoading(false);
  }, []);

  const handleLanguageSelect = (langCode) => {
    setUserLanguage(langCode);
    // Save language code to cookie
    Cookies.set('current_language', langCode, { expires: 365 }); // Expires in 1 year
    console.log('Selected language code:', langCode);
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setIsAuthenticated(true);
    
    // Set user language if available in user data
    if (userData.language) {
      setUserLanguage(userData.language);
      // Also set the cookie
      Cookies.set('current_language', userData.language, { expires: 365 });
    }
    if (userData.languageToLearn) {
      Cookies.set('accept-language', userData.languageToLearn, { expires: 365 });
    }
  };

  const handleLogout = () => {
    Cookies.remove('accessToken');
    Cookies.remove('refreshToken');
    Cookies.remove('current_language');
    Cookies.remove('accept-language');
    setIsAuthenticated(false);
    setUser(null);
    setUserLanguage(null);
  };

  // Don't render routes while loading initial state
  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
    </div>;
  }

  return (
    <Routes>
      <Route 
        path="/" 
        element={
          isAuthenticated ? 
            <Navigate to="/levelchooser" /> : 
            <Login onLogin={handleLogin} />
        } 
      />
      <Route 
        path="/signup" 
        element={
          isAuthenticated ? 
            <Navigate to="/levelchooser" /> : 
            <Signup onLogin={handleLogin} />
        } 
      />
      <Route 
        path="/choose-language" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <LanguagePicker 
                onLanguageSelect={handleLanguageSelect} 
                onLogout={handleLogout}
              />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/settings" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <Settings onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/pricing" 
        element={
          <PageWrapper onLogout={handleLogout}>
            <Pricing />
          </PageWrapper>
        } 
      />
      <Route 
        path="/oet" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETPage onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/progress" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETProgressReport onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/:moduleType" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETModuleTemplate onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/reading/test/" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETReadingTestSelection onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/reading/test/:part" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETReadingTest onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/writing/test/" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETWritingTest onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/speaking/test/:roleSequence" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETSpeakingTest onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/listening/test/" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETListeningTestSelection onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/listening/test/:part" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETListeningTest onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/reading/results/:tryId" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETReadingResults onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/writing/results/:progressId" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETWritingResults onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/speaking/results/:roleSequence" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETSpeakingResults onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/oet/listening/results/:tryId" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <OETListeningResults onLogout={handleLogout} />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/levelchooser" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <LevelChooserPage 
                nativeLanguage={userLanguage} 
                user={user}
                onLogout={handleLogout}
              />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/level/:levelSlug/practice/:practiceId" 
        element={
          <ProtectedRoute>
            <PageWrapper onLogout={handleLogout}>
              <RouteComponent />
            </PageWrapper>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/legal/privacy-policy" 
        element={
          <PageWrapper onLogout={handleLogout}>
            <PrivacyPolicy />
          </PageWrapper>
        } 
      />
      <Route 
        path="/legal/terms-conditions" 
        element={
          <PageWrapper onLogout={handleLogout}>
            <TermsOfService />
          </PageWrapper>
        } 
      />
      <Route 
        path="/legal/cookie-policy" 
        element={
          <PageWrapper onLogout={handleLogout}>
            <CookiePolicy />
          </PageWrapper>
        } 
      />
      <Route 
        path="/about" 
        element={
          <PageWrapper onLogout={handleLogout}>
            <About />
          </PageWrapper>
        } 
      />
      <Route 
        path="/legal/refund-policy" 
        element={
          <PageWrapper onLogout={handleLogout}>
            <RefundPolicy />
          </PageWrapper>
        } 
      />
    </Routes>
  );
}

function RouteComponent() {
  const { levelSlug, practiceId } = useParams();
  const userLanguage = Cookies.get('current_language');
  const onLogout = () => {
    Cookies.remove('accessToken');
    Cookies.remove('refreshToken');
    Cookies.remove('current_language');
    window.location.href = '/';
  };

  // Query to get level type
  const { data: levelData } = useQuery(gql`
    query GetLevelType($slug: String!) {
      level(slug: $slug) {
        levelType
      }
    }
  `, {
    variables: { slug: levelSlug }
  });

  const levelType = levelData?.level?.levelType;

  // If practiceId is a type (vocabulary, guided, complex), use levelType to determine the component
  if (practiceId === 'vocabulary' || practiceId === 'guided' || practiceId === 'complex') {
    const levelTypeToComponent = {
      'vocabulary': VocabularyPracticeRoute,
      'guided': GuidedClinicalCaseRoute,
      'complex': ComplexClinicalCaseRoute
    };

    const Component = levelTypeToComponent[practiceId];
    if (Component) {
      return <Component 
        nativeLanguage={userLanguage} 
        onLogout={onLogout}
        levelSlug={levelSlug}
      />;
    }
    return <Navigate to="/levelchooser" />;
  }

  // For specific practice items
  const levelTypeToComponent = {
    'vocabulary': VocabularyPracticeRoute,
    'guided': GuidedClinicalCaseRoute,
    'complex': ComplexClinicalCaseRoute
  };

  const Component = levelTypeToComponent[practiceId];
  if (Component) {
    return <Component 
      nativeLanguage={userLanguage} 
      onLogout={onLogout}
      levelSlug={levelSlug}
    />;
  }
  return <Navigate to="/levelchooser" />;
}

// Main App component that provides the Router
function App() {
  return (
    <Router>
      <AppWithNavigation />
    </Router>
  );
}

export { AppWithNavigation };
export default App;
