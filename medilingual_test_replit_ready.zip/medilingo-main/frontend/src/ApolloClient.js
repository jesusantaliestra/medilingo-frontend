import { ApolloClient, InMemoryCache, createHttpLink } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import { onError } from '@apollo/client/link/error';
import ErrorHandler from './utils/errors/ErrorHandler';
import Cookies from 'js-cookie';

// Create a navigation service
let navigateFunction = null;

// Use import.meta.env instead of process.env
export const VITE_MEDILINGUAL_API_URL = import.meta.env.VITE_MEDILINGUAL_API_URL || 'https://api.medilingual.app/graphql/';

const httpLink = createHttpLink({
  uri: VITE_MEDILINGUAL_API_URL,
  credentials: 'include',
});

const authLink = setContext((_, { headers }) => {
  // Get the authentication token from cookies
  const token = Cookies.get('accessToken');
  // Return the headers to the context so httpLink can read them
  return {
    headers: {
      ...headers,
      authorization: token ? `Bearer ${token}` : '',
      'current-language': Cookies.get('current_language') || 'en',
    },
  };
});

// Create error handler instance with navigation function
const errorHandler = new ErrorHandler(navigateFunction);

// Update error handler's navigation function when it changes
export const setNavigateFunction = (navigate) => {
  navigateFunction = navigate;
  errorHandler.setNavigateFunction(navigate);
};

const errorLink = onError(({ graphQLErrors, networkError }) => {
  errorHandler.handleGraphQLErrors(graphQLErrors);
  errorHandler.handleNetworkError(networkError);
});

const client = new ApolloClient({
  link: errorLink.concat(authLink).concat(httpLink),
  cache: new InMemoryCache(),
  defaultOptions: {
    watchQuery: {
      fetchPolicy: 'network-only',
      errorPolicy: 'ignore',
    },
    query: {
      fetchPolicy: 'network-only',
      errorPolicy: 'all',
    },
  },
});

export default client;