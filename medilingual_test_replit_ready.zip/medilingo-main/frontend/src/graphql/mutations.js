import { gql } from '@apollo/client';

export const LOGIN_MUTATION = gql`
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      login {
        user {
          id
          email
          username
          firstName
          lastName
          fullName
          language
          languageToLearn
        }
        token {
          access
          refresh
          expiresIn
          refreshExpiresIn
        }
      }
    }
  }
`;

export const SIGNUP_MUTATION = gql`
  mutation Signup(
    $email: String!
    $password: String!
    $fullName: String!
    $speciality: ID!
    $language: String!
    $languageToLearn: String!
    $phoneNumber: String
  ) {
    signup(
      email: $email
      password: $password
      fullName: $fullName
      speciality: $speciality
      language: $language
      languageToLearn: $languageToLearn
      phoneNumber: $phoneNumber
    ) {
      login {
        user {
          id
          email
          username
          firstName
          lastName
          fullName
          language
          languageToLearn
        }
        token {
          access
          refresh
          expiresIn
          refreshExpiresIn
        }
      }
    }
  }
`;

export const GENERATE_AI_MESSAGE = gql`
  mutation GenerateAiMessage(
    $conversationHistory: [MessageInput!]!
    $clinicalCase: ClinicalCaseInput!
  ) {
    generateAiMessage(
      conversationHistory: $conversationHistory
      clinicalCase: $clinicalCase
    ) {
      response
    }
  }
`;

export const MessageInput = gql`
  input MessageInput {
    role: String!
    content: String!
  }
`;

export const VitalSignsInput = gql`
  input VitalSignsInput {
    bloodPressure: String!
    heartRate: String!
    respiratoryRate: String!
    temperature: String!
  }
`;

export const PatientInfoInput = gql`
  input PatientInfoInput {
    age: Int!
    gender: String!
    chiefComplaint: String!
    history: String!
    vitalSigns: VitalSignsInput!
  }
`;

export const ClinicalCaseInput = gql`
  input ClinicalCaseInput {
    description: String!
    patientInfo: PatientInfoInput!
  }
`;

export const TRANSCRIBE_AUDIO = gql`
  mutation TranscribeAudio($audioData: String!) {
    transcribeAudio(audioData: $audioData) {
      text
      score
      feedback
    }
  }
`;

export const TRANSLATE_TEXT = gql`
  mutation TranslateText($text: String!, $targetLanguage: String!) {
    translateText(text: $text, targetLanguage: $targetLanguage) {
      translatedText
    }
  }
`;

export const TEST_VOCABULARY_PRONUNCIATION = gql`
  mutation TestVocabularyPronunciation($expectedTerm: String!, $audioData: String!, $vocabularyId: ID!) {
    testVocabularyPronunciation(expectedTerm: $expectedTerm, audioData: $audioData, vocabularyId: $vocabularyId) {
      spokenText
      matchingAccuracy
      pronunciationScore
      feedback
      confidenceScore
      vocabularyId
    }
  }
`;

export const GENERATE_VOICE = gql`
  mutation GenerateVoice($text: String!) {
    generateVoice(text: $text) {
      audioData
    }
  }
`;

export const PROCESS_AUDIO_AND_GENERATE_RESPONSE = gql`
  mutation ProcessAudioAndGenerateResponse(
    $audioData: String!
    $conversationHistory: [MessageInput!]!
    $clinicalCase: ClinicalCaseInput!
    $isComplexPractice: Boolean
  ) {
    processAudioAndGenerateResponse(
      audioData: $audioData
      conversationHistory: $conversationHistory
      clinicalCase: $clinicalCase
      isComplexPractice: $isComplexPractice
    ) {
      text
      score
      feedback
      response
      voiceResponse
    }
  }
`;

export const UPDATE_USER_LANGUAGE = gql`
  mutation UpdateUserLanguage($language: String!) {
    updateUserLanguage(language: $language) {
      success
    }
  }
`;

export const UPDATE_LANGUAGE_TO_LEARN = gql`
  mutation UpdateLanguageToLearn($languageToLearn: String!) {
    updateUserLanguageToLearn(languageToLearn: $languageToLearn) {
      success
      message
    }
  }
`;

export const SUBMIT_GUIDED_PRACTICE_ATTEMPT = gql`
  mutation SubmitGuidedPracticeAttempt($guidedGroupId: ID!, $score: Int!) {
    submitGuidedPracticeAttempt(guidedGroupId: $guidedGroupId, score: $score) {
      success
      message
      attempt {
        id
        score
        guidedGroup {
          id
          name
        }
      }
    }
  }
`;

export const MARK_VOCABULARY_TEST_AS_COMPLETED = gql`
  mutation MarkVocabularyTestAsCompleted($vocabularyId: ID!) {
    markVocabularyTestAsCompleted(vocabularyId: $vocabularyId) {
      success
      vocabularyId
    }
  }
`;

export const UPDATE_USER_PROFESSION = gql`
  mutation UpdateUserProfession($profession: String!) {
    updateUserProfession(profession: $profession) {
      success
      message
    }
  }
`; 