import { gql } from '@apollo/client';

export const GET_SPECIALITIES = gql`
  query GetSpecialities {
    specialities {
      id
      name
      description
      slug
      category {
        id
        name
      }
    }
  }
`;

export const GET_AVAILABLE_VOCABULARY_ITEM = gql`
  query GetAvailableVocabularyItem($levelSlug: String!) {
    availableVocabularyItems(levelSlug: $levelSlug) {
      vocabularyItem {
        id
        term
        definition
        speciality {
          name
        }
        level {
          name
        }
      }
      statistics {
        completedCount
        totalCount
        remainingCount
        completionPercentage
      }
    }
  }
`; 