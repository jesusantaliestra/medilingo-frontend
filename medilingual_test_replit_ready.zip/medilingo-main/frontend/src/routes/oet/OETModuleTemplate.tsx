import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Navbar from '../../components/Navbar';
import { ArrowLeft, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { useMutation } from '@apollo/client';
import { gql } from '@apollo/client';

const CREATE_USER_PROGRESS = gql`
  mutation CreateUserProgress($sectionType: String!) {
    createUserProgress(sectionType: $sectionType) {
      success
      userProgressId
      message
    }
  }
`;

interface OETModuleTemplateProps {
  onLogout: () => void;
}

const OETModuleTemplate: React.FC<OETModuleTemplateProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { moduleType } = useParams();
  
  const [createUserProgress] = useMutation(CREATE_USER_PROGRESS);

  // Module configuration based on type
  const moduleConfig = {
    reading: {
      title: 'OET Reading Practice',
      description: 'Test your ability to read and comprehend healthcare-related materials.',
      timers: [
        { name: 'Part A', duration: 15 },
        { name: 'Part B & C', duration: 45 }
      ],
      color: '#007BFF'
    },
    writing: {
      title: 'OET Writing Practice',
      description: 'Practice writing professional healthcare letters and referrals.',
      timers: [
        { name: 'Reading Time', duration: 5 },
        { name: 'Writing Time', duration: 40 }
      ],
      color: '#4CAF50'
    },
    speaking: {
      title: 'OET Speaking Practice',
      description: 'Roleplay patient consultations with appropriate professional communication.',
      timers: [
        { name: 'Preparation', duration: 3 },
        { name: 'Speaking', duration: 5 }
      ],
      color: '#FF5722'
    },
    listening: {
      title: 'OET Listening Practice',
      description: 'Practice understanding spoken English in healthcare contexts.',
      timers: [
        { name: 'Part A', duration: 20 },
        { name: 'Part B & C', duration: 25 }
      ],
      color: '#9C27B0'
    }
  };
  
  // Get config for current module
  const config = moduleConfig[moduleType || 'reading'];

  const handleStartTest = async () => {
    try {
      const { data } = await createUserProgress({
        variables: {
          sectionType: moduleType
        }
      });

      if (data?.createUserProgress?.success) {
        const progressId = data.createUserProgress.userProgressId;
        switch (moduleType) {
          case 'reading':
            navigate(`/oet/reading/test/`);
            break;
          case 'writing':
            navigate(`/oet/writing/test/${progressId}`);
            break;
          case 'speaking':
            navigate(`/oet/speaking/test/${progressId}`);
            break;
          case 'listening':
            navigate(`/oet/listening/test/${progressId}`);
            break;
          default:
            console.log('Unknown module type');
        }
      } else {
        console.error('Failed to create user progress:', data?.createUserProgress?.message);
      }
    } catch (error) {
      console.error('Error creating user progress:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 via-white to-blue-50">
      <Navbar onLogout={onLogout} />
      
      <main className="flex-grow container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          <button 
            onClick={() => navigate('/oet')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors px-3 py-1.5 rounded-md hover:bg-gray-100"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back to OET Modules
          </button>
          
          <div 
            className="rounded-lg p-5 mb-6"
            style={{ background: 'var(--color-background-gradient)' }}
          >
            <h1 className="text-2xl sm:text-3xl font-bold text-white">{config.title}</h1>
            <p className="text-white/90 mt-2">{config.description}</p>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 mb-6 border border-gray-200">
            <h2 className="text-xl font-bold mb-4">Exam Timer</h2>
            <div className="flex flex-wrap gap-4">
              {config.timers.map((timer, index) => (
                <div key={index} className="flex-1 min-w-[150px] border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-700">{timer.name}</span>
                    <Clock size={16} className="text-gray-500" />
                  </div>
                  <div className="text-2xl font-bold" style={{ color: 'var(--color-primary)' }}>
                    {timer.duration}:00
                  </div>
                  <div className="text-xs text-gray-500">minutes</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <div className="text-center py-8">
              <h2 className="text-xl font-semibold mb-4">Ready to begin?</h2>
              <p className="text-gray-600 mb-6">
                This OET {moduleType} practice test simulates the real exam environment.
                The timer will start once you begin.
              </p>
              <button
                onClick={handleStartTest}
                className="px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                style={{ 
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                Start Practice Test
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETModuleTemplate; 