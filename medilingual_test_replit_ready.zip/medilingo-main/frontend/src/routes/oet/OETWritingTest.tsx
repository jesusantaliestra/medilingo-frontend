import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import Navbar from '../../components/Navbar';
import { ArrowLeft, Clock, Edit, FileText } from 'lucide-react';

const GET_WRITING_TEST = gql`
  query GetWritingTest {
    writingTestSection {
      id
      title
      description
      caseNotes
      taskInstructions
      timeLimitMinutes
      wordLimit
      profession
      letterType
    }
  }
`;

const SUBMIT_WRITING_TEST = gql`
  mutation SubmitWritingTest($sectionId: ID!, $letterContent: String!) {
    submitWritingTest(sectionId: $sectionId, letterContent: $letterContent) {
      success
      message
      tryId
    }
  }
`;

interface OETWritingTestProps {
  onLogout: () => void;
}

const OETWritingTest: React.FC<OETWritingTestProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const [timeLeft, setTimeLeft] = useState(40 * 60); // 40 minutes in seconds
  const [isReadingPhase, setIsReadingPhase] = useState(true);
  const [isTestStarted, setIsTestStarted] = useState(false);
  const [letterContent, setLetterContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { loading, error, data } = useQuery(GET_WRITING_TEST);

  const [submitTest] = useMutation(SUBMIT_WRITING_TEST);

  // Timer effect
  useEffect(() => {
    if (!isTestStarted) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isTestStarted]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleStartTest = () => {
    setIsTestStarted(true);
    setTimeLeft(5 * 60); // 5 minutes for reading phase
  };

  const handleReadingPhaseComplete = () => {
    setIsReadingPhase(false);
    setTimeLeft(40 * 60); // 40 minutes for writing phase
  };

  const handleSubmit = async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    try {
      const result = await submitTest({
        variables: {
          sectionId: data.writingTestSection.id,
          letterContent
        }
      });

      if (result.data?.submitWritingTest.success) {
        navigate(`/oet/writing/results/${result.data.submitWritingTest.tryId}`);
      } else {
        alert(result.data?.submitWritingTest.message || 'Failed to submit test');
      }
    } catch (error) {
      alert('Error submitting test: ' + error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl">Loading...</div>
    </div>
  );

  if (error || !data?.writingTestSection) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl text-red-500">Error: {error?.message || 'Failed to load writing test'}</div>
    </div>
  );

  const writingTask = data.writingTestSection;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet/writing')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Writing Module
          </button>

          {/* Timer and Phase Indicator */}
          <div className="bg-white rounded-lg shadow-md p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center">
              <Clock size={20} className="mr-2" style={{ color: 'var(--color-primary)' }} />
              <span className="text-lg font-semibold" style={{ color: 'var(--color-text-primary)' }}>{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center">
              <span className="text-sm font-medium mr-2" style={{ color: 'var(--color-text-secondary)' }}>
                {isReadingPhase ? 'Reading Phase' : 'Writing Phase'}
              </span>
              <div className="flex space-x-1">
                <div className={`w-3 h-3 rounded-full ${isReadingPhase ? 'bg-primary' : 'bg-gray-300'}`} />
                <div className={`w-3 h-3 rounded-full ${!isReadingPhase ? 'bg-primary' : 'bg-gray-300'}`} />
              </div>
            </div>
          </div>

          {!isTestStarted ? (
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>Ready to Begin Writing Test?</h2>
              <p className="text-gray-600 mb-6">
                You will have 5 minutes to read the case notes, followed by 40 minutes to write your letter.
                The timer will start as soon as you begin.
              </p>
              <button
                onClick={handleStartTest}
                className="px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                style={{
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                Start Test
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {isReadingPhase ? (
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>{writingTask.title}</h2>
                  <div className="prose max-w-none">
                    <pre className="whitespace-pre-wrap font-sans" style={{ color: 'var(--color-text-secondary)' }}>
                      {writingTask.caseNotes}
                    </pre>
                  </div>
                  <button
                    onClick={handleReadingPhaseComplete}
                    className="mt-6 px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                    style={{
                      background: 'var(--color-background-gradient)',
                      border: 'none'
                    }}
                  >
                    Proceed to Writing Phase
                  </button>
                </div>
              ) : (
                <>
                  {/* Requirements */}
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--color-text-primary)' }}>Requirements</h3>
                    <ul className="list-disc list-inside space-y-2">
                      <li style={{ color: 'var(--color-text-secondary)' }}>Use appropriate letter format</li>
                      <li style={{ color: 'var(--color-text-secondary)' }}>Include all relevant patient information</li>
                      <li style={{ color: 'var(--color-text-secondary)' }}>Clearly state the reason for referral</li>
                      <li style={{ color: 'var(--color-text-secondary)' }}>Maintain professional tone</li>
                      <li style={{ color: 'var(--color-text-secondary)' }}>Keep within {writingTask.wordLimit} words</li>
                    </ul>
                  </div>

                  {/* Writing Area */}
                  <div className="bg-white rounded-lg shadow-md p-6">
                    <div className="flex items-center mb-4">
                      <Edit size={20} className="mr-2" style={{ color: 'var(--color-primary)' }} />
                      <h3 className="text-lg font-semibold" style={{ color: 'var(--color-text-primary)' }}>Write Your Letter</h3>
                    </div>
                    <textarea
                      value={letterContent}
                      onChange={(e) => setLetterContent(e.target.value)}
                      className="w-full h-96 p-4 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Start writing your letter here..."
                      style={{
                        color: 'var(--color-text-primary)',
                        backgroundColor: 'var(--color-background-default)',
                        borderColor: 'var(--color-border-main)'
                      }}
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="flex justify-end">
                    <button
                      onClick={handleSubmit}
                      disabled={isSubmitting}
                      className="px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all disabled:opacity-50"
                      style={{
                        background: 'var(--color-background-gradient)',
                        border: 'none'
                      }}
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Letter'}
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default OETWritingTest; 