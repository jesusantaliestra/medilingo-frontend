import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation, gql } from '@apollo/client';
import Navbar from '../../components/Navbar';
import { ArrowLeft, Clock, Mic, User, MessageSquare, AlertCircle, Square, Volume2, Languages, Send, Stethoscope } from 'lucide-react';
import { toast } from 'react-toastify';

const GET_SPEAKING_TEST = gql`
  query GetSpeakingTest($roleSequence: String!) {
    speakingTestSection(roleSequence: $roleSequence) {
      id
      title
      rolePlayScenario
      roleSequence
      timeLimitMinutes
      instructions
      profession
      rolePlayType
      preparationTime
      timeLimit
      score
      roleSequence
    }
  }
`;

const PROCESS_AUDIO_AND_GENERATE_RESPONSE = gql`
  mutation ProcessAudioAndGenerateResponse($audioData: String!, $conversationHistory: [MessageInput!]!, $clinicalCase: ClinicalCaseInput!) {
    processAudioAndGenerateResponse(audioData: $audioData, conversationHistory: $conversationHistory, clinicalCase: $clinicalCase) {
      text
      response
      voiceResponse
    }
  }
`;

const TRANSLATE_TEXT = gql`
  mutation TranslateText($text: String!, $targetLanguage: String!) {
    translateText(text: $text, targetLanguage: $targetLanguage) {
      translatedText
    }
  }
`;

const SUBMIT_SPEAKING_TEST = gql`
  mutation SubmitSpeakingTest($conversationHistory: JSONString!, $rolePlayType: String!, $roleSequence: String!) {
    submitSpeakingTest(conversationHistory: $conversationHistory, rolePlayType: $rolePlayType, roleSequence: $roleSequence) {
      success
      message
      tryId
      score
      feedback
    }
  }
`;

interface Message {
  role: 'system' | 'doctor' | 'patient';
  content: string;
}

interface Feedback {
  englishFluency: {
    score: number;
    comments: string[];
  };
  voiceAccuracy: {
    score: number;
    comments: string[];
  };
  commonMistakes: string[];
  overallScore: number;
  suggestions: string[];
}

interface OETSpeakingTestProps {
  onLogout: () => void;
}

const OETSpeakingTest: React.FC<OETSpeakingTestProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const {  roleSequence } = useParams();
  const [timeLeft, setTimeLeft] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [preparationTimeLeft, setPreparationTimeLeft] = useState(0);
  const [isPreparationPhase, setIsPreparationPhase] = useState(true);
  const [conversation, setConversation] = useState<Message[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [transcribedText, setTranscribedText] = useState('');
  const [translatedMessages, setTranslatedMessages] = useState({});
  const [voiceResponses, setVoiceResponses] = useState({});
  const [isPatientTyping, setIsPatientTyping] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState<Feedback | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const audioPlayerRef = useRef<HTMLAudioElement>(new Audio());

  const { loading, error, data } = useQuery(GET_SPEAKING_TEST, {
    variables: { roleSequence: roleSequence || 'first' },
  });

  const [processAudioAndGenerateResponse] = useMutation(PROCESS_AUDIO_AND_GENERATE_RESPONSE);
  const [translateText] = useMutation(TRANSLATE_TEXT);
  const [submitTest] = useMutation(SUBMIT_SPEAKING_TEST);

  useEffect(() => {
    if (data?.speakingTestSection) {
      setTimeLeft(data.speakingTestSection.timeLimitMinutes * 60);
      setPreparationTimeLeft(data.speakingTestSection.preparationTime * 60);
      // Initialize conversation with scenario
      setConversation([
        {
          role: 'system',
          content: `Role Play Scenario: ${data.speakingTestSection.rolePlayScenario}`
        }
      ]);
    }
  }, [data]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (isPreparationPhase && preparationTimeLeft > 0) {
      timer = setInterval(() => {
        setPreparationTimeLeft(prev => {
          if (prev <= 1) {
            setIsPreparationPhase(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (!isPreparationPhase && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 0) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }

    return () => clearInterval(timer);
  }, [isPreparationPhase, preparationTimeLeft, timeLeft]);

  // Auto-submit when timeLeft reaches 0
  useEffect(() => {
    if (!isPreparationPhase && timeLeft === 0 && !isSubmitting) {
      handleCompleteConsultation();
    }
  }, [isPreparationPhase, timeLeft, isSubmitting]);

  // Auto-scroll chat container
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [conversation]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        } 
      });
      
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus',
        audioBitsPerSecond: 128000
      });
      
      audioChunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorderRef.current.start(250);
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      toast.error('Failed to access microphone. Please check your permissions.');
    }
  };

  const stopRecording = async () => {
    if (mediaRecorderRef.current && isRecording) {
      setIsRecording(false);
      
      return new Promise((resolve) => {
        if (!mediaRecorderRef.current) return resolve(null);
        
        mediaRecorderRef.current.onstop = async () => {
          try {
            const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm;codecs=opus' });
            
            const reader = new FileReader();
            reader.readAsDataURL(audioBlob);
            
            reader.onloadend = async () => {
              const base64Audio = reader.result as string;
              const audioData = base64Audio.split(',')[1];
              
              try {
                setIsPatientTyping(true);
                const response = await processAudioAndGenerateResponse({
                  variables: {
                    audioData,
                    conversationHistory: conversation,
                    clinicalCase: {
                      description: data.speakingTestSection.rolePlayScenario
                    }
                  }
                });
                
                if (response.data?.processAudioAndGenerateResponse) {
                  const { text, response: patientResponse, voiceResponse } = response.data.processAudioAndGenerateResponse;
                  
                  setTranscribedText(text);
                  
                  setConversation([
                    ...conversation,
                    {
                      role: 'doctor' as const,
                      content: text
                    },
                    {
                      role: 'patient' as const,
                      content: patientResponse
                    }
                  ]);

                  if (voiceResponse) {
                    setVoiceResponses(prev => ({
                      ...prev,
                      [conversation.length + 1]: voiceResponse
                    }));
                    await playVoiceResponse(voiceResponse);
                  }
                  
                  setTranscribedText('');
                }
              } catch (error) {
                console.error('Error processing audio:', error);
                toast.error('Failed to process audio. Please try again.');
              } finally {
                setIsPatientTyping(false);
              }
            };
          } catch (error) {
            console.error('Error processing audio:', error);
            toast.error('Failed to process audio. Please try again.');
          }
          
          resolve(null);
        };
        
        mediaRecorderRef.current.stop();
        mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      });
    }
  };

  const playVoiceResponse = async (base64Audio: string) => {
    try {
      const audioBlob = await fetch(`data:audio/mp3;base64,${base64Audio}`).then(res => res.blob());
      const audioUrl = URL.createObjectURL(audioBlob);
      audioPlayerRef.current.src = audioUrl;
      audioPlayerRef.current.playbackRate = 1.0;
      await audioPlayerRef.current.play();
    } catch (error) {
      console.error('Error playing voice response:', error);
      toast.error('Failed to play voice response');
    }
  };

  const handleTranslate = async (messageIndex: number) => {
    const message = conversation[messageIndex];
    if (!message || message.role !== 'patient') return;

    try {
      const response = await translateText({
        variables: {
          text: message.content,
          targetLanguage: 'en' // You can make this dynamic based on user's native language
        }
      });

      if (response.data?.translateText.translatedText) {
        setTranslatedMessages(prev => ({
          ...prev,
          [messageIndex]: response.data.translateText.translatedText
        }));
      }
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Failed to translate message. Please try again.');
    }
  };

  const handleSubmitQuestion = async () => {
    try {
      const response = await processAudioAndGenerateResponse({
        variables: {
          audioData: '',
          conversationHistory: conversation,
          clinicalCase: {
            description: data.speakingTestSection.rolePlayScenario
          }
        }
      });
      
      if (response.data?.processAudioAndGenerateResponse) {
        const { text, response: patientResponse, voiceResponse } = response.data.processAudioAndGenerateResponse;
        
        setConversation([
          ...conversation,
          {
            role: 'patient' as const,
            content: patientResponse
          }
        ]);
        
        if (voiceResponse) {
          setVoiceResponses(prev => ({
            ...prev,
            [conversation.length]: voiceResponse
          }));
          await playVoiceResponse(voiceResponse);
        }
        
        if (text) {
          setTranscribedText(text);
        }
      }
      
      setCurrentQuestion('');
    } catch (error) {
      console.error('Error generating response:', error);
      toast.error('Failed to generate response. Please try again.');
    }
  };

  const handleRecordingComplete = async (audioBlob: Blob | null) => {
    if (!currentQuestion.trim() && !audioBlob) return;
    
    setIsSubmitting(true);
    
    try {
      const newConversation: Message[] = [
        ...conversation,
        {
          role: 'doctor' as const,
          content: currentQuestion
        }
      ];
      
      const response = await processAudioAndGenerateResponse({
        variables: {
          audioData: audioBlob ? await blobToBase64(audioBlob) : '',
          conversationHistory: newConversation,
          clinicalCase: {
            description: data.speakingTestSection.rolePlayScenario
          }
        }
      });
      
      if (response.data?.processAudioAndGenerateResponse) {
        const { text, response: patientResponse, voiceResponse } = response.data.processAudioAndGenerateResponse;
        
        setConversation([
          ...newConversation,
          {
            role: 'patient' as const,
            content: patientResponse
          }
        ]);
        
        if (audioBlob && voiceResponse) {
          setVoiceResponses(prev => ({
            ...prev,
            [newConversation.length]: voiceResponse
          }));
          await playVoiceResponse(voiceResponse);
        }
        
        if (audioBlob) {
          setTranscribedText(text);
        }
      }
      
      setCurrentQuestion('');
      
    } catch (error) {
      console.error('Error generating response:', error);
      toast.error('Failed to generate response. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        resolve(base64String.split(',')[1]);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  const handleCompleteConsultation = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      const result = await submitTest({
        variables: {
          conversationHistory: JSON.stringify(conversation),
          rolePlayType: data.speakingTestSection.rolePlayType,
          roleSequence: roleSequence || data.speakingTestSection.roleSequence
        }
      });
      if (result.data?.submitSpeakingTest.success) {
        navigate(`/oet/speaking/results/${roleSequence}`);
      } else {
        toast.error(result.data?.submitSpeakingTest.message || 'Failed to submit test');
      }
    } catch (error) {
      console.error('Error submitting test:', error);
      toast.error('Error submitting test: ' + error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (currentQuestion.trim()) {
        handleSubmitQuestion();
      }
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl">Loading...</div>
    </div>
  );

  if (error || !data?.speakingTestSection) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl text-red-500">Error: {error?.message || 'Failed to load speaking test'}</div>
    </div>
  );

  const speakingSection = data.speakingTestSection;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          <button 
            onClick={() => navigate('/oet/speaking')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Speaking Module
          </button>

          <div className="bg-white rounded-lg shadow-md p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center">
              <Clock size={20} className="mr-2" style={{ color: 'var(--color-primary)' }} />
              <span className="text-lg font-semibold" style={{ color: 'var(--color-text-primary)' }}>
                {formatTime(isPreparationPhase ? preparationTimeLeft : timeLeft)}
              </span>
            </div>
            <div className="flex items-center">
              <span className="text-sm font-medium mr-2" style={{ color: 'var(--color-text-secondary)' }}>
                {isPreparationPhase ? 'Preparation Phase' : 'Speaking Phase'}
              </span>
              <div className="flex space-x-1">
                <div className={`w-3 h-3 rounded-full ${isPreparationPhase ? 'bg-primary' : 'bg-gray-300'}`} />
                <div className={`w-3 h-3 rounded-full ${!isPreparationPhase ? 'bg-primary' : 'bg-gray-300'}`} />
              </div>
            </div>
          </div>

          {!isPreparationPhase ? (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-xl font-semibold mb-4" style={{ color: 'var(--color-text-primary)' }}>
                  Speaking Test
                </h2>
                <div className="prose max-w-none" style={{ color: 'var(--color-text-secondary)' }}>
                  <h3 className="text-lg font-medium mb-2">Role Play Type:</h3>
                  <p className="mb-4">{speakingSection.rolePlayType}</p>
                  <h3 className="text-lg font-medium mb-2">Scenario:</h3>
                  <p className="mb-4">{speakingSection.rolePlayScenario}</p>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-md p-6">
                <div 
                  ref={chatContainerRef}
                  className="bg-gray-50 p-4 rounded-lg border border-gray-200 h-64 overflow-y-auto scroll-smooth mb-4"
                >
                  {conversation.map((message, index) => (
                    <div 
                      key={index} 
                      className={`mb-4 ${
                        message.role === 'doctor' ? 'text-right' : 'text-left'
                      }`}
                    >
                      <div 
                        className={`inline-block p-3 rounded-lg ${
                          message.role === 'doctor' 
                            ? 'bg-teal-100 text-teal-800' 
                            : message.role === 'patient'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-gray-200 text-gray-800'
                        }`}
                      >
                        <div className="flex items-center">
                          {message.role === 'doctor' ? (
                            <Stethoscope className="mr-1" size={16} />
                          ) : message.role === 'patient' ? (
                            <User className="mr-1" size={16} />
                          ) : (
                            <MessageSquare className="mr-1" size={16} />
                          )}
                          <span className="font-medium">
                            {message.role === 'doctor' 
                              ? 'Doctor' 
                              : message.role === 'patient'
                                ? 'Patient'
                                : 'System'}
                          </span>
                          {message.role === 'patient' && (
                            <>
                              <button
                                onClick={() => handleTranslate(index)}
                                className="ml-2 p-1 rounded-full bg-indigo-200 hover:bg-indigo-300 transition-colors"
                              >
                                <Languages size={14} />
                              </button>
                              {voiceResponses[index] && (
                                <button
                                  onClick={() => playVoiceResponse(voiceResponses[index])}
                                  className="ml-2 p-1 rounded-full bg-indigo-200 hover:bg-indigo-300 transition-colors"
                                >
                                  <Volume2 size={14} />
                                </button>
                              )}
                            </>
                          )}
                        </div>
                        <p>{message.content}</p>
                        {translatedMessages[index] && (
                          <div className="mt-2 p-2 bg-indigo-50 rounded text-indigo-700 text-sm">
                            {translatedMessages[index]}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  {isPatientTyping && (
                    <div className="flex items-center space-x-2 text-gray-500">
                      <User className="text-indigo-600" size={16} />
                      <span className="font-medium">Patient</span>
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                        <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-col space-y-4">
                  <div className="flex items-center justify-center">
                    <button
                      onClick={isRecording ? stopRecording : startRecording}
                      className={`p-4 rounded-full ${
                        isRecording 
                          ? 'bg-red-500 hover:bg-red-600' 
                          : 'bg-teal-600 hover:bg-teal-700'
                      } text-white transition-colors`}
                    >
                      {isRecording ? <Square size={24} /> : <Mic size={24} />}
                    </button>
                  </div>
                  
                  {isRecording && (
                    <div className="text-center text-red-500 font-medium">
                      Recording... Speak now
                    </div>
                  )}
                  
                  {transcribedText && (
                    <div className="text-sm text-gray-600">
                      Transcribed: {transcribedText}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleCompleteConsultation}
                  disabled={isSubmitting}
                  className={`flex items-center px-4 py-2 text-white rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg ${
                    isSubmitting ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none'
                  }}
                >
                  {isSubmitting ? 'Generating Feedback...' : 'Complete Test'}
                  <ArrowLeft className="ml-2" size={18} />
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>
                {speakingSection.title}
              </h2>
              
              <div className="mb-6 p-4 rounded-lg bg-blue-50">
                <div className="flex items-center mb-2">
                  <User size={20} className="mr-2 text-blue-600" />
                  <h3 className="font-semibold text-blue-700">Your Role</h3>
                </div>
                <p className="text-blue-800">{speakingSection.rolePlayScenario}</p>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>Scenario</h3>
                <p className="text-gray-700">{speakingSection.rolePlayScenario}</p>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>Tasks</h3>
                <ul className="list-disc list-inside space-y-2">
                  {speakingSection.instructions.split('\n').map((task, index) => (
                    <li key={index} style={{ color: 'var(--color-text-secondary)' }}>{task}</li>
                  ))}
                </ul>
              </div>

              <div className="mb-6">
                <h3 className="font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>Role Sequence</h3>
                <p className="text-gray-700">{speakingSection.roleSequence === 'first' ? 'First' : 'Second'}</p>
              </div>

              <button
                onClick={() => setIsPreparationPhase(false)}
                className="mt-6 px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                style={{
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                Begin Roleplay
              </button>
            </div>
          )}

          {showFeedback && feedback && (
            <div className="mt-6 space-y-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Test Results</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-blue-800 mb-2">English Fluency</h3>
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className={`w-5 h-5 ${i < feedback.englishFluency.score ? 'text-yellow-400' : 'text-gray-300'}`}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-600">{feedback.englishFluency.score}/5</span>
                  </div>
                  <ul className="list-disc list-inside text-sm text-gray-700">
                    {feedback.englishFluency.comments.map((comment, index) => (
                      <li key={index}>{comment}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-green-800 mb-2">Voice Accuracy</h3>
                  <div className="flex items-center mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <svg
                          key={i}
                          className={`w-5 h-5 ${i < feedback.voiceAccuracy.score ? 'text-yellow-400' : 'text-gray-300'}`}
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-600">{feedback.voiceAccuracy.score}/5</span>
                  </div>
                  <ul className="list-disc list-inside text-sm text-gray-700">
                    {feedback.voiceAccuracy.comments.map((comment, index) => (
                      <li key={index}>{comment}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-yellow-800 mb-2">Common Mistakes</h3>
                <ul className="list-disc list-inside text-sm text-gray-700">
                  {feedback.commonMistakes.map((mistake, index) => (
                    <li key={index}>{mistake}</li>
                  ))}
                </ul>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-purple-800 mb-2">Overall Performance</h3>
                <div className="flex items-center mb-4">
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div
                      className="bg-purple-600 h-2.5 rounded-full"
                      style={{ width: `${feedback.overallScore}%` }}
                    ></div>
                  </div>
                  <span className="ml-2 text-sm font-medium text-gray-700">{feedback.overallScore}%</span>
                </div>
                <h4 className="text-md font-medium text-purple-700 mb-2">Suggestions for Improvement:</h4>
                <ul className="list-disc list-inside text-sm text-gray-700">
                  {feedback.suggestions.map((suggestion, index) => (
                    <li key={index}>{suggestion}</li>
                  ))}
                </ul>
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => navigate('/oet/speaking')}
                  className="flex items-center space-x-2 px-6 py-3 rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                  style={{
                    background: 'var(--color-background-default)',
                    border: '1px solid var(--color-border-main)',
                    color: 'var(--color-text-primary)'
                  }}
                >
                  <ArrowLeft className="h-5 w-5" />
                  <span>Back to Speaking Module</span>
                </button>
                <button
                  onClick={() => navigate('/oet/speaking/test/new')}
                  className="px-6 py-3 rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none',
                    color: 'white'
                  }}
                >
                  Take Another Test
                </button>
                {roleSequence === 'first' && (
                  <button
                    onClick={() => navigate('/oet/speaking/test/second')}
                    className="px-6 py-3 rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all"
                    style={{
                      background: 'linear-gradient(90deg, #6366f1 0%, #60a5fa 100%)',
                      border: 'none',
                      color: 'white'
                    }}
                  >
                    Take Second Roleplay
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default OETSpeakingTest; 