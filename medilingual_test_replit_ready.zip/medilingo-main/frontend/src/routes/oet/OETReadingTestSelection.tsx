import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';
import Navbar from '../../components/Navbar';
import { ArrowLeft, BookOpen, CheckCircle, XCircle } from 'lucide-react';

const GET_READING_PROGRESSION = gql`
  query GetReadingProgression {
    readingSectionProgression {
      a
      b
      c
    }
  }
`;

interface OETReadingTestSelectionProps {
  onLogout: () => void;
}

const OETReadingTestSelection: React.FC<OETReadingTestSelectionProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { progressId } = useParams();
  const { data, loading, error } = useQuery(GET_READING_PROGRESSION);

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet/reading')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Reading Module
          </button>

          {/* Test Selection Card */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-center mb-8">
              <BookOpen size={48} className="mx-auto mb-4" style={{ color: 'var(--color-primary)' }} />
              <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>OET Reading Test</h1>
              <p className="text-gray-600 mb-8">
                Choose which part of the reading test you would like to attempt.
                Each part has its own time limit and set of questions.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Part A Card */}
              <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                <div className="flex justify-between items-start mb-4">
                  <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>Part A</h2>
                  {data?.readingSectionProgression?.a ? (
                    <div className="flex items-center text-green-600">
                      <CheckCircle size={20} className="mr-1" />
                      <span className="text-sm">Completed</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-gray-500">
                      <XCircle size={20} className="mr-1" />
                      <span className="text-sm">Not completed</span>
                    </div>
                  )}
                </div>
                <p className="text-gray-600 mb-4">
                  Time limit: 15 minutes<br />
                  Format: Multiple choice questions based on a healthcare text
                </p>
                <button
                  onClick={() => navigate(`/oet/reading/test/A`)}
                  className="w-full px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none'
                  }}
                >
                  Start Part A
                </button>
              </div>

              {/* Part B Card */}
              <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
                <div className="flex justify-between items-start mb-4">
                  <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>Part B & C</h2>
                  {data?.readingSectionProgression?.b ? (
                    <div className="flex items-center text-green-600">
                      <CheckCircle size={20} className="mr-1" />
                      <span className="text-sm">Completed</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-gray-500">
                      <XCircle size={20} className="mr-1" />
                      <span className="text-sm">Not completed</span>
                    </div>
                  )}
                </div>
                <p className="text-gray-600 mb-4">
                  Time limit: 45 minutes<br />
                  Format: Multiple choice questions based on healthcare scenarios
                </p>
                <button
                  onClick={() => navigate(`/oet/reading/test/B`)}
                  className="w-full px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none'
                  }}
                >
                  Start Part B & C
                </button>
              </div>

              {/* Part D Card */}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETReadingTestSelection; 