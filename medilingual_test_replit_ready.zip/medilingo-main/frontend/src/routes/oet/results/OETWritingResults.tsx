import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@apollo/client';
import { gql } from '@apollo/client';
import Navbar from '../../../components/Navbar';
import { ArrowLeft, FileText, Award, Clock, CheckCircle, Star, BarChart } from 'lucide-react';

const GET_WRITING_RESULTS = gql`
  query GetWritingResults($progressId: ID!) {
    getWritingSection(progressId: $progressId)
  }
`;

interface CriteriaScores {
  task_fulfillment: number;
  grammar: number;
  vocabulary: number;
  coherence: number;
  format: number;
}

interface WritingSubmission {
  letter_content: string;
  completed_at: string;
  section_id: string;
  score: number;
  band: string;
  criteria_scores: CriteriaScores;
  feedback: string[];
}

interface WritingSection {
  id: string;
  title: string;
  description: string;
  case_notes: string;
  task_instructions: string;
  time_limit_minutes: number;
  word_limit: number;
  profession: string;
  letter_type: string;
}

interface WritingResults {
  section: {
    id: string;
    title: string;
    description: string;
    case_notes: string;
    task_instructions: string;
    time_limit_minutes: number;
    word_limit: number;
    profession: string;
    letter_type: string;
  };
  submission: {
    letter_content: string;
    completed_at: string;
    section_id: string;
    score: number;
    band: string;
    criteria_scores: CriteriaScores;
    feedback: string[];
  };
}

interface OETWritingResultsProps {
  onLogout: () => void;
}

const OETWritingResults: React.FC<OETWritingResultsProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { progressId } = useParams<{ progressId: string }>();

  const { loading, error, data } = useQuery(GET_WRITING_RESULTS, {
    variables: { progressId },
    skip: !progressId
  });

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="flex items-center space-x-3">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2" style={{ borderColor: 'var(--color-primary)' }}></div>
        <div className="text-xl" style={{ color: 'var(--color-text-primary)' }}>Loading results...</div>
      </div>
    </div>
  );

  if (error || !data?.getWritingSection) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl p-6 bg-white rounded-lg shadow-md text-center max-w-md mx-auto">
        <div className="text-red-500 text-5xl mb-4">⚠️</div>
        <div className="font-bold mb-2">Error Loading Results</div>
        <p className="text-base">{error?.message || 'Failed to load results'}</p>
        <button 
          onClick={() => navigate('/oet/writing')}
          className="mt-4 px-4 py-2 rounded-lg shadow-sm text-white font-medium"
          style={{ backgroundColor: 'var(--color-primary)' }}
        >
          Return to Writing Module
        </button>
      </div>
    </div>
  );

  const results: WritingResults = JSON.parse(data.getWritingSection);
  const score = Math.round(results.submission.score);

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20 md:mt-24">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet/writing')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors group"
            aria-label="Back to Writing Module"
          >
            <ArrowLeft size={20} className="mr-2 group-hover:-translate-x-1 transition-transform" />
            <span className="font-medium">Back to Writing Module</span>
          </button>

          {/* Results Card */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Header with gradient */}
            <div className="p-6 text-center text-white" style={{ background: 'var(--color-background-gradient)' }}>
              <FileText size={48} className="mx-auto mb-4 drop-shadow-md" />
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Writing Test Results</h1>
              <p className="text-lg opacity-90">{results.section.title}</p>
            </div>
            
            {/* Score Display */}
            <div className="flex flex-col md:flex-row md:justify-center items-center gap-6 p-6 border-b border-gray-100">
              <div className="relative flex items-center justify-center w-36 h-36">
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="#e6e6e6"
                      strokeWidth="8"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="var(--color-primary)"
                      strokeWidth="8"
                      strokeDasharray={`${(score / 100) * 283} 283`}
                      strokeDashoffset="0"
                      strokeLinecap="round"
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                </div>
                <div className="text-center z-10">
                  <div className="text-4xl font-bold" style={{ color: 'var(--color-primary)' }}>{score}%</div>
                </div>
              </div>
              
              <div className="text-center md:text-left">
                <div className="inline-flex items-center px-4 py-2 rounded-full mb-2" 
                  style={{ 
                    backgroundColor: score >= 70 ? 'rgba(76, 175, 80, 0.1)' : score >= 50 ? 'rgba(255, 193, 7, 0.1)' : 'rgba(244, 67, 54, 0.1)',
                    color: score >= 70 ? 'var(--color-secondary-dark)' : score >= 50 ? '#F57C00' : '#D32F2F'
                  }}>
                  <Award size={20} className="mr-2" />
                  <span className="font-semibold">Band {results.submission.band}</span>
                </div>
                <p className="text-gray-600">
                  {score >= 70 ? 'Excellent performance!' : 
                   score >= 50 ? 'Good effort, room for improvement.' : 
                   'Keep practicing to improve your score.'}
                </p>
                <p className="text-gray-500 text-sm mt-2">
                  Completed on {new Date(results.submission.completed_at).toLocaleDateString(undefined, { 
                    year: 'numeric', month: 'short', day: 'numeric' 
                  })}
                </p>
              </div>
            </div>

            {/* Criteria Scores */}
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold mb-4 flex items-center" style={{ color: 'var(--color-text-primary)' }}>
                <BarChart size={22} className="mr-2" style={{ color: 'var(--color-primary)' }} />
                Criteria Scores
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {results.submission.criteria_scores && Object.entries(results.submission.criteria_scores).map(([criteria, score]) => {
                  const criteriaLabel = criteria.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                  const scorePercentage = (score / 10) * 100; // Assuming score is out of 10
                  
                  return (
                    <div key={criteria} className="bg-gray-50 p-4 rounded-lg shadow-sm">
                      <div className="flex justify-between items-center mb-2">
                        <div className="text-md font-medium" style={{ color: 'var(--color-text-primary)' }}>
                          {criteriaLabel}
                        </div>
                        <div className="font-bold" style={{ color: 'var(--color-primary)' }}>{score}/10</div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-1">
                        <div 
                          className="h-2.5 rounded-full" 
                          style={{ 
                            width: `${scorePercentage}%`,
                            backgroundColor: 'var(--color-primary)'
                          }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Feedback Section */}
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold mb-4 flex items-center" style={{ color: 'var(--color-text-primary)' }}>
                <Star size={22} className="mr-2" style={{ color: 'var(--color-primary)' }} />
                Feedback
              </h2>
              <div className="space-y-3">
                {results.submission.feedback && results.submission.feedback.length > 0 ? 
                  results.submission.feedback.map((item, index) => (
                    <div key={index} className="flex items-start p-3 bg-gray-50 rounded-lg">
                      <CheckCircle size={20} className="mr-3 mt-0.5 flex-shrink-0" style={{ color: 'var(--color-secondary)' }} />
                      <span style={{ color: 'var(--color-text-secondary)' }}>{item}</span>
                    </div>
                  )) : (
                    <div className="text-center p-4 text-gray-500">
                      No specific feedback available for this attempt.
                    </div>
                  )
                }
              </div>
            </div>

            {/* Case Notes */}
            <div className="p-6 border-b border-gray-100">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold flex items-center" style={{ color: 'var(--color-text-primary)' }}>
                  <FileText size={22} className="mr-2" style={{ color: 'var(--color-primary)' }} />
                  Case Notes
                </h2>
                <span className="text-sm text-gray-500">Reference Material</span>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed" style={{ color: 'var(--color-text-secondary)' }}>
                  {results.section.case_notes}
                </pre>
              </div>
            </div>

            {/* Your Submission */}
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold mb-4 flex items-center" style={{ color: 'var(--color-text-primary)' }}>
                <FileText size={22} className="mr-2" style={{ color: 'var(--color-primary)' }} />
                Your Letter
              </h2>
              <div className="bg-gray-50 p-5 rounded-lg shadow-sm">
                <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed" style={{ color: 'var(--color-text-secondary)' }}>
                  {results.submission.letter_content}
                </pre>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="p-6 bg-gray-50 flex flex-col sm:flex-row justify-center gap-4">
              <button
                onClick={() => navigate('/oet/writing')}
                className="px-6 py-3 rounded-lg font-medium transition-all flex items-center justify-center"
                style={{
                  background: 'var(--color-background-gradient)',
                  color: 'white',
                  boxShadow: 'var(--shadow-md)'
                }}
              >
                <FileText size={18} className="mr-2" />
                Try Another Writing Test
              </button>
              <button
                onClick={() => navigate('/oet')}
                className="px-6 py-3 rounded-lg font-medium bg-white border border-gray-200 hover:bg-gray-50 transition-colors flex items-center justify-center"
              >
                Back to OET Dashboard
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETWritingResults; 