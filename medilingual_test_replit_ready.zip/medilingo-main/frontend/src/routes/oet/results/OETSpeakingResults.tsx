import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';
import { ArrowLeft, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

const GET_SPEAKING_RESULTS = gql`
  query GetSpeakingResults($roleSequence: String!) {
    speakingTestResults(roleSequence: $roleSequence) {
      id
      createdAt
      updatedAt
      overallScore
      grade
      result
      speakingSection {
        roleSequence
       
      }
    }
  }
`;

interface OETSpeakingResultsProps {
  onLogout: () => void;
}

const OETSpeakingResults: React.FC<OETSpeakingResultsProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { roleSequence } = useParams();

  // Countdown state for redirection if roleSequence is 'first'
  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    if (roleSequence === 'first') {
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            navigate('/oet/speaking/test/second');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [roleSequence, navigate]);

  const { loading, error, data } = useQuery(GET_SPEAKING_RESULTS, {
    variables: {
      roleSequence
    }
  });

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl">Loading...</div>
    </div>
  );

  if (error || !data?.speakingTestResults) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl text-red-500">Error: {error?.message || 'Failed to load results'}</div>
    </div>
  );

  // Use the result field directly (parse if string)
  let results = data.speakingTestResults.result;
  if (typeof results === 'string') {
    try {
      results = JSON.parse(results);
    } catch (e) {
      results = null;
    }
  }
  
  if (!data?.speakingTestResults) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
        <div className="text-xl text-red-500">No speaking test results found</div>
      </div>
    );
  }

  const score = data.speakingTestResults.overallScore || 0;
  const completedAt = results.completed_at;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-2xl font-semibold" style={{ color: 'var(--color-text-primary)' }}>
            OET Speaking Test Results
          </h1>
          <button
            onClick={onLogout}
            className="px-4 py-2 text-sm font-medium rounded-md"
            style={{
              color: 'var(--color-text-primary)',
              backgroundColor: 'var(--color-background-default)',
              border: '1px solid var(--color-border-main)'
            }}
          >
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="space-y-6">
          {/* Countdown Alert for roleSequence 'first' */}
          {roleSequence === 'first' && (
            <div className="px-6 pb-6">
              <div className="bg-yellow-50 border-2 border-yellow-400 rounded-xl p-6 text-center animate-pulse">
                <div className="flex flex-col items-center justify-center space-y-3">
                  <div className="bg-yellow-100 rounded-full p-4">
                    <AlertCircle className="h-12 w-12 text-yellow-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-yellow-800">
                    Automatic Redirection in Progress
                  </h3>
                  <div className="text-5xl font-bold text-yellow-600">
                    {timeLeft}
                  </div>
                  <p className="text-lg text-yellow-700">
                    You will be redirected to the next speaking test in <span className="font-semibold">{timeLeft} seconds</span>
                  </p>
                  <p className="text-sm text-yellow-600">
                    Please wait while we prepare the next section for you
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Score Summary */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>
                Your Speaking Test Results
              </h2>
              <div className="flex justify-center items-center space-x-4 mb-6">
                <div className="text-4xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
                  {score.toFixed(1)}
                </div>
              </div>
              <p className="text-sm text-gray-500">
                Completed on {new Date(completedAt).toLocaleDateString()}
              </p>
            </div>
          </div>

          {/* Band and Criteria Scores */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-center mb-4">
              <span className="text-lg font-semibold" style={{ color: 'var(--color-text-primary)' }}>
                Band: {results.band || data.speakingTestResults.grade}
              </span>
            </div>
            {results.criteria_scores && (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-4 py-2 text-left">Criteria</th>
                      <th className="px-4 py-2 text-left">Score</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(Object.entries(results.criteria_scores as Record<string, number>) as [string, number][]).map(([criteria, value]) => (
                      <tr key={criteria}>
                        <td className="px-4 py-2 capitalize">{criteria}</td>
                        <td className="px-4 py-2">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Feedback */}
          {results.feedback && results.feedback.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>
                Feedback
              </h3>
              <ul className="list-disc list-inside text-gray-700">
                {results.feedback.map((item: string, idx: number) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Conversation History */}
          {results.conversation_history && results.conversation_history.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold mb-2" style={{ color: 'var(--color-text-primary)' }}>
                Conversation History
              </h3>
              <ul className="space-y-2">
                {results.conversation_history.map((msg: any, idx: number) => (
                  <li key={idx} className="border-b last:border-b-0 pb-2">
                    <span className="font-medium capitalize">{msg.role}:</span> {msg.content}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => navigate('/oet')}
              className="flex items-center space-x-2 px-6 py-3 rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
              style={{
                background: 'var(--color-background-default)',
                border: '1px solid var(--color-border-main)',
                color: 'var(--color-text-primary)'
              }}
            >
              <ArrowLeft className="h-5 w-5" />
              <span>Back to OET</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETSpeakingResults; 