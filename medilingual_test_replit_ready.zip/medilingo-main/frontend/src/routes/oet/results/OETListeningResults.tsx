import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@apollo/client';
import { gql } from '@apollo/client';
import Navbar from '../../../components/Navbar';
import { ArrowLeft, Headphones, Award, Clock, FileText, AlertTriangle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const GET_LISTENING_RESULTS = gql`
  query GetListeningResults($tryId: ID!) {
    listeningTestResults(tryId: $tryId) {
      overallScore
      grade
      feedback
      updatedAt
      listeningSection {
        part
      }
    }
  }
`;

interface OETListeningResultsProps {
  onLogout: () => void;
}

const OETListeningResults: React.FC<OETListeningResultsProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { tryId } = useParams();
  const [timeLeft, setTimeLeft] = useState(15);

  const { loading, error, data } = useQuery(GET_LISTENING_RESULTS, {
    variables: {
      tryId
    }
  });

  useEffect(() => {
    if (data?.listeningTestResults?.listeningSection?.part === "B") {
      const timer = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 1) {
            clearInterval(timer);
            navigate('/oet/listening/test/C');
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [data, navigate]);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="flex items-center space-x-3">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2" style={{ borderColor: 'var(--color-primary)' }}></div>
        <div className="text-xl" style={{ color: 'var(--color-text-primary)' }}>Loading results...</div>
      </div>
    </div>
  );

  if (error || !data?.listeningTestResults) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl p-6 bg-white rounded-lg shadow-md text-center max-w-md mx-auto">
        <div className="text-red-500 text-5xl mb-4">⚠️</div>
        <div className="font-bold mb-2">Error Loading Results</div>
        <p className="text-base">{error?.message || 'Failed to load results'}</p>
        <button 
          onClick={() => navigate('/oet/listening')}
          className="mt-4 px-4 py-2 rounded-lg shadow-sm text-white font-medium"
          style={{ backgroundColor: 'var(--color-primary)' }}
        >
          Return to Listening Module
        </button>
      </div>
    </div>
  );

  const results = data.listeningTestResults;
  const score = results.overallScore;
  const band = results.grade;
  const feedback = results.feedback ? results.feedback.split('\n') : [];
  const isPart = results.listeningSection.part;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20 md:mt-24">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet/listening')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors group"
            aria-label="Back to Listening Module"
          >
            <ArrowLeft size={20} className="mr-2 group-hover:-translate-x-1 transition-transform" />
            <span className="font-medium">Back to Listening Module</span>
          </button>

          {/* Results Card */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Header with gradient */}
            <div className="p-6 text-center text-white" style={{ background: 'var(--color-background-gradient)' }}>
              <Headphones size={48} className="mx-auto mb-4 drop-shadow-md" />
              <h1 className="text-3xl md:text-4xl font-bold mb-2">Listening Test Results</h1>
              <p className="text-lg opacity-90">Part {results.listeningSection.part}</p>
            </div>
            
            {/* Score Display */}
            <div className="flex flex-col md:flex-row md:justify-center items-center gap-6 p-6 border-b border-gray-100">
              <div className="relative flex items-center justify-center w-36 h-36">
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="#e6e6e6"
                      strokeWidth="8"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="45"
                      fill="none"
                      stroke="var(--color-primary)"
                      strokeWidth="8"
                      strokeDasharray={`${(score / 100) * 283} 283`}
                      strokeDashoffset="0"
                      strokeLinecap="round"
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                </div>
                <div className="text-center z-10">
                  <div className="text-4xl font-bold" style={{ color: 'var(--color-primary)' }}>{score}%</div>
                  <div className="text-lg font-semibold mt-1">Grade: {band}</div>
                </div>
              </div>
            </div>

            {/* Feedback Section */}
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-4" style={{ color: 'var(--color-text-primary)' }}>Feedback & Recommendations</h2>
              <div className="space-y-4">
                {feedback.length > 0 ? feedback.map((item, index) => (
                  <div key={index} className="p-4 rounded-lg border border-gray-100 shadow-sm bg-white hover:shadow-md transition-shadow prose">
                    <ReactMarkdown>{item}</ReactMarkdown>
                  </div>
                )) : (
                  <div className="text-center p-6 text-gray-500">
                    No specific feedback available for this attempt.
                  </div>
                )}
              </div>
            </div>

            {/* Large Alert Badge for Part B */}
            {isPart === "B" && (
              <div className="px-6 pb-6">
                <div className="bg-yellow-50 border-2 border-yellow-400 rounded-xl p-6 text-center animate-pulse">
                  <div className="flex flex-col items-center justify-center space-y-3">
                    <div className="bg-yellow-100 rounded-full p-4">
                      <AlertTriangle className="h-12 w-12 text-yellow-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-yellow-800">
                      Automatic Redirection in Progress
                    </h3>
                    <div className="text-5xl font-bold text-yellow-600">
                      {timeLeft}
                    </div>
                    <p className="text-lg text-yellow-700">
                      You will be redirected to Part C in <span className="font-semibold">{timeLeft} seconds</span>
                    </p>
                    <p className="text-sm text-yellow-600">
                      Please wait while we prepare the next section for you
                    </p>
                  </div>
                </div>
              </div>
            )}
            
            {/* Action Buttons */}
            <div className="p-6 bg-gray-50 flex flex-col sm:flex-row justify-center gap-4">
              <button
                onClick={() => navigate('/oet/listening')}
                className="px-6 py-3 rounded-lg font-medium transition-all flex items-center justify-center"
                style={{
                  background: 'var(--color-background-gradient)',
                  color: 'white',
                  boxShadow: 'var(--shadow-md)'
                }}
              >
                <Headphones size={18} className="mr-2" />
                Try Another Listening Test
              </button>
              <button
                onClick={() => navigate('/oet')}
                className="px-6 py-3 rounded-lg font-medium bg-white border border-gray-200 hover:bg-gray-50 transition-colors flex items-center justify-center"
              >
                Back to OET Dashboard
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETListeningResults; 