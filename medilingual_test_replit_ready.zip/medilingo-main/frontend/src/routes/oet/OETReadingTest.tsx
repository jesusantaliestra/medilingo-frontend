import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import Navbar from '../../components/Navbar';
import { ArrowLeft, Clock } from 'lucide-react';

interface Question {
  id: string;
  dbId: string;
  questionText: string;
  questionType: 'MCQ' | 'FILL' | 'MATCH' | 'TRUE_FALSE' | 'SUMMARY';
  options: string[] | null;
  marks: number;
  questionNumber: number;
  correctAnswer: string;
}

interface TextContent {
  id: string;
  dbId: string;
  title: string;
  text: string;
  questions: {
    edges: {
      node: Question;
    }[];
  };
}

interface ReadingSection {
  id: string;
  description: string;
  timeLimitMinutes: number;
  textContents: {
    edges: {
      node: TextContent;
    }[];
  };
}

const GET_READING_TEST = gql`
  query GetReadingTest($part: String!) {
    readingTestSection(part: $part) {
      id
      dbId
      description
      timeLimitMinutes
      textContents(first: 10) {
        edges {
          node {
            id
            dbId
            text
            title
            questions(first: 20) {
              edges {
                node {
                  id
                  dbId
                  questionText
                  questionType
                  options
                  marks
                  questionNumber
                }
              }
            }
          }
        }
      }
    }
  }
`;

const SUBMIT_READING_TEST = gql`
  mutation SubmitReadingTest($part: String!, $answers: String!) {
    submitReadingTest(part: $part, answers: $answers) {
      success
      message
      tryId
    }
  }
`;

interface OETReadingTestProps {
  onLogout: () => void;
}

const OETReadingTest: React.FC<OETReadingTestProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { progressId, part } = useParams();
  const [timeLeft, setTimeLeft] = useState(part === 'A' ? 15 * 60 : 45 * 60);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { loading, error, data } = useQuery<{ readingTestSection: ReadingSection }>(GET_READING_TEST, {
    variables: {
      part,
      progressId
    }
  });

  const [submitTest] = useMutation(SUBMIT_READING_TEST);

  // Timer effect
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const handleSubmit = async () => {
    if (!data?.readingTestSection || isSubmitting) return;
    
    setIsSubmitting(true);
    try {
      const result = await submitTest({
        variables: {
          part,
          answers: JSON.stringify(answers)
        }
      });

      if (result.data?.submitReadingTest.success) {
        navigate(`/oet/reading/results/${result.data.submitReadingTest.tryId}`);
      } else {
        alert(result.data?.submitReadingTest.message || 'Failed to submit test');
      }
    } catch (error) {
      alert('Error submitting test: ' + error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl">Loading...</div>
    </div>
  );

  if (error || !data?.readingTestSection) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl text-red-500">Error: {error?.message || 'Failed to load reading test'}</div>
    </div>
  );

  const readingSection = data.readingTestSection;

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet/reading/test')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Test Selection
          </button>

          {/* Timer and Progress */}
          <div className="bg-white rounded-lg shadow-md p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center">
              <Clock size={20} className="mr-2" style={{ color: 'var(--color-primary)' }} />
              <span className="text-lg font-semibold" style={{ color: 'var(--color-text-primary)' }}>{formatTime(timeLeft)}</span>
            </div>
            <div className="flex items-center">
              <span className="text-sm font-medium mr-2" style={{ color: 'var(--color-text-secondary)' }}>Part {part}</span>
              <div className="flex space-x-1">
                <div className={`w-3 h-3 rounded-full ${part === 'A' ? 'bg-primary' : 'bg-gray-300'}`} />
                <div className={`w-3 h-3 rounded-full ${part === 'B' ? 'bg-primary' : 'bg-gray-300'}`} />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            {readingSection.textContents.edges.map(({ node: textContent }) => (
              <div key={textContent.dbId}>
                {/* Reading Text */}
                <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                  <h2 className="text-xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>{textContent.title}</h2>
                  <div className="prose max-w-none">
                    {textContent.text.split('\n\n').map((paragraph: string, index: number) => (
                      <p key={index} className="mb-4" style={{ color: 'var(--color-text-secondary)' }}>{paragraph}</p>
                    ))}
                  </div>
                </div>

                {/* Questions for this text content */}
                <div className="bg-white rounded-lg shadow-md p-6">
                  <h3 className="text-lg font-semibold mb-4" style={{ color: 'var(--color-text-primary)' }}>Questions</h3>
                  <div className="space-y-6">
                    {textContent.questions.edges.map(({ node: q }) => (
                      <div key={q.dbId} className="border-b border-gray-200 pb-4 last:border-0">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-xs font-medium px-1.5 py-0.5 rounded-full bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 border border-blue-200">
                            {q.questionType}
                          </span>
                          <p className="font-medium" style={{ color: 'var(--color-text-primary)' }}>{q.questionText}</p>
                        </div>
                        {q.questionType === 'MCQ' && q.options && (
                          <div className="space-y-2">
                            {(Array.isArray(q.options) ? q.options : JSON.parse(q.options)).map((option: string) => (
                              <label
                                key={option}
                                className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                              >
                                <input
                                  type="radio"
                                  name={q.dbId}
                                  value={option}
                                  checked={answers[q.dbId] === option}
                                  onChange={(e) => handleAnswerChange(q.dbId, e.target.value)}
                                  className="h-4 w-4"
                                  style={{ color: 'var(--color-primary)' }}
                                />
                                <span style={{ color: 'var(--color-text-secondary)' }}>{option}</span>
                              </label>
                            ))}
                          </div>
                        )}
                        {q.questionType === 'FILL' && (
                          <input
                            type="text"
                            value={answers[q.dbId] || ''}
                            onChange={(e) => handleAnswerChange(q.dbId, e.target.value)}
                            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                            style={{
                              color: 'var(--color-text-primary)',
                              backgroundColor: 'var(--color-background-default)',
                              borderColor: 'var(--color-border-main)'
                            }}
                          />
                        )}
                        {q.questionType === 'TRUE_FALSE' && (
                          <div className="space-y-2">
                            {['True', 'False'].map((option) => (
                              <label
                                key={option}
                                className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer"
                              >
                                <input
                                  type="radio"
                                  name={q.dbId}
                                  value={option}
                                  checked={answers[q.dbId] === option}
                                  onChange={(e) => handleAnswerChange(q.dbId, e.target.value)}
                                  className="h-4 w-4"
                                  style={{ color: 'var(--color-primary)' }}
                                />
                                <span style={{ color: 'var(--color-text-secondary)' }}>{option}</span>
                              </label>
                            ))}
                          </div>
                        )}
                        {q.questionType === 'SUMMARY' && (
                          <div className="space-y-2">
                            <textarea
                              value={answers[q.dbId] || ''}
                              onChange={(e) => handleAnswerChange(q.dbId, e.target.value)}
                              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 min-h-[100px]"
                              placeholder="Type your summary here..."
                              style={{
                                color: 'var(--color-text-primary)',
                                backgroundColor: 'var(--color-background-default)',
                                borderColor: 'var(--color-border-main)'
                              }}
                            />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}

            {/* Submit Button */}
            <div className="flex justify-end">
              <button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all disabled:opacity-50"
                style={{
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Test'}
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETReadingTest; 