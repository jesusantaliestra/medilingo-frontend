import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';
import Navbar from '../../components/Navbar';
import { ArrowLeft, Headphones, CheckCircle, XCircle } from 'lucide-react';

const GET_LISTENING_PROGRESSION = gql`
  query GetListeningProgression {
    listeningSectionProgression {
      a
      b
      c
    }
  }
`;

interface OETListeningTestSelectionProps {
  onLogout: () => void;
}

const OETListeningTestSelection: React.FC<OETListeningTestSelectionProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { progressId } = useParams();
  const { data, loading, error } = useQuery(GET_LISTENING_PROGRESSION);

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet/listening')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to Listening Module
          </button>

          {/* Header */}
          <div className="text-center mb-8">
            <Headphones size={48} className="mx-auto mb-4" style={{ color: 'var(--color-primary)' }} />
            <h1 className="text-3xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>Listening Test</h1>
            <p className="text-gray-600">
              Choose a part to begin your listening test. Each part has different time limits and formats.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Part A Card */}
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>Part A</h2>
                {data?.listeningSectionProgression?.a ? (
                  <div className="flex items-center text-green-600">
                    <CheckCircle size={20} className="mr-1" />
                    <span className="text-sm">Completed</span>
                  </div>
                ) : (
                  <div className="flex items-center text-gray-500">
                    <XCircle size={20} className="mr-1" />
                    <span className="text-sm">Not completed</span>
                  </div>
                )}
              </div>
              <p className="text-gray-600 mb-4">
                Time limit: 30 minutes<br />
                Format: Fill in the blanks and summary completion based on medical conversations
              </p>
              <button
                onClick={() => navigate(`/oet/listening/test/A`)}
                className="w-full px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                style={{
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                Start Part A
              </button>
            </div>

            {/* Part B Card */}
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>Part B</h2>
                {data?.listeningSectionProgression?.b ? (
                  <div className="flex items-center text-green-600">
                    <CheckCircle size={20} className="mr-1" />
                    <span className="text-sm">Completed</span>
                  </div>
                ) : (
                  <div className="flex items-center text-gray-500">
                    <XCircle size={20} className="mr-1" />
                    <span className="text-sm">Not completed</span>
                  </div>
                )}
              </div>
              <p className="text-gray-600 mb-4">
                Time limit: 45 minutes<br />
                Format: Multiple choice questions based on healthcare presentations and discussions
              </p>
              <button
                onClick={() => navigate(`/oet/listening/test/B`)}
                className="w-full px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                style={{
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                Start Part B
              </button>
            </div>

            {/* Part B Card */}
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text-primary)' }}>Part C</h2>
                {data?.listeningSectionProgression?.b ? (
                  <div className="flex items-center text-green-600">
                    <CheckCircle size={20} className="mr-1" />
                    <span className="text-sm">Completed</span>
                  </div>
                ) : (
                  <div className="flex items-center text-gray-500">
                    <XCircle size={20} className="mr-1" />
                    <span className="text-sm">Not completed</span>
                  </div>
                )}
              </div>
              <p className="text-gray-600 mb-4">
                Time limit: 45 minutes<br />
                Format: Multiple choice questions based on healthcare presentations and discussions
              </p>
              <button
                onClick={() => navigate(`/oet/listening/test/C`)}
                className="w-full px-6 py-3 text-white rounded-lg font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all"
                style={{
                  background: 'var(--color-background-gradient)',
                  border: 'none'
                }}
              >
                Start Part C
              </button>
            </div>


          </div>
        </div>
      </main>
    </div>
  );
};

export default OETListeningTestSelection; 