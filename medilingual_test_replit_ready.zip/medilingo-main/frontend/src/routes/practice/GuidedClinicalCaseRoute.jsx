import React, { useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import GuidedClinicalCase from '../../components/GuidedClinicalCase';
import Navbar from '../../components/Navbar';
import Cookies from 'js-cookie';

const GuidedClinicalCaseRoute = ({ nativeLanguage, onLogout, levelSlug }) => {
  const navigate = useNavigate();
  const { practiceId } = useParams();

  // Ensure language is set even on direct page load/refresh
  useEffect(() => {
    if (!nativeLanguage) {
      const savedLanguage = Cookies.get('current_language');
      if (!savedLanguage) {
        // If no language is found in cookies, redirect to language chooser
        navigate('/choose-language');
      }
    }
  }, [nativeLanguage, navigate]);

  const handleComplete = (progress) => {
    // Handle completion and navigate back to level chooser page
    navigate('/levelchooser');
  };

  const handleBack = () => {
    navigate('/levelchooser');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar onLogout={onLogout} />
      <main className="flex-grow container mx-auto px-4 py-8 mt-20">
        <div className="mb-6">
          <button
            onClick={handleBack}
            className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
          >
            <ArrowLeft className="mr-2" size={20} />
            Back to Levels
          </button>
        </div>
        <GuidedClinicalCase 
          nativeLanguage={nativeLanguage || Cookies.get('current_language')}
          onComplete={handleComplete}
          levelSlug={levelSlug}
        />
      </main>
    </div>
  );
};

export default GuidedClinicalCaseRoute; 