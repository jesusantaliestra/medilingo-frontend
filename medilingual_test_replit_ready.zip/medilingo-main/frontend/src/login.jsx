import { useState } from 'react';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@apollo/client';
import { LOGIN_MUTATION } from './graphql/mutations';
import Cookies from 'js-cookie';
import { toast } from 'react-toastify';
import { theme } from './theme/theme';
import './styles/theme.css';
import AuthSidebar from './components/AuthSidebar';

export default function Login({ onLogin }) {
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const [form, setForm] = useState({
    email: '',
    password: ''
  });

  const [login, { loading: loginLoading }] = useMutation(LOGIN_MUTATION);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const { data } = await login({
        variables: {
          email: form.email,
          password: form.password
        }
      });

      if (data?.login?.login?.token) {
        // Store tokens in cookies
        Cookies.set('accessToken', data.login.login.token.access, { expires: data.login.login.token.expiresIn / 86400 });
        Cookies.set('refreshToken', data.login.login.token.refresh, { expires: data.login.login.token.refreshExpiresIn / 86400 });

        // Set language cookies if available in user data
        if (data.login.login.user.language) {
          Cookies.set('current_language', data.login.login.user.language, { expires: 365 });
        }
        if (data.login.login.user.languageToLearn) {
          Cookies.set('accept-language', data.login.login.user.languageToLearn, { expires: 365 });
        }

        // Call onLogin callback with user data
        if (onLogin) {
          onLogin({
            ...data.login.login.user,
            isNewUser: false
          });
        }

        // Show success toast
        toast.success('Login successful! Welcome to MediLingual.');

        // Navigate to level chooser
        navigate('/levelchooser');
      }
    } catch (error) {
      toast.error(error.message || 'Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="flex min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <AuthSidebar />

      {/* Right panel with login form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Welcome back</h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleInputChange}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={form.password}
                  onChange={handleInputChange}
                  className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-gray-400" />
                  ) : (
                    <Eye className="h-5 w-5 text-gray-400" />
                  )}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-sm">
                <a href="/forgot-password" className="font-medium text-primary hover:text-primary-dark">
                  Forgot your password?
                </a>
              </div>
              <div className="text-sm">
                <a href="/signup" className="font-medium text-primary hover:text-primary-dark">
                  Don't have an account?
                </a>
              </div>
            </div>

            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
              style={{
                background: 'var(--color-background-gradient)',
                border: 'none'
              }}
              disabled={loginLoading}
            >
              {loginLoading ? 'Signing in...' : 'Sign in'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}