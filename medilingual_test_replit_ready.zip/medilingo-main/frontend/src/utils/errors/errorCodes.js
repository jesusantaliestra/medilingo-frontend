export const ErrorCodes = {
  // Authentication Errors
  UNAUTHORIZED: "AUTH_001",
  TOKEN_EXPIRED: "AUTH_002",
  INVALID_CREDENTIALS: "AUTH_003",
  
  // Subscription Errors
  INVALID_SUBSCRIPTION: "SUB_001",
  NO_CREDITS: "SUB_002",
  SUBSCRIPTION_EXPIRED: "SUB_003",
  INVALID_OET_SUBSCRIPTION: "SUB_004",
  // Network Errors
  NETWORK_ERROR: "NET_001",
  TIMEOUT: "NET_002",
  
  // Validation Errors
  INVALID_INPUT: "VAL_001",
  MISSING_REQUIRED_FIELD: "VAL_002",
  
  // Server Errors
  INTERNAL_SERVER_ERROR: "SRV_001",
  SERVICE_UNAVAILABLE: "SRV_002"
};

export const ErrorMessages = {
  [ErrorCodes.UNAUTHORIZED]: "You are not authorized to perform this action",
  [ErrorCodes.TOKEN_EXPIRED]: "Your session has expired. Please log in again",
  [ErrorCodes.INVALID_CREDENTIALS]: "Invalid username or password",
  [ErrorCodes.INVALID_SUBSCRIPTION]: "Your subscription is invalid or has expired",
  [ErrorCodes.NO_CREDITS]: "You have no credits remaining",
  [ErrorCodes.SUBSCRIPTION_EXPIRED]: "Your subscription has expired",
  [ErrorCodes.NETWORK_ERROR]: "Network connection error",
  [ErrorCodes.TIMEOUT]: "Request timed out",
  [ErrorCodes.INVALID_INPUT]: "Invalid input provided",
  [ErrorCodes.MISSING_REQUIRED_FIELD]: "Required field is missing",
  [ErrorCodes.INTERNAL_SERVER_ERROR]: "Internal server error",
  [ErrorCodes.SERVICE_UNAVAILABLE]: "Service is temporarily unavailable"
}; 