import { ErrorCodes, ErrorMessages } from './errorCodes';
import Cookies from 'js-cookie';

class ErrorHandler {
  constructor(navigateFunction = null) {
    this.navigateFunction = navigateFunction;
  }

  setNavigateFunction(navigateFunction) {
    this.navigateFunction = navigateFunction;
  }

  handleGraphQLErrors(graphQLErrors) {
    if (!graphQLErrors) return;

    for (const err of graphQLErrors) {
      const errorCode = err.extensions?.code;
      
      // Handle subscription errors
      if (errorCode === ErrorCodes.INVALID_SUBSCRIPTION || 
          errorCode === ErrorCodes.NO_CREDITS || 
          errorCode === ErrorCodes.INVALID_OET_SUBSCRIPTION ||
          errorCode === ErrorCodes.SUBSCRIPTION_EXPIRED) {
        this.redirectToPricing();
        return;
      }

      // Handle authentication errors
      if (errorCode === ErrorCodes.UNAUTHORIZED || 
          errorCode === ErrorCodes.TOKEN_EXPIRED ||
          err.message.includes('token_invalid_or_expired')) {
        this.handleAuthError();
        return;
      }

      // Log other GraphQL errors
      console.error(`[GraphQL Error]: ${err.message}`, err);
    }
  }

  handleNetworkError(networkError) {
    if (!networkError) return;
    
    console.error(`[Network Error]: ${networkError}`);
    // You could add specific network error handling here
  }

  handleAuthError() {
    const refreshToken = Cookies.get('refreshToken');
    if (refreshToken) {
      // TODO: Implement token refresh logic
      this.redirectToLogin();
    } else {
      this.redirectToLogin();
    }
  }

  redirectToLogin() {
    if (this.navigateFunction) {
      this.navigateFunction('/');
    } else {
      window.location.href = '/';
    }
  }

  redirectToPricing() {
    if (this.navigateFunction) {
      this.navigateFunction('/pricing');
    } else {
      window.location.href = '/pricing';
    }
  }

  getErrorMessage(errorCode) {
    return ErrorMessages[errorCode] || 'An unexpected error occurred';
  }
}

export default ErrorHandler; 