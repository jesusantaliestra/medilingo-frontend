export interface Language {
  code: string;
  name: string;
  nativeName: string;
  flagCode: string;
  originCountry: string;
}

export const languageToLearn: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', flagCode: 'us', originCountry: 'United States' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flagCode: 'es', originCountry: 'Spain' },
  { code: 'fr', name: 'French', nativeName: 'Français', flagCode: 'fr', originCountry: 'France' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flagCode: 'de', originCountry: 'Germany' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flagCode: 'pt', originCountry: 'Portugal' },
]


// All available languages with their codes, names, and native names
export const languages: Language[] = [
  { code: 'en', name: 'English', nativeName: 'English', flagCode: 'us', originCountry: 'United States' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flagCode: 'es', originCountry: 'Spain' },
  { code: 'fr', name: 'French', nativeName: 'Français', flagCode: 'fr', originCountry: 'France' },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flagCode: 'de', originCountry: 'Germany' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flagCode: 'it', originCountry: 'Italy' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flagCode: 'pt', originCountry: 'Portugal' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski', flagCode: 'pl', originCountry: 'Poland' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands', flagCode: 'nl', originCountry: 'Netherlands' },
  { code: 'ro', name: 'Romanian', nativeName: 'Română', flagCode: 'ro', originCountry: 'Romania' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά', flagCode: 'gr', originCountry: 'Greece' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska', flagCode: 'se', originCountry: 'Sweden' },
  { code: 'da', name: 'Danish', nativeName: 'Dansk', flagCode: 'dk', originCountry: 'Denmark' },
  { code: 'fi', name: 'Finnish', nativeName: 'Suomi', flagCode: 'fi', originCountry: 'Finland' },
  { code: 'cs', name: 'Czech', nativeName: 'Čeština', flagCode: 'cz', originCountry: 'Czech Republic' },
  { code: 'sk', name: 'Slovak', nativeName: 'Slovenčina', flagCode: 'sk', originCountry: 'Slovakia' },
  { code: 'hu', name: 'Hungarian', nativeName: 'Magyar', flagCode: 'hu', originCountry: 'Hungary' },
  { code: 'bg', name: 'Bulgarian', nativeName: 'Български', flagCode: 'bg', originCountry: 'Bulgaria' },
  { code: 'hr', name: 'Croatian', nativeName: 'Hrvatski', flagCode: 'hr', originCountry: 'Croatia' },
  { code: 'lt', name: 'Lithuanian', nativeName: 'Lietuvių', flagCode: 'lt', originCountry: 'Lithuania' },
  { code: 'lv', name: 'Latvian', nativeName: 'Latviešu', flagCode: 'lv', originCountry: 'Latvia' },
  { code: 'et', name: 'Estonian', nativeName: 'Eesti', flagCode: 'ee', originCountry: 'Estonia' },
  { code: 'sl', name: 'Slovenian', nativeName: 'Slovenščina', flagCode: 'si', originCountry: 'Slovenia' },
  { code: 'ga', name: 'Irish', nativeName: 'Gaeilge', flagCode: 'ie', originCountry: 'Ireland' },
  { code: 'mt', name: 'Maltese', nativeName: 'Malti', flagCode: 'mt', originCountry: 'Malta' },
  { code: 'nb', name: 'Norwegian Bokmål', nativeName: 'Norsk Bokmål', flagCode: 'no', originCountry: 'Norway' },
  { code: 'is', name: 'Icelandic', nativeName: 'Íslenska', flagCode: 'is', originCountry: 'Iceland' },
  { code: 'sq', name: 'Albanian', nativeName: 'Shqip', flagCode: 'al', originCountry: 'Albania' },
  { code: 'mk', name: 'Macedonian', nativeName: 'Македонски', flagCode: 'mk', originCountry: 'North Macedonia' },
  { code: 'bs', name: 'Bosnian', nativeName: 'Bosanski', flagCode: 'ba', originCountry: 'Bosnia and Herzegovina' },
  { code: 'sr', name: 'Serbian', nativeName: 'Српски', flagCode: 'rs', originCountry: 'Serbia' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский', flagCode: 'ru', originCountry: 'Russia' },
  { code: 'uk', name: 'Ukrainian', nativeName: 'Українська', flagCode: 'ua', originCountry: 'Ukraine' },
  { code: 'be', name: 'Belarusian', nativeName: 'Беларуская', flagCode: 'by', originCountry: 'Belarus' },
  { code: 'hy', name: 'Armenian', nativeName: 'Հայերեն', flagCode: 'am', originCountry: 'Armenia' },
  { code: 'ka', name: 'Georgian', nativeName: 'ქართული', flagCode: 'ge', originCountry: 'Georgia' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flagCode: 'in', originCountry: 'India' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', flagCode: 'bd', originCountry: 'Bangladesh' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', flagCode: 'in', originCountry: 'India' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', flagCode: 'in', originCountry: 'India' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', flagCode: 'in', originCountry: 'India' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', flagCode: 'pk', originCountry: 'Pakistan' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', flagCode: 'in', originCountry: 'India' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flagCode: 'in', originCountry: 'India' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', flagCode: 'in', originCountry: 'India' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', flagCode: 'in', originCountry: 'India' },
  { code: 'or', name: 'Odia', nativeName: 'ଓଡ଼ିଆ', flagCode: 'in', originCountry: 'India' },
  { code: 'si', name: 'Sinhala', nativeName: 'සිංහල', flagCode: 'lk', originCountry: 'Sri Lanka' },
  { code: 'ne', name: 'Nepali', nativeName: 'नेपाली', flagCode: 'np', originCountry: 'Nepal' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', flagCode: 'id', originCountry: 'Indonesia' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu', flagCode: 'my', originCountry: 'Malaysia' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', flagCode: 'vn', originCountry: 'Vietnam' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย', flagCode: 'th', originCountry: 'Thailand' },
  { code: 'my', name: 'Burmese', nativeName: 'မြန်မာ', flagCode: 'mm', originCountry: 'Myanmar' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flagCode: 'cn', originCountry: 'China' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flagCode: 'jp', originCountry: 'Japan' },
  { code: 'ko', name: 'Korean', nativeName: '한국어', flagCode: 'kr', originCountry: 'South Korea' },
  { code: 'km', name: 'Khmer', nativeName: 'ភាសាខ្មែរ', flagCode: 'kh', originCountry: 'Cambodia' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flagCode: 'sa', originCountry: 'Saudi Arabia' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی', flagCode: 'ir', originCountry: 'Iran' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית', flagCode: 'il', originCountry: 'Israel' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe', flagCode: 'tr', originCountry: 'Turkey' },
  { code: 'ku', name: 'Kurdish', nativeName: 'Kurdî', flagCode: 'iq', originCountry: 'Iraq' },
  { code: 'ps', name: 'Pashto', nativeName: 'پښتو', flagCode: 'af', originCountry: 'Afghanistan' },
  { code: 'sw', name: 'Swahili', nativeName: 'Kiswahili', flagCode: 'ke', originCountry: 'Kenya' },
  { code: 'am', name: 'Amharic', nativeName: 'አማርኛ', flagCode: 'et', originCountry: 'Ethiopia' },
  { code: 'yo', name: 'Yoruba', nativeName: 'Yorùbá', flagCode: 'ng', originCountry: 'Nigeria' },
  { code: 'ig', name: 'Igbo', nativeName: 'Igbo', flagCode: 'ng', originCountry: 'Nigeria' },
  { code: 'ha', name: 'Hausa', nativeName: 'Hausa', flagCode: 'ng', originCountry: 'Nigeria' },
  { code: 'rw', name: 'Kinyarwanda', nativeName: 'Ikinyarwanda', flagCode: 'rw', originCountry: 'Rwanda' },
  { code: 'xh', name: 'Xhosa', nativeName: 'isiXhosa', flagCode: 'za', originCountry: 'South Africa' },
  { code: 'zu', name: 'Zulu', nativeName: 'isiZulu', flagCode: 'za', originCountry: 'South Africa' },
  { code: 'so', name: 'Somali', nativeName: 'Soomaali', flagCode: 'so', originCountry: 'Somalia' },
  { code: 'ht', name: 'Haitian Creole', nativeName: 'Kreyòl ayisyen', flagCode: 'ht', originCountry: 'Haiti' },
  { code: 'qu', name: 'Quechua', nativeName: 'Runa Simi', flagCode: 'pe', originCountry: 'Peru' },
  { code: 'gn', name: 'Guarani', nativeName: 'Avañe\'ẽ', flagCode: 'py', originCountry: 'Paraguay' },
  { code: 'tl', name: 'Tagalog', nativeName: 'Tagalog', flagCode: 'ph', originCountry: 'Philippines' },
  { code: 'ceb', name: 'Cebuano', nativeName: 'Binisaya', flagCode: 'ph', originCountry: 'Philippines' }
];

// Helper function to get language info from code
export const getLanguageInfo = (code: string): Language | null => {
  return languages.find(lang => lang.code === code) || null;
};

// Helper function to get all languages for a country
export const getLanguagesByCountry = (countryCode: string): Language[] => {
  return languages.filter(lang => 
    lang.flagCode.toLowerCase() === countryCode.toLowerCase()
  );
};

// Function to detect user language and country
export const detectUserLanguage = async (): Promise<{ language: Language; availableLanguages: Language[] }> => {
  // First, get browser language
  const browserLanguage = navigator.language.split('-')[0];
  
  // If browser language is not English, find the language object
  if (browserLanguage !== 'en') {
    const langObj = languages.find(lang => lang.code === browserLanguage);
    
    if (langObj) {
      const availableLanguages = getLanguagesByCountry(langObj.originCountry);
      return {
        language: langObj,
        availableLanguages
      };
    }
  }

  try {
    // If browser language is English or not found, get user's country from Cloudflare
    const response = await fetch('https://cloudflare.com/cdn-cgi/trace');
    const text = await response.text();
    
    // Parse the response to get country code
    const lines = text.split('\n');
    const countryLine = lines.find(line => line.startsWith('loc='));
    const countryCode = countryLine ? countryLine.split('=')[1] : 'US';
    
    // Get all languages for this country
    const availableLanguages = getLanguagesByCountry(countryCode);
    
    // Return the first language object found for this country, or default to English
    const selectedLanguage = availableLanguages.length > 0 
      ? availableLanguages[0] 
      : languages.find(lang => lang.code === 'en')!;
    
    return {
      language: selectedLanguage,
      availableLanguages: availableLanguages.length > 0 
        ? availableLanguages 
        : [languages.find(lang => lang.code === 'en')!]
    };
  } catch (error) {
    // Return English language object as default
    const englishLang = languages.find(lang => lang.code === 'en')!;
    return {
      language: englishLang,
      availableLanguages: [englishLang]
    };
  }
}; 