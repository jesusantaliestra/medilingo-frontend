import React from 'react';
import PageWrapper from '../../components/PageWrapper';

const CookiePolicy: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Cookie Policy</h1>
        <div className="prose max-w-none">
          <p className="mb-4">Last updated: {new Date().toLocaleDateString()}</p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">1. What Are Cookies</h2>
          <p className="mb-4">
            Cookies are small text files that are placed on your computer or mobile device when you visit a website. 
            They are widely used to make websites work more efficiently and provide a better user experience.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">2. How We Use Cookies</h2>
          <p className="mb-4">Santaliestra Limited uses cookies on the MediLingual website for the following purposes:</p>
          <ul className="list-disc pl-6 mb-4">
            <li>Essential cookies: These cookies are necessary for the website to function properly</li>
            <li>Authentication cookies: To keep you signed in</li>
            <li>Preference cookies: To remember your settings and preferences</li>
            <li>Analytics cookies: To help us understand how visitors interact with our website</li>
            <li>Performance cookies: To help us improve the performance of our website</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">3. Types of Cookies We Use</h2>
          <p className="mb-4">We use the following types of cookies:</p>
          <ul className="list-disc pl-6 mb-4">
            <li>Session cookies: These are temporary cookies that expire when you close your browser</li>
            <li>Persistent cookies: These remain on your device until they expire or you delete them</li>
            <li>First-party cookies: These are set by our website</li>
            <li>Third-party cookies: These are set by third-party services we use</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">4. Managing Cookies</h2>
          <p className="mb-4">
            Most web browsers allow you to control cookies through their settings preferences. However, limiting cookies 
            may impact your experience using our website. You can learn more about cookies and how to manage them at 
            <a href="https://www.aboutcookies.org" className="text-blue-600 hover:underline"> www.aboutcookies.org</a>.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">5. Third-Party Cookies</h2>
          <p className="mb-4">
            We use third-party services that may set cookies on your device. These services include:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Google Analytics for website analytics</li>
            <li>Stripe for payment processing</li>
            <li>Other third-party services that help us provide our services</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">6. Updates to This Policy</h2>
          <p className="mb-4">
            We may update this Cookie Policy from time to time. We will notify you of any changes by posting the new 
            Cookie Policy on this page and updating the "Last updated" date.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">7. Contact Us</h2>
          <p className="mb-4">
            If you have any questions about our Cookie Policy, please contact Santaliestra Limited at:
            <br />
            Email: privacy@medilingual.app
          </p>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicy; 