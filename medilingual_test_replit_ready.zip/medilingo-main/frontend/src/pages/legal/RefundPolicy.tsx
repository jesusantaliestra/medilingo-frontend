import React from 'react';
import PageWrapper from '../../components/PageWrapper';

const RefundPolicy: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Refund Policy</h1>
        <div className="prose max-w-none">
          <p className="mb-4">Last updated: {new Date().toLocaleDateString()}</p>
          
          <h2 className="text-2xl font-semibold mt-8 mb-4">1. Overview</h2>
          <p className="mb-4">
            At MediLingual, a service provided by Santaliestra Limited, we strive to ensure complete satisfaction with our services. This Refund Policy outlines 
            the terms and conditions for requesting and receiving refunds for our services.
          </p>

          <h2 className="text-2xl font-semibold mt-8 mb-4">2. Subscription Refunds</h2>
          <p className="mb-4">
            For subscription-based services:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>You may request a full refund within 14 days of your initial subscription purchase</li>
            <li>Refunds will not be provided for partial months of service</li>
            <li>Refunds will not be provided for subscription renewals</li>
            <li>Refunds will not be provided for used credits or completed services</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">3. Credit Package Refunds</h2>
          <p className="mb-4">
            For credit package purchases:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Unused credits are eligible for a refund within 30 days of purchase</li>
            <li>Refunds will be prorated based on the number of unused credits</li>
            <li>Used credits are not eligible for refund</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">4. Refund Process</h2>
          <p className="mb-4">
            To request a refund:
          </p>
          <ol className="list-decimal pl-6 mb-4">
            <li>Contact our support team at support@medilingual.app</li>
            <li>Provide your account details and reason for the refund request</li>
            <li>Allow up to 5-7 business days for the refund to be processed</li>
            <li>Refunds will be issued to the original payment method</li>
          </ol>

          <h2 className="text-2xl font-semibold mt-8 mb-4">5. Exceptions</h2>
          <p className="mb-4">
            We may consider exceptions to this policy in cases of:
          </p>
          <ul className="list-disc pl-6 mb-4">
            <li>Technical issues preventing service access</li>
            <li>Service unavailability for extended periods</li>
            <li>Other exceptional circumstances at our discretion</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8 mb-4">6. Contact Us</h2>
          <p className="mb-4">
            If you have any questions about our Refund Policy, please contact Santaliestra Limited at:
            <br />
            Email: support@medilingual.app
          </p>
        </div>
      </div>
    </div>
  );
};

export default RefundPolicy; 