import React from 'react';
import { Check, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery, gql } from '@apollo/client';
import Navbar from '../components/Navbar';
import Cookies from 'js-cookie';

const GET_PLANS = gql`
  query GetPlans {
    allPlans {
      id
      name
      price
      frequency
      creditsAllocated
      featuresIncluded
      featuresExcluded
      paymentLink
    }
  }
`;

const Pricing: React.FC = () => {
  const navigate = useNavigate();
  const { loading, error, data } = useQuery(GET_PLANS);

  const handleLogout = () => {
    Cookies.remove('accessToken');
    Cookies.remove('refreshToken');
    Cookies.remove('current_language');
    Cookies.remove('accept-language');
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--color-background-default)' }}>
        <Navbar onLogout={handleLogout} />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--color-background-default)' }}>
        <Navbar onLogout={handleLogout} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-red-500">Error loading plans: {error.message}</div>
        </div>
      </div>
    );
  }

  const plans = data.allPlans.map((plan, index) => ({
    ...plan,
    color: index === 0 ? 'from-blue-500 to-blue-600' : 
           index === 1 ? 'from-purple-500 to-purple-600' : 
           'from-indigo-500 to-indigo-600',
    buttonText: index === 0 ? 'Start with Basic' : 
                index === 1 ? 'Get Professional' : 
                'Go Premium',
    popular: index === 1
  }));

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={handleLogout} />
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-16 mt-16">
        <div className="text-center max-w-6xl mx-auto">
          <h1 className="text-5xl font-bold mb-6" style={{ color: 'var(--color-text-primary)' }}>
            Choose Your Learning Path
          </h1>
          <p className="text-2xl mb-12" style={{ color: 'var(--color-text-secondary)' }}>
            Select the perfect plan to accelerate your medical English journey
          </p>
          
          {/* Pricing Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {plans.map((plan, index) => (
              <div 
                key={plan.id}
                className={`relative rounded-2xl p-8 transition-all duration-300 transform hover:-translate-y-2 ${
                  plan.popular ? 'ring-2 ring-purple-500' : ''
                }`}
                style={{ 
                  backgroundColor: 'var(--color-background-paper)',
                  border: '1px solid var(--color-border-main)'
                }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-purple-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <h2 className="text-2xl font-bold mb-4" style={{ color: 'var(--color-text-primary)' }}>
                  {plan.name}
                </h2>
                
                <div className="mb-6">
                  <div className="flex items-end justify-center">
                    <span className="text-5xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
                      ${plan.price}
                    </span>
                    <span className="text-xl ml-2 mb-1" style={{ color: 'var(--color-text-secondary)' }}>
                      /{plan.frequency}
                    </span>
                  </div>
                  <p className="text-sm mt-2" style={{ color: 'var(--color-text-secondary)' }}>
                    {plan.creditsAllocated} credits included
                  </p>
                </div>

                <div className="space-y-4 mb-8">
                  {plan.featuresIncluded.map((feature, idx) => (
                    <div key={idx} className="flex items-center">
                      <Check className="h-5 w-5 mr-3 flex-shrink-0" style={{ color: 'var(--color-success)' }} />
                      <span style={{ color: 'var(--color-text-primary)' }}>{feature}</span>
                    </div>
                  ))}
                  {plan.featuresExcluded.map((feature, idx) => (
                    <div key={idx} className="flex items-center opacity-50">
                      <X className="h-5 w-5 mr-3 flex-shrink-0" style={{ color: 'var(--color-error)' }} />
                      <span style={{ color: 'var(--color-text-secondary)' }}>{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => window.location.href = plan.paymentLink}
                  className={`w-full py-3 rounded-lg text-white font-medium transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl bg-gradient-to-r ${plan.color}`}
                >
                  {plan.buttonText}
                </button>
              </div>
            ))}
          </div>

          {/* Bottom Text */}
          <div className="text-center">
            <p className="text-sm" style={{ color: 'var(--color-text-secondary)' }}>
              All plans include a 14-day free trial • No credit card required • Cancel anytime
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Banner */}
      <div 
        className="w-full py-8 text-center"
        style={{ 
          background: 'var(--color-background-gradient)',
          color: 'white'
        }}
      >
        <p className="text-lg font-medium">
          Join thousands of healthcare professionals improving their medical English
        </p>
      </div>
    </div>
  );
};

export default Pricing; 