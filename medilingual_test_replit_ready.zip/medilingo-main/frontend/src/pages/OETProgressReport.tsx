import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@apollo/client';
import { gql } from '@apollo/client';
import Navbar from '../components/Navbar';
import { ArrowLeft, BookOpen, Edit, Headphones, Mic, BarChart2 } from 'lucide-react';

const GET_USER_PROGRESS = gql`
  query GetUserProgress {
    latestReadingResults {
      id
      overallScore
      grade
      createdAt
      readingSection {
        title
        part
      }
    }
    writingTestSection {
      id
      title
      description
    }
    getWritingSection(progressId: "1")
    speakingTestResults(progressId: "1")
    latestListeningResults {
      id
      overallScore
      grade
      createdAt
      listeningSection {
        title
        part
      }
    }
  }
`;

interface OETProgressReportProps {
  onLogout: () => void;
}

const OETProgressReport: React.FC<OETProgressReportProps> = ({ onLogout }) => {
  const navigate = useNavigate();
  const { loading, error, data } = useQuery(GET_USER_PROGRESS);

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl">Loading progress report...</div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <div className="text-xl text-red-500">Error loading progress report</div>
    </div>
  );

  const readingData = data?.latestReadingResults || null;
  const writingData = data?.getWritingSection ? JSON.parse(data.getWritingSection)?.submission : null;
  const speakingData = data?.speakingTestResults ? JSON.parse(data.speakingTestResults) : null;
  const listeningData = data?.latestListeningResults || null;

  // Calculate total score
  const totalScore = Math.round(
    ((readingData?.overallScore || 0) + 
     (writingData?.score || 0) + 
     (speakingData?.speaking_score || 0) + 
     (listeningData?.overallScore || 0)) / 4
  );

  const sections = [
    {
      id: 'reading',
      title: 'Reading',
      score: readingData?.overallScore || 0,
      band: readingData?.grade || 'Not Taken',
      icon: <BookOpen size={24} className="text-blue-600" />,
      color: '#007BFF',
      lastAttempt: readingData?.createdAt,
      status: readingData ? 'Completed' : 'Not Taken'
    },
    {
      id: 'writing',
      title: 'Writing',
      score: writingData?.score || 0,
      band: writingData?.band || 'Not Taken',
      icon: <Edit size={24} className="text-green-600" />,
      color: '#4CAF50',
      lastAttempt: writingData?.completed_at,
      status: writingData ? 'Completed' : 'Not Taken'
    },
    {
      id: 'speaking',
      title: 'Speaking',
      score: speakingData?.speaking_score || 0,
      band: speakingData?.speaking_progress?.band || 'Not Taken',
      icon: <Mic size={24} className="text-orange-600" />,
      color: '#FF5722',
      lastAttempt: speakingData?.speaking_progress?.completed_at,
      status: speakingData ? 'Completed' : 'Not Taken'
    },
    {
      id: 'listening',
      title: 'Listening',
      score: listeningData?.overallScore || 0,
      band: listeningData?.grade || 'Not Taken',
      icon: <Headphones size={24} className="text-purple-600" />,
      color: '#9C27B0',
      lastAttempt: listeningData?.createdAt,
      status: listeningData ? 'Completed' : 'Not Taken'
    }
  ];

  const getBandColor = (band: string) => {
    if (band === 'Not Taken') return 'text-gray-500';
    switch (band) {
      case 'A': return 'text-green-600';
      case 'B+': return 'text-blue-600';
      case 'B': return 'text-blue-500';
      case 'C+': return 'text-yellow-600';
      case 'C': return 'text-yellow-500';
      case 'D': return 'text-orange-600';
      default: return 'text-red-600';
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'No attempts yet';
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-8 mt-20">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <button 
            onClick={() => navigate('/oet')}
            className="mb-6 flex items-center text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft size={20} className="mr-2" />
            Back to OET Dashboard
          </button>

          {/* Title Section */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800">OET Progress Report</h1>
            <p className="text-gray-600 mt-2">
              Track your performance across all OET sections
            </p>
          </div>

          {/* Overall Score Card */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <BarChart2 size={24} className="text-blue-600 mr-2" />
                <h2 className="text-xl font-bold text-gray-800">Overall Score</h2>
              </div>
              <div className="text-2xl font-bold" style={{ color: 'var(--color-text-primary)' }}>
                {totalScore}%
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="h-2.5 rounded-full" 
                style={{ 
                  width: `${totalScore}%`,
                  background: 'var(--color-background-gradient)'
                }}
              ></div>
            </div>
          </div>

          {/* Section Scores */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sections.map((section) => (
              <div key={section.id} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    {section.icon}
                    <h3 className="text-lg font-semibold text-gray-800 ml-2">{section.title}</h3>
                  </div>
                  <div className={`text-xl font-bold ${getBandColor(section.band)}`}>
                    {section.band === 'Not Taken' ? 'Not Taken' : `Band ${section.band}`}
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="h-2.5 rounded-full" 
                    style={{ 
                      width: `${section.score}%`,
                      backgroundColor: section.color
                    }}
                  ></div>
                </div>
                <div className="mt-2 text-sm text-gray-600">
                  Score: {section.score}%
                </div>
                <div className="mt-1 text-xs text-gray-500">
                  Last attempt: {formatDate(section.lastAttempt)}
                </div>
                <div className="mt-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    section.status === 'Completed' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {section.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETProgressReport; 