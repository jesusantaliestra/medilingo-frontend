import React from 'react';

const About = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 mt-20">
      <h1 className="text-3xl font-bold mb-8 text-gray-900">About Us</h1>
      
      <div className="space-y-6 text-gray-700 leading-relaxed">
        <p>
          Medilingual is a digital platform owned by Santaliestra Limited, an Irish-registered
          company, created with one mission: to empower healthcare professionals worldwide to
          communicate confidently and effectively in English and other clinical languages.
        </p>

        <p>
          We believe that language should never be a barrier to quality healthcare. That's why we built
          Medilingual: an innovative web and mobile app that combines artificial intelligence, clinical
          roleplay, multilingual translation, and real-time pronunciation feedback to help doctors,
          nurses, and allied professionals master medical English and prepare for international
          certification exams like the OET.
        </p>

        <p>
          More than just a language tool, Medilingual simulates real consultations and offers
          personalized learning paths, supporting professionals from Latin America, Africa, Asia, and
          Europe in their journey to integrate into global healthcare systems.
        </p>

        <p>
          We are proud to be building the future of clinical communication — smart, scalable, and
          accessible to all.
        </p>
      </div>
    </div>
  );
};

export default About; 