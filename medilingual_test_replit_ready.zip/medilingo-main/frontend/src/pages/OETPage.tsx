import React from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { BookOpen, Edit, Headphones, Mic, Timer, ArrowRight, Info, BarChart2 } from 'lucide-react';

interface OETPageProps {
  onLogout: () => void;
}

const OETPage: React.FC<OETPageProps> = ({ onLogout }) => {
  const navigate = useNavigate();

  const modules = [
    {
      id: 'reading',
      title: 'Reading',
      description: 'Practice medical texts with OET-style questions, divided into Part A, B & C with countdown timers.',
      icon: <BookOpen size={28} className="text-white" />,
      features: [
        'Skim and scan medical texts',
        'Answer matching, short answer, and multiple choice',
        'AI feedback with text references',
        'Part A (15 min), Part B & C (45 min) timers'
      ],
      color: '#007BFF',
      url: '/oet/reading/test'
    },
    {
      id: 'writing',
      title: 'Writing',
      description: 'Build clinical letters with editable templates and timers for reading and writing phases.',
      icon: <Edit size={28} className="text-white" />,
      features: [
        'Editable clinical letter builder',
        'Medical case notes included',
        'AI feedback on OET criteria',
        '5 min reading + 40 min writing timer'
      ],
      color: '#4CAF50',
      url: '/oet/writing/test'
    },
    {
      id: 'speaking',
      title: 'Speaking',
      description: 'Roleplay medical scenarios with animated avatars and countdown timers for each task.',
      icon: <Mic size={28} className="text-white" />,
      features: [
        'Roleplay simulator with animated avatars',
        'Scenario examples (e.g. post-MI consultation)',
        'Speech recognition with feedback',
        '3 min prep + 5 min speaking timer'
      ],
      color: '#FF5722',
      url: '/oet/speaking/test/first'
    },
    {
      id: 'listening',
      title: 'Listening',
      description: 'Practice with simulated audio interface and timed sections replicating real OET conditions.',
      icon: <Headphones size={28} className="text-white" />,
      features: [
        'Simulated audio with real-time timer',
        'Fill-in-the-blanks and multiple choice questions',
        'Auto-scoring with instant explanations',
        'Optional translation support'
      ],
      color: '#9C27B0',
      url: '/oet/listening/test'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar onLogout={onLogout} />
      
      <main className="container mx-auto px-4 py-6 max-w-6xl mt-20">
        {/* Title Section */}
        <div className="mb-10">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">OET Exam Preparation</h1>
              <p className="text-gray-600 mt-2">
                Complete preparation for all four components of the Occupational English Test
              </p>
            </div>
            <button
              onClick={() => navigate('/oet/progress')}
              className="flex items-center px-4 py-2 text-white rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200"
              style={{
                background: 'var(--color-background-gradient)',
                border: 'none'
              }}
            >
              <BarChart2 size={20} className="mr-2" />
              Test Progress Report
            </button>
          </div>
        </div>

        {/* About OET Info Card */}
        <div className="mb-10 p-6 rounded-lg border border-blue-100 bg-white shadow-sm flex items-start">
          <div className="mr-4 p-2 rounded-full bg-blue-100">
            <Info size={24} className="text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-blue-700 mb-2">About OET Exam</h3>
            <p className="text-gray-700">
              The Occupational English Test (OET) is a language proficiency test for healthcare professionals 
              seeking to register and practice in an English-speaking environment. Our practice modules 
              are designed to match the real exam format, helping you achieve the scores you need.
            </p>
          </div>
        </div>

        {/* Main Modules Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {modules.map((module) => (
            <div 
              key={module.id}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-all duration-200"
            >
              <div className="flex items-start p-6">
                {/* Module Icon */}
                <div 
                  className="p-3 rounded-lg mr-4 flex-shrink-0"
                  style={{ backgroundColor: module.color }}
                >
                  {module.icon}
                </div>

                {/* Module Content */}
                <div className="flex-1">
                  <h2 className="text-xl font-bold text-gray-800">{module.title}</h2>
                  <p className="mt-1 text-gray-600">{module.description}</p>
                  
                  <div className="flex items-center mt-3 mb-2">
                    <Timer size={16} className="text-gray-500 mr-2" />
                    <span className="text-sm font-medium text-gray-600">Real-time exam timer</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-2 mt-4">
                    {module.features.map((feature, index) => (
                      <div key={index} className="flex items-start">
                        <div 
                          className="w-4 h-4 mt-0.5 mr-2 rounded-full flex items-center justify-center"
                          style={{ backgroundColor: `${module.color}30` }}
                        >
                          <div className="w-2 h-2 rounded-full" style={{ backgroundColor: module.color }}></div>
                        </div>
                        <span className="text-sm text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <button 
                    className="w-full mt-6 flex items-center justify-center px-4 py-3 text-sm font-medium text-white rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200"
                    onClick={() => navigate(module.url)}
                    style={{
                      background: 'var(--color-background-gradient)',
                      border: 'none'
                    }}
                  >
                    Start {module.title} Practice
                    <ArrowRight className="ml-2" size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tips Section */}
        <div className="mt-10 bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">OET Success Tips</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-blue-50">
              <h4 className="font-semibold text-blue-700">Time Management</h4>
              <p className="text-gray-700 text-sm mt-1">Practice with our built-in timers to develop efficient test-taking strategies for each section.</p>
            </div>
            <div className="p-4 rounded-lg bg-green-50">
              <h4 className="font-semibold text-green-700">Regular Practice</h4>
              <p className="text-gray-700 text-sm mt-1">Consistent practice with varied medical scenarios is key to mastering the OET format.</p>
            </div>
            <div className="p-4 rounded-lg bg-orange-50">
              <h4 className="font-semibold text-orange-700">Feedback Review</h4>
              <p className="text-gray-700 text-sm mt-1">Take time to analyze AI feedback after each practice session to identify improvement areas.</p>
            </div>
            <div className="p-4 rounded-lg bg-purple-50">
              <h4 className="font-semibold text-purple-700">Vocabulary Building</h4>
              <p className="text-gray-700 text-sm mt-1">Focus on expanding your medical terminology knowledge specific to your healthcare field.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OETPage;