import React, { useState } from 'react';
import Navbar from '../components/Navbar';
import SettingsSidebar from '../components/settings/SettingsSidebar';
import SpecialtySettings from '../components/settings/SpecialtySettings';
import CategorySettings from '../components/settings/CategorySettings';
import ProfessionSettings from '../components/settings/ProfessionSettings';
import LanguageSettings from '../components/settings/LanguageSettings';
import PasswordSettings from '../components/settings/PasswordSettings';
import SubscriptionSettings from '../components/settings/SubscriptionSettings';
import CreditBalanceSettings from '../components/settings/CreditBalanceSettings';

interface SettingsProps {
  onLogout: () => void;
}

const Settings: React.FC<SettingsProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState('category');

  const renderContent = () => {
    switch (activeTab) {
      case 'category':
        return <CategorySettings isActive={activeTab === 'category'} />;
      case 'specialty':
        return <SpecialtySettings isActive={activeTab === 'specialty'} />;
      case 'profession':
        return <ProfessionSettings isActive={activeTab === 'profession'} />;
      case 'language':
        return <LanguageSettings isActive={activeTab === 'language'} />;
      case 'subscription':
        return <SubscriptionSettings isActive={activeTab === 'subscription'} />;
      case 'credits':
        return <CreditBalanceSettings isActive={activeTab === 'credits'} />;
      case 'password':
        return <PasswordSettings isActive={activeTab === 'password'} />;
      default:
        return <CategorySettings isActive={activeTab === 'category'} />;
    }
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--color-background-default)' }}>
      <Navbar onLogout={onLogout} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mt-16">
        <div className="bg-white rounded-lg shadow">
          <div className="flex">
            <SettingsSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
            <div className="flex-1 p-6">
              {renderContent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings; 