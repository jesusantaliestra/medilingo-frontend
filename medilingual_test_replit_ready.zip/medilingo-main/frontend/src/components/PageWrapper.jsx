import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

const PageWrapper = ({ children, onLogout }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar onLogout={onLogout} />
      <div className="flex-grow">
        {children}
      </div>
      <Footer />
    </div>
  );
};

export default PageWrapper; 