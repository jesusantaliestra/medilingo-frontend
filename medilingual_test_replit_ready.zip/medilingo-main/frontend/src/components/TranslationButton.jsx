import React, { useState } from 'react';
import { Languages } from 'lucide-react';
import { useMutation } from '@apollo/client';
import { TRANSLATE_TEXT } from '../graphql/mutations';

const TranslationButton = ({ text, nativeLanguage, onTranslate }) => {
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatedText, setTranslatedText] = useState('');
  const [translateText] = useMutation(TRANSLATE_TEXT);

  const handleTranslate = async () => {
    setIsTranslating(true);
    try {
      const { data } = await translateText({
        variables: {
          text: text,
          targetLanguage: nativeLanguage
        }
      });

      if (data?.translateText?.translatedText) {
        setTranslatedText(data.translateText.translatedText);
        if (onTranslate) {
          onTranslate(data.translateText.translatedText);
        }
      }
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setIsTranslating(false);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <button
        onClick={handleTranslate}
        disabled={isTranslating}
        className={`flex items-center justify-center px-4 py-2 rounded-lg text-white font-medium transition-all duration-200 ${
          isTranslating
            ? 'bg-teal-400 cursor-not-allowed'
            : 'bg-teal-600 hover:bg-teal-700 shadow-md hover:shadow-lg'
        }`}
      >
        <Languages className="mr-2" size={18} />
        {isTranslating ? 'Translating...' : 'Translate'}
      </button>
      
      {translatedText && (
        <div className="mt-2 p-3 bg-teal-50 border border-teal-200 rounded-lg text-teal-800 max-w-md">
          {translatedText}
        </div>
      )}
    </div>
  );
};

export default TranslationButton; 