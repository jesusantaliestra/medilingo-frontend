import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-gray-200 py-6 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex justify-center gap-6 flex-wrap">
          <Link
            to="/about"
            className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
          >
            About
          </Link>
          <Link
            to="/legal/terms-conditions"
            className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
          >
            Terms of Service
          </Link>
          <Link
            to="/legal/privacy-policy"
            className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
          >
            Privacy Policy
          </Link>
          <Link
            to="/legal/refund-policy"
            className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
          >
            Refund Policy
          </Link>
          <Link
            to="/legal/cookie-policy"
            className="text-sm text-gray-600 hover:text-gray-900 hover:underline"
          >
            Cookies Policy
          </Link>
        </div>
        <p className="text-sm text-gray-600 text-center mt-4">
          © {new Date().getFullYear()} Santaliestra Limited. MediLingual is a trademark of Santaliestra Limited. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer; 