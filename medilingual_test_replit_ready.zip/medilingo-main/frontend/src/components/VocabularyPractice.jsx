import React, { useState, useEffect } from 'react';
import { BookOpen, Languages, Mic, Volume2, ArrowRight } from 'lucide-react';
import { useQuery, gql, useMutation } from '@apollo/client';
import { TEST_VOCABULARY_PRONUNCIATION, TRANSLATE_TEXT, GENERATE_VOICE, MARK_VOCABULARY_TEST_AS_COMPLETED } from '../graphql/mutations';
import { GET_AVAILABLE_VOCABULARY_ITEM } from '../graphql/queries';
import AudioRecorder from './AudioRecorder';

import ProgressBar from './ProgressBar';

const VocabularyPractice = ({ nativeLanguage, onComplete, levelSlug }) => {
  const [currentTerm, setCurrentTerm] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [translatedTerm, setTranslatedTerm] = useState('');
  const [translatedDefinition, setTranslatedDefinition] = useState('');
  const [isTranslatingTerm, setIsTranslatingTerm] = useState(false);
  const [isTranslatingDefinition, setIsTranslatingDefinition] = useState(false);
  const [pronunciationResult, setPronunciationResult] = useState(null);
  const [isGeneratingVoice, setIsGeneratingVoice] = useState(false);
  const [error, setError] = useState("");
  const [statistics, setStatistics] = useState(null);
  const [attemptCount, setAttemptCount] = useState(0);
  
  const [testPronunciation] = useMutation(TEST_VOCABULARY_PRONUNCIATION);
  const [translateText] = useMutation(TRANSLATE_TEXT);
  const [generateVoice] = useMutation(GENERATE_VOICE);
  const [markVocabularyTestAsCompleted] = useMutation(MARK_VOCABULARY_TEST_AS_COMPLETED);

  // Format percentage to show only one decimal place
  const formatPercentage = (value) => {
    return Math.round(value * 10) / 10;
  };

  const { loading, error: queryError, data, refetch } = useQuery(GET_AVAILABLE_VOCABULARY_ITEM, {
    variables: {
      levelSlug
    },
    notifyOnNetworkStatusChange: true
  });

  useEffect(() => {
    if (data?.availableVocabularyItems) {
      setCurrentTerm(data.availableVocabularyItems.vocabularyItem);
      setStatistics(data.availableVocabularyItems.statistics);
    }
  }, [data]);

  const handleRecordingComplete = async (audioBlob) => {
    if (!currentTerm) return;
    
    setIsLoading(true);
    setError(""); // Clear any previous errors
    try {
      // Convert audio blob to base64
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      
      reader.onloadend = async () => {
        const base64Audio = reader.result.split(',')[1];
        
        try {
          const { data } = await testPronunciation({
            variables: {
              expectedTerm: currentTerm.term,
              audioData: base64Audio,
              vocabularyId: currentTerm.id
            }
          });
          
          if (data?.testVocabularyPronunciation) {
            setPronunciationResult(data.testVocabularyPronunciation);
            setAttemptCount(prev => prev + 1);
          }
        } catch (error) {
          console.error('Error testing pronunciation:', error);
          // Display the server-side error message
          if (error.graphQLErrors && error.graphQLErrors.length > 0) {
            setError(error.graphQLErrors[0].message);
          } else {
            setError("An error occurred while testing pronunciation. Please try again.");
          }
        } finally {
          setIsLoading(false);
        }
      };
    } catch (error) {
      console.error('Error processing audio:', error);
      setError("An error occurred while processing the audio. Please try again.");
      setIsLoading(false);
    }
  };
  
  const handleTranslateTerm = async () => {
    if (translatedTerm) {
      setTranslatedTerm('');
      return;
    }
    
    setIsTranslatingTerm(true);
    try {
      const { data } = await translateText({
        variables: {
          text: currentTerm.term,
          targetLanguage: nativeLanguage
        }
      });
      if (data?.translateText?.translatedText) {
        setTranslatedTerm(data.translateText.translatedText);
      }
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setIsTranslatingTerm(false);
    }
  };

  const handleTranslateDefinition = async () => {
    if (translatedDefinition) {
      setTranslatedDefinition('');
      return;
    }
    
    setIsTranslatingDefinition(true);
    try {
      const { data } = await translateText({
        variables: {
          text: currentTerm.definition,
          targetLanguage: nativeLanguage
        }
      });
      if (data?.translateText?.translatedText) {
        setTranslatedDefinition(data.translateText.translatedText);
      }
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setIsTranslatingDefinition(false);
    }
  };

  const handlePlayAudio = async (text) => {
    if (!text) return;
    
    setIsGeneratingVoice(true);
    try {
      console.log('Generating voice for text:', text);
      const { data } = await generateVoice({
        variables: {
          text: text
        }
      });
      
      console.log('Voice generation response:', data);
      
      if (data?.generateVoice?.audioData) {
        console.log('Audio data received, length:', data.generateVoice.audioData.length);
        const audio = new Audio(`data:audio/mp3;base64,${data.generateVoice.audioData}`);
        
        // Add event listeners for debugging
        audio.addEventListener('error', (e) => {
          console.error('Audio playback error:', e);
        });
        
        audio.addEventListener('loadeddata', () => {
          console.log('Audio loaded successfully');
        });
        
        audio.addEventListener('playing', () => {
          console.log('Audio started playing');
        });
        
        try {
          await audio.play();
          console.log('Audio playback started');
        } catch (playError) {
          console.error('Error playing audio:', playError);
        }
      } else {
        console.error('No audio data received from the server');
      }
    } catch (error) {
      console.error('Error in handlePlayAudio:', error);
    } finally {
      setIsGeneratingVoice(false);
    }
  };

  const handleComplete = () => {
    if (onComplete) {
      onComplete(1);
    }
  };

  const handleNextClick = async () => {
    if (!pronunciationResult) {
      setError("Please record your pronunciation first.");
      return;
    }
    
    if (pronunciationResult.pronunciationScore < 75 && attemptCount < 3) {
      setError("Your pronunciation score must be at least 75% to proceed. Please try again.");
      return;
    }
    
    setError("");
    
    try {
      // Mark the current vocabulary test as completed
      await markVocabularyTestAsCompleted({
        variables: {
          vocabularyId: currentTerm.id
        }
      });
      
      // Move to the next vocabulary item
      refetch();
      setPronunciationResult(null);
      setTranslatedTerm('');
      setTranslatedDefinition('');
      setAttemptCount(0);
    } catch (error) {
      console.error('Error marking vocabulary test as completed:', error);
      setError("Failed to mark vocabulary test as completed. Please try again.");
    }
  };

  if (loading && !currentTerm) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2" style={{borderColor: 'var(--color-primary)'}}></div>
      </div>
    );
  }

  if (queryError) {
    return (
      <div className="text-center p-4 text-red-500">
        Error loading vocabulary: {queryError.message}
      </div>
    );
  }
  
  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      <div className="mb-6">
        <div className="flex items-center mb-2">
          <BookOpen style={{color: 'var(--color-primary)', marginRight: '0.5rem'}} size={20} />
          <h2 className="text-xl font-bold" style={{color: 'var(--color-text-primary)'}}>Medical Vocabulary Practice</h2>
        </div>
      </div>
      
      {currentTerm && (
        <div className="space-y-6">
          {/* Vocabulary Progress Bar */}
          <div className="mb-4">
            <p className="text-sm font-medium mb-1" style={{color: 'var(--color-text-secondary)'}}>
              Vocabulary Progress ({statistics?.completedCount || 0}/{statistics?.totalCount || 0} terms)
            </p>
            <ProgressBar 
              score={formatPercentage(statistics?.completionPercentage || 0)} 
              name="Term Completion" 
            />
          </div>

          <div className="p-4 rounded-lg border" style={{backgroundColor: 'var(--color-background-default)', borderColor: 'var(--color-border-main)'}}>
            <p className="text-sm mb-1" style={{color: 'var(--color-text-secondary)'}}>
              Speciality: {currentTerm.speciality.name}
            </p>
            <div className="flex items-center gap-2">
              <h3 className="text-2xl font-bold" style={{color: 'var(--color-text-primary)'}}>
                {currentTerm.term}
              </h3>
              <button
                onClick={handleTranslateTerm}
                disabled={isTranslatingTerm}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors bg-teal-100 hover:bg-teal-200"
                title="Translate term"
              >
                <Languages 
                  size={24} 
                  className={translatedTerm ? 'text-teal-600' : 'text-teal-500'} 
                />
              </button>
              <button
                onClick={() => handlePlayAudio(currentTerm.term)}
                disabled={isGeneratingVoice}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors bg-blue-100 hover:bg-blue-200"
                title="Listen to term pronunciation"
              >
                <Volume2 
                  size={24} 
                  className={isGeneratingVoice ? 'text-blue-400' : 'text-blue-500'} 
                />
              </button>
            </div>
            {translatedTerm && (
              <p className="text-lg mt-2" style={{color: 'var(--color-text-secondary)'}}>
                {translatedTerm}
              </p>
            )}
            
            <div className="flex items-center gap-2 mt-4">
              <p className="text-lg" style={{color: 'var(--color-text-secondary)'}}>
                {currentTerm.definition}
              </p>
              <button
                onClick={handleTranslateDefinition}
                disabled={isTranslatingDefinition}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors bg-teal-100 hover:bg-teal-200"
                title="Translate definition"
              >
                <Languages 
                  size={24} 
                  className={translatedDefinition ? 'text-teal-600' : 'text-teal-500'} 
                />
              </button>
              <button
                onClick={() => handlePlayAudio(currentTerm.definition)}
                disabled={isGeneratingVoice}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors bg-blue-100 hover:bg-blue-200"
                title="Listen to definition"
              >
                <Volume2 
                  size={24} 
                  className={isGeneratingVoice ? 'text-blue-400' : 'text-blue-500'} 
                />
              </button>
            </div>
            {translatedDefinition && (
              <p className="text-lg mt-2" style={{color: 'var(--color-text-secondary)'}}>
                {translatedDefinition}
              </p>
            )}
          </div>
          
          <div className="flex flex-col items-center space-y-4">
            <div className="text-center">
              <p className="text-sm mb-2" style={{color: 'var(--color-text-secondary)'}}>
                Click the microphone to practice pronunciation
              </p>
              <AudioRecorder 
                onRecordingComplete={handleRecordingComplete}
              />
            </div>
            
            {pronunciationResult && (
              <div className="w-full p-4 rounded-lg border" style={{backgroundColor: 'var(--color-background-default)', borderColor: 'var(--color-border-main)'}}>
                <div className="flex items-center gap-2 mb-2">
                  <Mic size={18} className="text-teal-600" />
                  <h4 className="font-medium" style={{color: 'var(--color-text-primary)'}}>
                    Pronunciation Analysis
                  </h4>
                </div>
                <p className="text-sm mb-1" style={{color: 'var(--color-text-secondary)'}}>
                  You said: <span className="font-medium">{pronunciationResult.spokenText}</span>
                </p>
                
                <div className="space-y-3 mt-3">
                  <ProgressBar 
                    score={pronunciationResult.matchingAccuracy} 
                    name="Matching Accuracy" 
                  />
                  <ProgressBar 
                    score={pronunciationResult.confidenceScore} 
                    name="Confidence Score" 
                  />
                   <ProgressBar 
                    score={pronunciationResult.pronunciationScore} 
                    name="Pronunciation Score (Overall)" 
                  />
                </div>

                <div className="mt-4">
                  <p className="text-sm font-medium mb-1" style={{color: 'var(--color-text-secondary)'}}>Feedback:</p>
                  <p className="text-sm" style={{color: 'var(--color-text-secondary)'}}>
                    {pronunciationResult.feedback}
                  </p>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex justify-center mt-6">
            <button
              onClick={handleComplete}
              className="px-4 py-2 rounded-lg transition-colors mr-4"
              style={{color: 'var(--color-text-secondary)'}}
            >
              Complete Practice
            </button>
            <button
              onClick={handleNextClick}
              className="px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white focus:outline-none focus:ring-1 focus:ring-offset-1 focus:ring-primary"
              style={{
                background: 'var(--color-background-gradient)',
                border: 'none'
              }}
            >
              Next
              <ArrowRight className="inline-block ml-2 h-4 w-4" />
            </button>
          </div>
          
          {error && (
            <div className="mt-3 text-center text-red-500">
              {error}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default VocabularyPractice; 