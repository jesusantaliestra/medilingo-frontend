import React from 'react';
import { useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import { toast } from 'react-toastify';

const UPDATE_PASSWORD = gql`
  mutation UpdatePassword($currentPassword: String!, $newPassword: String!) {
    updatePassword(currentPassword: $currentPassword, newPassword: $newPassword) {
      success
      message
    }
  }
`;

interface PasswordSettingsProps {
  isActive: boolean;
}

const PasswordSettings: React.FC<PasswordSettingsProps> = ({ isActive }) => {
  const [currentPassword, setCurrentPassword] = React.useState('');
  const [newPassword, setNewPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const [updatePassword] = useMutation(UPDATE_PASSWORD);

  const handlePasswordUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }

    try {
      const { data } = await updatePassword({
        variables: {
          currentPassword,
          newPassword
        }
      });

      if (data?.updatePassword?.success) {
        toast.success(data.updatePassword.message || 'Password updated successfully!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        toast.error(data?.updatePassword?.message || 'Failed to update password');
      }
    } catch (error) {
      toast.error('Error updating password: ' + error.message);
    }
  };

  if (!isActive) {
    return null;
  }

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Change Password</h2>
      <form onSubmit={handlePasswordUpdate} className="max-w-md">
        <div className="mb-4">
          <label htmlFor="currentPassword" className="block text-sm font-medium" style={{color: 'var(--color-text-secondary)'}}>
            Current Password
          </label>
          <input
            type="password"
            id="currentPassword"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
            style={{
              borderColor: 'var(--color-border-main)',
              color: 'var(--color-text-primary)',
              backgroundColor: 'var(--color-background-paper)'
            }}
            required
          />
        </div>
        <div className="mb-4">
          <label htmlFor="newPassword" className="block text-sm font-medium" style={{color: 'var(--color-text-secondary)'}}>
            New Password
          </label>
          <input
            type="password"
            id="newPassword"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
            style={{
              borderColor: 'var(--color-border-main)',
              color: 'var(--color-text-primary)',
              backgroundColor: 'var(--color-background-paper)'
            }}
            required
          />
        </div>
        <div className="mb-4">
          <label htmlFor="confirmPassword" className="block text-sm font-medium" style={{color: 'var(--color-text-secondary)'}}>
            Confirm New Password
          </label>
          <input
            type="password"
            id="confirmPassword"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
            style={{
              borderColor: 'var(--color-border-main)',
              color: 'var(--color-text-primary)',
              backgroundColor: 'var(--color-background-paper)'
            }}
            required
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2 text-white rounded-md transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
          style={{
            background: 'var(--color-background-gradient)',
            border: 'none'
          }}
        >
          Update Password
        </button>
      </form>
    </div>
  );
};

export default PasswordSettings; 