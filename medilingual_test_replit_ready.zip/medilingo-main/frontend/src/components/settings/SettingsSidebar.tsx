import React from 'react';
import { User, Lock, Globe, Stethoscope, CreditCard, Coins, Tag } from 'lucide-react';

interface SettingsSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const SettingsSidebar: React.FC<SettingsSidebarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="w-64 border-r" style={{borderColor: 'var(--color-border-main)'}}>
      <nav className="p-4">
        <button
          onClick={() => setActiveTab('category')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg mb-2 transition-colors ${
            activeTab === 'category'
              ? 'text-white' 
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'category' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <Tag className="h-4 w-4 mr-2" />
          Category
        </button>
        <button
          onClick={() => setActiveTab('specialty')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg mb-2 transition-colors ${
            activeTab === 'specialty'
              ? 'text-white' 
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'specialty' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <User className="h-4 w-4 mr-2" />
          Specialty
        </button>
        <button
          onClick={() => setActiveTab('profession')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg mb-2 transition-colors ${
            activeTab === 'profession'
              ? 'text-white'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'profession' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <Stethoscope className="h-4 w-4 mr-2" />
          OET Profession
        </button>
        <button
          onClick={() => setActiveTab('language')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg mb-2 transition-colors ${
            activeTab === 'language'
              ? 'text-white'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'language' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <Globe className="h-4 w-4 mr-2" />
          Language to Learn
        </button>
        <button
          onClick={() => setActiveTab('subscription')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg mb-2 transition-colors ${
            activeTab === 'subscription'
              ? 'text-white'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'subscription' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <CreditCard className="h-4 w-4 mr-2" />
          Subscription
        </button>
        <button
          onClick={() => setActiveTab('credits')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg mb-2 transition-colors ${
            activeTab === 'credits'
              ? 'text-white'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'credits' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <Coins className="h-4 w-4 mr-2" />
          Credit Balance
        </button>
        <button
          onClick={() => setActiveTab('password')}
          className={`flex items-center w-full px-4 py-2 text-sm rounded-lg transition-colors ${
            activeTab === 'password'
              ? 'text-white'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
          style={{
            background: activeTab === 'password' ? 'var(--color-background-gradient)' : 'transparent'
          }}
        >
          <Lock className="h-4 w-4 mr-2" />
          Password
        </button>
      </nav>
    </div>
  );
};

export default SettingsSidebar; 