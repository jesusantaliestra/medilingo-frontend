import React from 'react';
import { useQuery, gql } from '@apollo/client';
import { Coins } from 'lucide-react';

const GET_CREDIT_BALANCE = gql`
  query GetCreditBalance {
    myCreditBalance {
      amount
      createdAt
    }
  }
`;

interface CreditBalanceSettingsProps {
  isActive: boolean;
}

const CreditBalanceSettings: React.FC<CreditBalanceSettingsProps> = ({ isActive }) => {
  const { data, loading, error } = useQuery(GET_CREDIT_BALANCE, {
    skip: !isActive,
    pollInterval: 30000 // Poll every 30 seconds to keep credit balance up to date
  });

  if (!isActive) {
    return null;
  }

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error loading credit balance: {error.message}</div>;
  }

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Credit Balance</h2>
      <div className="max-w-md">
        <div className="p-6 rounded-lg border" style={{
          borderColor: 'var(--color-border-main)',
          backgroundColor: 'var(--color-background-paper)'
        }}>
          <div className="flex items-center space-x-4">
            <div className="p-3 rounded-full" style={{background: 'var(--color-background-gradient)'}}>
              <Coins className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-sm" style={{color: 'var(--color-text-secondary)'}}>
                Available Credits
              </p>
              <p className="text-2xl font-semibold" style={{color: 'var(--color-text-primary)'}}>
                {data?.myCreditBalance?.amount || 0}
              </p>
            </div>
          </div>
          <p className="mt-4 text-sm" style={{color: 'var(--color-text-secondary)'}}>
            Credits are used for practice sessions and assessments. You can get more credits by upgrading your subscription.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CreditBalanceSettings; 