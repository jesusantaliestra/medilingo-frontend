import React from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import { toast } from 'react-toastify';

const GET_USER_PROFESSION = gql`
  query GetUserProfession {
    me {
      id
      profession
    }
  }
`;

const UPDATE_USER_PROFESSION = gql`
  mutation UpdateUserProfession($profession: String!) {
    updateUserProfession(profession: $profession) {
      success
      message
    }
  }
`;

const PROFESSIONS = [
  { value: 'medicine', label: 'Medicine' },
  { value: 'nursing', label: 'Nursing' },
  { value: 'dentistry', label: 'Dentistry' },
  { value: 'pharmacy', label: 'Pharmacy' },
  { value: 'veterinary_science', label: 'Veterinary Science' },
  { value: 'dietetics', label: 'Dietetics' },
  { value: 'occupational_therapy', label: 'Occupational Therapy' },
  { value: 'optometry', label: 'Optometry' },
  { value: 'physiotherapy', label: 'Physiotherapy' },
  { value: 'podiatry', label: 'Podiatry' },
  { value: 'radiography', label: 'Radiography' },
  { value: 'speech_pathology', label: 'Speech Pathology' }
];

interface ProfessionSettingsProps {
  isActive: boolean;
}

const ProfessionSettings: React.FC<ProfessionSettingsProps> = ({ isActive }) => {
  const [selectedProfession, setSelectedProfession] = React.useState('');
  const { data: userData, loading: userLoading } = useQuery(GET_USER_PROFESSION, {
    skip: !isActive
  });
  const [updateProfession] = useMutation(UPDATE_USER_PROFESSION);

  React.useEffect(() => {
    if (userData?.me?.profession) {
      setSelectedProfession(userData.me.profession);
    }
  }, [userData]);

  const handleProfessionUpdate = async () => {
    try {
      const { data } = await updateProfession({
        variables: { profession: selectedProfession }
      });

      if (data?.updateUserProfession?.success) {
        toast.success(data.updateUserProfession.message || 'Profession updated successfully!');
      } else {
        toast.error(data?.updateUserProfession?.message || 'Failed to update profession');
      }
    } catch (error) {
      toast.error('Error updating profession: ' + error.message);
    }
  };

  if (!isActive) {
    return null;
  }

  if (userLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Update Your OET Profession</h2>
      <div className="max-w-md">
        <select
          value={selectedProfession}
          onChange={(e) => setSelectedProfession(e.target.value)}
          className="block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
          style={{
            borderColor: 'var(--color-border-main)',
            color: 'var(--color-text-primary)',
            backgroundColor: 'var(--color-background-paper)'
          }}
        >
          <option value="">Select a profession</option>
          {PROFESSIONS.map((profession) => (
            <option key={profession.value} value={profession.value}>
              {profession.label}
            </option>
          ))}
        </select>
        <button
          onClick={handleProfessionUpdate}
          className="mt-4 px-4 py-2 text-white rounded-md transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
          style={{
            background: 'var(--color-background-gradient)',
            border: 'none'
          }}
        >
          Update Profession
        </button>
      </div>
    </div>
  );
};

export default ProfessionSettings; 