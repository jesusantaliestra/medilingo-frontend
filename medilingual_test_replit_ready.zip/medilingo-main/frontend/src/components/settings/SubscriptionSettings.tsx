import React from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const GET_MY_ACTIVE_SUBSCRIPTION = gql`
  query GetMyActiveSubscription {
    myActiveSubscription {
      id
      planName
      planPrice
      creditsAllocated
      startDate
      endDate
      isActive
      isCancelled
      paymentId
    }
  }
`;

const CREATE_CUSTOMER_PORTAL_SESSION = gql`
  mutation CreateCustomerPortalSession {
    createCustomerPortalSession {
      success
      message
      url
    }
  }
`;

interface SubscriptionSettingsProps {
  isActive: boolean;
}

const SubscriptionSettings: React.FC<SubscriptionSettingsProps> = ({ isActive }) => {
  const navigate = useNavigate();
  const { data, loading, error } = useQuery(GET_MY_ACTIVE_SUBSCRIPTION);

  const [createPortalSession, { loading: portalLoading }] = useMutation(CREATE_CUSTOMER_PORTAL_SESSION, {
    onCompleted: (data) => {
      if (data.createCustomerPortalSession.success) {
        // Redirect to Stripe Customer Portal
        window.location.href = data.createCustomerPortalSession.url;
      } else {
        toast.error(data.createCustomerPortalSession.message);
      }
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const handleManageSubscription = async () => {
    await createPortalSession();
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error loading subscription.</div>;

  const subscription = data?.myActiveSubscription;

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Subscription & Credits</h2>
      <div className="max-w-md space-y-6">
        <div className="p-4 rounded-lg border" style={{
          borderColor: 'var(--color-border-main)',
          backgroundColor: 'var(--color-background-paper)'
        }}>
          <h3 className="text-md font-medium mb-2" style={{color: 'var(--color-text-primary)'}}>Current Plan</h3>
          {subscription && (
            <div className="space-y-2">
              <p className="text-sm" style={{color: 'var(--color-text-secondary)'}}>
                Plan: <span style={{color: 'var(--color-text-primary)'}}>{subscription.planName}</span>
              </p>
              <p className="text-sm" style={{color: 'var(--color-text-secondary)'}}>
                Status: <span style={{color: 'var(--color-success)'}}>
                  {subscription.isCancelled ? 'Cancellation Scheduled' : 'Active'}
                </span>
              </p>
              <p className="text-sm" style={{color: 'var(--color-text-secondary)'}}>
                Expires: <span style={{color: 'var(--color-text-primary)'}}>{new Date(subscription.endDate).toLocaleDateString('en-US', {
                  year: 'numeric', month: 'long', day: 'numeric'
                })}</span>
              </p>
              <div className="flex items-center justify-between mt-4">
                <button
                  className="px-4 py-2 rounded-md transition-all duration-300 transform hover:-translate-y-0.5"
                  style={{
                    background: 'linear-gradient(135deg, #6366F1, #4F46E5)',
                    color: 'white',
                    border: 'none',
                    fontWeight: 500,
                    boxShadow: '0 2px 4px rgba(79, 70, 229, 0.2)',
                  }}
                  onClick={handleManageSubscription}
                  disabled={portalLoading}
                >
                  {portalLoading ? 'Loading...' : 'Manage Subscription'}
                </button>
              </div>
            </div>
          )}
          {!subscription && (
            <div className="flex items-center justify-between mt-4">
              <button
                className="px-4 py-2 rounded-md transition-all duration-300 transform hover:-translate-y-0.5"
                style={{
                  background: 'var(--color-background-gradient)',
                  color: 'white',
                  border: 'none',
                  fontWeight: 500
                }}
                onClick={() => navigate('/pricing')}
              >
                Subscribe
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionSettings; 