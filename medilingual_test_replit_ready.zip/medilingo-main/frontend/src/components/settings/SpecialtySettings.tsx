import React from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import { toast } from 'react-toastify';

const GET_USER_SPECIALTY = gql`
  query GetUserSpecialty {
    me {
      id
      speciality {
        id
        name
        slug
      }
    }
  }
`;

const GET_SPECIALTIES = gql`
  query GetSpecialties {
    userSpecialities {
      id
      name
      slug
    }
  }
`;

const UPDATE_USER_SPECIALTY = gql`
  mutation UpdateUserSpecialty($specialty: String!) {
    updateUserSpecialty(specialty: $specialty) {
      success
      message
    }
  }
`;

interface SpecialtySettingsProps {
  isActive: boolean;
}

const SpecialtySettings: React.FC<SpecialtySettingsProps> = ({ isActive }) => {
  const [specialty, setSpecialty] = React.useState('');
  const { data: userData, loading: userLoading } = useQuery(GET_USER_SPECIALTY, {
    skip: !isActive
  });
  const { data: specialtiesData, loading: specialtiesLoading } = useQuery(GET_SPECIALTIES, {
    skip: !isActive
  });
  const [updateSpecialty] = useMutation(UPDATE_USER_SPECIALTY);

  React.useEffect(() => {
    if (userData?.me?.speciality?.slug) {
      setSpecialty(userData.me.speciality.slug);
    }
  }, [userData]);

  const handleSpecialtyUpdate = async () => {
    try {
      const { data } = await updateSpecialty({
        variables: { specialty }
      });

      if (data?.updateUserSpecialty?.success) {
        toast.success(data.updateUserSpecialty.message || 'Specialty updated successfully!');
      } else {
        toast.error(data?.updateUserSpecialty?.message || 'Failed to update specialty');
      }
    } catch (error) {
      toast.error('Error updating specialty: ' + error.message);
    }
  };

  if (!isActive) {
    return null;
  }

  if (userLoading || specialtiesLoading) {
    return <div>Loading...</div>;
  }

  const allSpecialties = specialtiesData?.userSpecialities || [];

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Update Your Specialty</h2>
      <div className="max-w-md">
        <select
          value={specialty}
          onChange={(e) => setSpecialty(e.target.value)}
          className="block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
          style={{
            borderColor: 'var(--color-border-main)',
            color: 'var(--color-text-primary)',
            backgroundColor: 'var(--color-background-paper)'
          }}
        >
          <option value="">Select a specialty</option>
          {allSpecialties.map((spec) => (
            <option key={spec.id} value={spec.slug}>
              {spec.name}
            </option>
          ))}
        </select>
        <button
          onClick={handleSpecialtyUpdate}
          className="mt-4 px-4 py-2 text-white rounded-md transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
          style={{
            background: 'var(--color-background-gradient)',
            border: 'none'
          }}
        >
          Update Specialty
        </button>
      </div>
    </div>
  );
};

export default SpecialtySettings; 