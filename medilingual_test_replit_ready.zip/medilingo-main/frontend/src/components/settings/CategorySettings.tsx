import React from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import { toast } from 'react-toastify';

const GET_USER_CATEGORY = gql`
  query GetUserCategory {
    me {
      id
      category {
        id
        name
        slug
      }
    }
  }
`;

const GET_CATEGORIES = gql`
  query GetCategories {
    categories {
      id
      name
      slug
    }
  }
`;

const UPDATE_USER_CATEGORY = gql`
  mutation UpdateUserCategory($category: String!) {
    updateUserCategory(category: $category) {
      success
      message
    }
  }
`;

interface CategorySettingsProps {
  isActive: boolean;
}

const CategorySettings: React.FC<CategorySettingsProps> = ({ isActive }) => {
  const [category, setCategory] = React.useState('');
  const { data: userData, loading: userLoading } = useQuery(GET_USER_CATEGORY, {
    skip: !isActive
  });
  const { data: categoriesData, loading: categoriesLoading } = useQuery(GET_CATEGORIES, {
    skip: !isActive
  });
  const [updateCategory] = useMutation(UPDATE_USER_CATEGORY);

  React.useEffect(() => {
    if (userData?.me?.category?.slug) {
      setCategory(userData.me.category.slug);
    }
  }, [userData]);

  const handleCategoryUpdate = async () => {
    try {
      const { data } = await updateCategory({
        variables: { category }
      });

      if (data?.updateUserCategory?.success) {
        toast.success(data.updateUserCategory.message || 'Category updated successfully!');
      } else {
        toast.error(data?.updateUserCategory?.message || 'Failed to update category');
      }
    } catch (error) {
      toast.error('Error updating category: ' + error.message);
    }
  };

  if (!isActive) {
    return null;
  }

  if (userLoading || categoriesLoading) {
    return <div>Loading...</div>;
  }

  const allCategories = categoriesData?.categories || [];

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Update Your Category</h2>
      <div className="max-w-md">
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
          style={{
            borderColor: 'var(--color-border-main)',
            color: 'var(--color-text-primary)',
            backgroundColor: 'var(--color-background-paper)'
          }}
        >
          <option value="">Select a category</option>
          {allCategories.map((cat) => (
            <option key={cat.id} value={cat.slug}>
              {cat.name}
            </option>
          ))}
        </select>
        <button
          onClick={handleCategoryUpdate}
          className="mt-4 px-4 py-2 text-white rounded-md transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
          style={{
            background: 'var(--color-background-gradient)',
            border: 'none'
          }}
        >
          Update Category
        </button>
      </div>
    </div>
  );
};

export default CategorySettings; 