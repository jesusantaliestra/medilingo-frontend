import React from 'react';
import { useQuery, useMutation } from '@apollo/client';
import { gql } from '@apollo/client';
import { toast } from 'react-toastify';
import Cookies from 'js-cookie';
import { languageToLearn } from '../../config/languages';

const GET_USER_LANGUAGE_TO_LEARN = gql`
  query GetUserLanguageToLearn {
    me {
      id
      languageToLearn
    }
  }
`;

const UPDATE_LANGUAGE_TO_LEARN = gql`
  mutation UpdateLanguageToLearn($languageToLearn: String!) {
    updateUserLanguageToLearn(languageToLearn: $languageToLearn) {
      success
      message
    }
  }
`;

interface LanguageSettingsProps {
  isActive: boolean;
}

const LanguageSettings: React.FC<LanguageSettingsProps> = ({ isActive }) => {
  const [selectedLanguageToLearn, setSelectedLanguageToLearn] = React.useState('');
  const { data: languageToLearnData, loading: languageToLearnLoading } = useQuery(GET_USER_LANGUAGE_TO_LEARN, {
    skip: !isActive
  });
  const [updateLanguageToLearn] = useMutation(UPDATE_LANGUAGE_TO_LEARN);

  React.useEffect(() => {
    if (languageToLearnData?.me?.languageToLearn) {
      setSelectedLanguageToLearn(languageToLearnData.me.languageToLearn);
    }
  }, [languageToLearnData]);

  const handleLanguageToLearnUpdate = async () => {
    try {
      const { data } = await updateLanguageToLearn({
        variables: { languageToLearn: selectedLanguageToLearn }
      });

      if (data?.updateUserLanguageToLearn?.success) {
        // Update the cookie immediately
        Cookies.set('accept-language', selectedLanguageToLearn, { expires: 365 });
        toast.success(data.updateUserLanguageToLearn.message || 'Language to learn updated successfully!');
      } else {
        toast.error(data?.updateUserLanguageToLearn?.message || 'Failed to update language to learn');
      }
    } catch (error) {
      toast.error('Error updating language to learn: ' + error.message);
    }
  };

  if (!isActive) {
    return null;
  }

  if (languageToLearnLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2 className="text-lg font-medium mb-4" style={{color: 'var(--color-text-primary)'}}>Update Language to Learn</h2>
      <div className="max-w-md">
        <select
          value={selectedLanguageToLearn}
          onChange={(e) => setSelectedLanguageToLearn(e.target.value)}
          className="block w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2"
          style={{
            borderColor: 'var(--color-border-main)',
            color: 'var(--color-text-primary)',
            backgroundColor: 'var(--color-background-paper)'
          }}
        >
          <option value="">Select a language</option>
          {languageToLearn.map((lang) => (
            <option key={lang.code} value={lang.code}>
              {lang.name}
            </option>
          ))}
        </select>
        <button
          onClick={handleLanguageToLearnUpdate}
          className="mt-4 px-4 py-2 text-white rounded-md transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
          style={{
            background: 'var(--color-background-gradient)',
            border: 'none'
          }}
        >
          Update Language
        </button>
      </div>
    </div>
  );
};

export default LanguageSettings; 