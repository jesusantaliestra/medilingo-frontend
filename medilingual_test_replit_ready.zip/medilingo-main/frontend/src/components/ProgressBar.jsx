import React from 'react';

const ProgressBar = ({ score, name }) => {
  return (
    <div className="mb-6">
      <div className="flex items-center mb-2">
        <h2 className="text-xl font-bold" style={{color: 'var(--color-text-primary)'}}>{name}</h2>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2.5">
        <div 
          className="h-2.5 rounded-full" 
          style={{ 
            width: `${score}%`,
            background: 'var(--color-background-gradient)'
          }}
        ></div>
      </div>
      <p className="text-sm mt-1" style={{color: 'var(--color-text-secondary)'}}>
        Progress: {score}%
      </p>
    </div>
  );
};

export default ProgressBar; 