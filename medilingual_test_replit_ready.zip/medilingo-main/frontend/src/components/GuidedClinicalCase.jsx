import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowRight, Stethoscope, User, MessageSquare, Languages, Volume2, Mic, Loader } from 'lucide-react';
import { useQuery, gql, useMutation } from '@apollo/client';
import AudioRecorder from './AudioRecorder';
import PronunciationFeedback from './PronunciationFeedback';
import ProgressBar from './ProgressBar';
import { TRANSLATE_TEXT, GENERATE_VOICE, SUBMIT_GUIDED_PRACTICE_ATTEMPT } from '../graphql/mutations';

const TEST_PRONUNCIATION = gql`
  mutation TestPronunciation($expectedTerm: String!, $audioData: String!) {
    testPronunciation(expectedTerm: $expectedTerm, audioData: $audioData) {
      spokenText
      matchingAccuracy
      pronunciationScore
      feedback
      confidenceScore
    }
  }
`;

const GUIDED_PRACTICE_QUERY = gql`
  query GuidedPracticeQuery($levelSlug: String!) {
    guidedPracticeGroup(levelSlug: $levelSlug) {
      id
      name
      description
      guidedPractices(first: 100) {
        edges {
          node {
            doctorMessage
            patientMessage
            sequence
          }
        }
      }
      speciality {
        name
      }
    }
  }
`;

const GuidedClinicalCase = ({ nativeLanguage, onComplete, levelSlug }) => {
  const [feedback, setFeedback] = useState(null);
  const [score, setScore] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPlayingPatientResponse, setIsPlayingPatientResponse] = useState(false);
  const [translatedMessages, setTranslatedMessages] = useState({});
  const [isTranslating, setIsTranslating] = useState({});
  const [isGeneratingVoice, setIsGeneratingVoice] = useState(false);
  const [pronunciationResult, setPronunciationResult] = useState(null);
  const [recordedAudioUrl, setRecordedAudioUrl] = useState('');
  const [currentPracticeIndex, setCurrentPracticeIndex] = useState(0);
  const [isPronunciationLoading, setIsPronunciationLoading] = useState(false);
  const audioRef = useRef(new Audio());
  const [errorMessage, setErrorMessage] = useState('');
  const [attemptCount, setAttemptCount] = useState(0);
  
  const [translateText] = useMutation(TRANSLATE_TEXT);
  const [generateVoice] = useMutation(GENERATE_VOICE);
  const [testPronunciation] = useMutation(TEST_PRONUNCIATION);
  const [submitGuidedPracticeAttempt, { loading: isSubmitting }] = useMutation(SUBMIT_GUIDED_PRACTICE_ATTEMPT);

  // Cleanup audio URLs when component unmounts
  useEffect(() => {
    return () => {
      if (recordedAudioUrl) {
        URL.revokeObjectURL(recordedAudioUrl);
      }
    };
  }, [recordedAudioUrl]);

  const { loading, error, data, refetch } = useQuery(GUIDED_PRACTICE_QUERY, {
    variables: { levelSlug },
  });

  if (loading) return (
    <div className="flex justify-center items-center h-64">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-teal-600"></div>
    </div>
  );

  if (error) return (
    <div className="text-center text-red-600">
      Error loading guided practice: {error.message}
    </div>
  );

  const guidedPracticeGroup = data?.guidedPracticeGroup;
  const practices = guidedPracticeGroup?.guidedPractices?.edges?.map(edge => edge.node) || [];
  
  if (!practices.length) {
    return (
      <div className="text-center text-gray-600">
        No practices available for this level.
      </div>
    );
  }

  // Sort practices by sequence
  const sortedPractices = [...practices].sort((a, b) => a.sequence - b.sequence);

  const handleTranslate = async (message, messageId) => {
    if (translatedMessages[messageId]) {
      setTranslatedMessages(prev => {
        const newState = { ...prev };
        delete newState[messageId];
        return newState;
      });
      return;
    }

    setIsTranslating(prev => ({ ...prev, [messageId]: true }));
    try {
      const { data } = await translateText({
        variables: {
          text: message,
          targetLanguage: nativeLanguage
        }
      });

      if (data?.translateText?.translatedText) {
        setTranslatedMessages(prev => ({
          ...prev,
          [messageId]: data.translateText.translatedText
        }));
      }
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setIsTranslating(prev => ({ ...prev, [messageId]: false }));
    }
  };

  const handleRecordingComplete = async (audioBlob, expectedText) => {
    try {
      const audioUrl = URL.createObjectURL(audioBlob);
      setRecordedAudioUrl(audioUrl);
      setIsPronunciationLoading(true);
      setPronunciationResult(null);
      setErrorMessage(''); // Clear any previous errors

      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64Audio = reader.result.split(',')[1];
        
        try {
          const { data } = await testPronunciation({
            variables: {
              expectedTerm: expectedText,
              audioData: base64Audio
            }
          });

          if (data?.testPronunciation) {
            const result = data.testPronunciation;
            setPronunciationResult(result);
            setScore(result.pronunciationScore);
            setFeedback(result.feedback);
            setAttemptCount(prev => prev + 1);
          }
        } catch (error) {
          console.error('Error processing recording:', error);
          // Display the server-side error message
          if (error.graphQLErrors && error.graphQLErrors.length > 0) {
            setErrorMessage(error.graphQLErrors[0].message);
          } else {
            setErrorMessage("An error occurred while testing pronunciation. Please try again.");
          }
        } finally {
          setIsPronunciationLoading(false);
        }
      };
    } catch (error) {
      console.error('Error processing recording:', error);
      setErrorMessage("An error occurred while processing the audio. Please try again.");
      setIsPronunciationLoading(false);
    }
  };

  const handlePlayAudio = async (message) => {
    if (!message) return;
    
    setIsGeneratingVoice(true);
    try {
      const { data } = await generateVoice({
        variables: {
          text: message
        }
      });
      
      if (data?.generateVoice?.audioData) {
        const audio = new Audio(`data:audio/mp3;base64,${data.generateVoice.audioData}`);
        await audio.play();
      }
    } catch (error) {
      console.error('Error generating voice:', error);
    } finally {
      setIsGeneratingVoice(false);
    }
  };

  const handleSubmitAndNext = async () => {
    setErrorMessage('');
    if (!guidedPracticeGroup?.id) return;
    const submitScore = score == null ? 1 : Math.round(score);
    
    if (submitScore < 75 && attemptCount < 3) {
      setErrorMessage('Your pronunciation score must be at least 75% to proceed. Please try again.');
      return;
    }

    try {
      await submitGuidedPracticeAttempt({
        variables: {
          guidedGroupId: guidedPracticeGroup.id,
          score: submitScore,
        },
      });
      await refetch();
      setAttemptCount(0); // Reset attempt count after successful submission
      // Optionally call onComplete or advance UI here
    } catch (err) {
      // Optionally handle error
      console.error('Error submitting guided practice attempt:', err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="mb-6">
        <div className="flex items-center mb-2">
          <Stethoscope className="text-teal-600 mr-2" size={20} />
          <h2 className="text-xl font-bold text-gray-800">{guidedPracticeGroup.name}</h2>
        </div>
        <p className="text-gray-600 mb-4">{guidedPracticeGroup.description}</p>
      </div>
      
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Pronunciation Feedback - Appears first on mobile */}
        <div className="order-1 lg:order-2 lg:w-1/3 lg:sticky lg:top-0 lg:self-start bg-white rounded-xl shadow-lg p-4 md:p-6">
          <h3 className="text-lg font-semibold mb-4 text-gray-800 flex items-center gap-2">
            <Mic size={20} className="text-teal-600" />
            Pronunciation Feedback
          </h3>
          
          {isPronunciationLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader size={40} className="text-teal-600 animate-spin mb-4" />
              <p className="text-gray-600 text-center">
                Analyzing your pronunciation...<br />
                <span className="text-sm text-gray-500">This may take up to 30 seconds</span>
              </p>
            </div>
          ) : pronunciationResult ? (
            <div className="p-4 rounded-lg border" style={{backgroundColor: 'var(--color-background-default)', borderColor: 'var(--color-border-main)'}}>
              <p className="text-sm mb-3" style={{color: 'var(--color-text-secondary)'}}>
                You said: <span className="font-medium">{pronunciationResult.spokenText}</span>
              </p>
              
              <div className="space-y-3 mt-3">
                <ProgressBar 
                  score={pronunciationResult.matchingAccuracy} 
                  name="Matching Accuracy" 
                />
                <ProgressBar 
                  score={pronunciationResult.confidenceScore} 
                  name="Confidence Score" 
                />
                <ProgressBar 
                  score={pronunciationResult.pronunciationScore} 
                  name="Pronunciation Score (Overall)" 
                />
              </div>
              
              <p className="text-sm font-medium mt-4 mb-1" style={{color: 'var(--color-text-secondary)'}}>Feedback:</p>
              <p className="text-sm" style={{color: 'var(--color-text-secondary)'}}>
                {pronunciationResult.feedback}
              </p>
            </div>
          ) : (
            <div className="text-center text-gray-500 py-12">
              <Mic size={40} className="mx-auto mb-2 text-gray-400" />
              <p>Record your pronunciation to see feedback here</p>
            </div>
          )}

          {errorMessage && (
            <div className="mt-3 text-center text-red-500">
              {errorMessage}
            </div>
          )}
        </div>

        {/* Conversation Thread - Appears second on mobile */}
        <div className="order-2 lg:order-1 flex-1 bg-white rounded-xl shadow-lg p-4 md:p-6 mt-6 lg:mt-0">
          <div className="space-y-4">
            {sortedPractices.map((practice, index) => (
              <div key={index} className="space-y-4">
                {/* Doctor Message */}
                <div className="flex items-start gap-2 justify-end">
                  <div className="flex-1 flex flex-col items-end">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handlePlayAudio(practice.doctorMessage)}
                          className="p-1 rounded-full hover:bg-blue-100 transition-colors"
                          disabled={isGeneratingVoice}
                          title="Play message"
                        >
                          <Volume2 size={16} className="text-blue-600" />
                        </button>
                        <button
                          onClick={() => handleTranslate(practice.doctorMessage, `doctor-${index}`)}
                          disabled={isTranslating[`doctor-${index}`]}
                          className="p-1 rounded-full hover:bg-blue-100 transition-colors"
                          title="Translate message"
                        >
                          <Languages size={16} className="text-blue-600" />
                        </button>
                        <div className="p-1">
                          <AudioRecorder 
                            onRecordingComplete={(audioBlob) => {
                              setCurrentPracticeIndex(index);
                              handleRecordingComplete(audioBlob, practice.doctorMessage);
                            }}
                            size="small"
                          />
                        </div>
                      </div>
                      <span className="text-sm font-medium text-blue-600">
                        {data.guidedPracticeGroup.speciality?.name}
                        </span>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-3 max-w-[80%]">
                      <p className="text-gray-700">{practice.doctorMessage}</p>
                      {translatedMessages[`doctor-${index}`] && (
                        <div className="mt-2 pt-2 border-t border-blue-100 text-sm text-blue-700">
                          {translatedMessages[`doctor-${index}`]}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                      <Stethoscope className="text-blue-600" size={16} />
                    </div>
                  </div>
                </div>

                {/* Patient Message */}
                <div className="flex items-start gap-2">
                  <div className="flex-shrink-0">
                    <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center">
                      <User className="text-teal-600" size={16} />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-teal-600">Patient</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleTranslate(practice.patientMessage, `patient-${index}`)}
                          disabled={isTranslating[`patient-${index}`]}
                          className="p-1 rounded-full hover:bg-teal-100 transition-colors"
                          title="Translate message"
                        >
                          <Languages size={16} className="text-teal-600" />
                        </button>
                        <button
                          onClick={() => handlePlayAudio(practice.patientMessage)}
                          className="p-1 rounded-full hover:bg-teal-100 transition-colors"
                          disabled={isGeneratingVoice}
                          title="Play message"
                        >
                          <Volume2 size={16} className="text-teal-600" />
                        </button>
                        <div className="p-1">
                          <AudioRecorder 
                            onRecordingComplete={(audioBlob) => {
                              setCurrentPracticeIndex(index);
                              handleRecordingComplete(audioBlob, practice.patientMessage);
                            }}
                            size="small"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-teal-50 rounded-lg p-3 max-w-[80%]">
                      <p className="text-gray-700">{practice.patientMessage}</p>
                      {translatedMessages[`patient-${index}`] && (
                        <div className="mt-2 pt-2 border-t border-teal-100 text-sm text-teal-700">
                          {translatedMessages[`patient-${index}`]}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end mt-4 flex-col items-end">
            {errorMessage && (
              <div className="mb-2 text-red-600 font-medium text-sm text-right">
                {errorMessage}
              </div>
            )}
            <button
              className="flex items-center px-4 py-2 text-white rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg"
              style={{
                background: 'var(--color-background-gradient)',
                border: 'none'
              }}
              onClick={handleSubmitAndNext}
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Submitting...' : 'Submit & Next'}
              <ArrowRight className="ml-2" size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GuidedClinicalCase; 