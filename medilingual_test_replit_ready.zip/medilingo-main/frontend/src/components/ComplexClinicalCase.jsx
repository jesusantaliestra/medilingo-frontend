import React, { useState, useEffect, useRef } from 'react';
import { ArrowRight, Stethoscope, User, History, Mic, Square, Languages, Volume2, Send } from 'lucide-react';
import { useMutation, useQuery, gql } from '@apollo/client';
import { toast } from 'react-toastify';
import { PROCESS_AUDIO_AND_GENERATE_RESPONSE, TRANSLATE_TEXT } from '../graphql/mutations';

const GET_PATIENT_CASE = gql`
  query GetPatientCase($levelSlug: String!) {
    patientCase(levelSlug: $levelSlug) {
      id
      title
      content
      speciality {
        name
      }
      level {
        name
      }
    }
  }
`;

const ComplexClinicalCase = ({ nativeLanguage, onComplete, levelSlug }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [conversation, setConversation] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [transcribedText, setTranscribedText] = useState('');
  const [translatedMessages, setTranslatedMessages] = useState({});
  const [voiceResponses, setVoiceResponses] = useState({});
  const [isPatientTyping, setIsPatientTyping] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedback, setFeedback] = useState(null);
  
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const chatContainerRef = useRef(null);
  const audioPlayerRef = useRef(new Audio());
  
  const [processAudioAndGenerateResponse] = useMutation(PROCESS_AUDIO_AND_GENERATE_RESPONSE);
  const [translateText] = useMutation(TRANSLATE_TEXT);

  const { loading: caseLoading, error: caseError, data: caseData } = useQuery(GET_PATIENT_CASE, {
    variables: { levelSlug },
    skip: !levelSlug
  });
  
  // Parse the patient case content into a structured format
  const clinicalCase = React.useMemo(() => {
    if (!caseData?.patientCase?.content) return null;
    return {
      description: caseData.patientCase.content
    };
  }, [caseData]);
  
  useEffect(() => {
    // Initialize the conversation with the case description
    setConversation([
      {
        role: 'system',
        content: `Patient Case: ${clinicalCase?.description}`
      }
    ]);
  }, [clinicalCase]);
  
  // Add useEffect for auto-scrolling
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTo({
        top: chatContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [conversation]);
  
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        } 
      });
      
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 64000 // Reduced from 128000 for faster processing
      });
      
      audioChunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorderRef.current.start(100); // Reduced from 250ms to 100ms for more frequent updates
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      toast.error('Failed to access microphone. Please check your permissions.');
    }
  };

  const playVoiceResponse = async (base64Audio) => {
    try {
      const audioBlob = await fetch(`data:audio/mp3;base64,${base64Audio}`).then(res => res.blob());
      const audioUrl = URL.createObjectURL(audioBlob);
      audioPlayerRef.current.src = audioUrl;
      audioPlayerRef.current.playbackRate = 1.0; // Changed from 1.2 to 1.0 for normal speech rate
      await audioPlayerRef.current.play();
    } catch (error) {
      console.error('Error playing voice response:', error);
      toast.error('Failed to play voice response');
    }
  };

  const stopRecording = async () => {
    if (mediaRecorderRef.current && isRecording) {
      setIsRecording(false);
      
      return new Promise((resolve) => {
        mediaRecorderRef.current.onstop = async () => {
          try {
            const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
            
            // Convert audio blob to base64
            const reader = new FileReader();
            reader.readAsDataURL(audioBlob);
            
            reader.onloadend = async () => {
              const base64Audio = reader.result.split(',')[1];
              
              try {
                setIsLoading(true);
                setIsPatientTyping(true);
                
                // Process audio and generate response in parallel
                const [audioResponse] = await Promise.all([
                  processAudioAndGenerateResponse({
                    variables: {
                      audioData: base64Audio,
                      conversationHistory: conversation,
                      clinicalCase: clinicalCase,
                      isComplexPractice: true
                    }
                  })
                ]);
                
                if (audioResponse.data.processAudioAndGenerateResponse) {
                  const { text, response, voiceResponse } = audioResponse.data.processAudioAndGenerateResponse;
                  
                  setTranscribedText(text);
                  setCurrentQuestion(text);
                  
                  // Update conversation with both the transcribed text and AI response
                  setConversation([
                    ...conversation,
                    {
                      role: 'doctor',
                      content: text
                    },
                    {
                      role: 'patient',
                      content: response
                    }
                  ]);

                  // Store and play voice response if available
                  if (voiceResponse) {
                    setVoiceResponses(prev => ({
                      ...prev,
                      [conversation.length + 1]: voiceResponse
                    }));
                    await playVoiceResponse(voiceResponse);
                  }
                  
                  // Clear the current question and transcribed text
                  setCurrentQuestion('');
                  setTranscribedText('');
                }
              } catch (error) {
                console.error('Error processing audio and generating response:', error);
                // Display the server-side error message
                if (error.graphQLErrors && error.graphQLErrors.length > 0) {
                  toast.error(error.graphQLErrors[0].message);
                } else {
                  toast.error('Failed to process audio and generate response. Please try again.');
                }
              } finally {
                setIsLoading(false);
                setIsPatientTyping(false);
              }
            };
          } catch (error) {
            console.error('Error processing audio:', error);
            toast.error('Failed to process audio. Please try again.');
          }
          
          resolve();
        };
        
        mediaRecorderRef.current.stop();
      });
    }
  };

  const handleRecordingComplete = async (audioBlob) => {
    if (!currentQuestion.trim()) {
      return; // Don't proceed if there's no question
    }
    
    setIsLoading(true);
    
    try {
      // Add the doctor's question to the conversation
      const newConversation = [
        ...conversation,
        {
          role: 'doctor',
          content: currentQuestion
        }
      ];
      
      // Generate AI response
      const { data } = await processAudioAndGenerateResponse({
        variables: {
          audioData: audioBlob ? audioBlob.toString() : '',  // Empty string for text-only chat
          conversationHistory: newConversation,
          clinicalCase: clinicalCase,
          isComplexPractice: true
        }
      });
      
      if (data?.processAudioAndGenerateResponse) {
        const { text, response, voiceResponse } = data.processAudioAndGenerateResponse;
        
        // Add the patient's response to the conversation
        setConversation([
          ...newConversation,
          {
            role: 'patient',
            content: response
          }
        ]);
        
        // Store voice response if available (only for voice input)
        if (audioBlob && voiceResponse) {
          setVoiceResponses(prev => ({
            ...prev,
            [newConversation.length]: voiceResponse
          }));
          await playVoiceResponse(voiceResponse);
        }
        
        // Update transcribed text only for voice input
        if (audioBlob) {
          setTranscribedText(text);
        }
      }
      
      // Clear the current question
      setCurrentQuestion('');
      
    } catch (error) {
      console.error('Error generating AI response:', error);
      // Display the server-side error message
      if (error.graphQLErrors && error.graphQLErrors.length > 0) {
        toast.error(error.graphQLErrors[0].message);
      } else {
        toast.error('Failed to generate response. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSubmitQuestion = () => {
    if (currentQuestion.trim()) {
      handleRecordingComplete(null);
    }
  };
  
  const handleCompleteConsultation = async () => {
    setIsLoading(true);
    try {
      // Analyze the conversation for feedback
      const doctorMessages = conversation.filter(msg => msg.role === 'doctor');
      const patientMessages = conversation.filter(msg => msg.role === 'patient');
      
      // Calculate basic metrics
      const totalMessages = doctorMessages.length;
      const avgMessageLength = doctorMessages.reduce((acc, msg) => acc + msg.content.length, 0) / totalMessages;
      
      // Analyze medical terminology usage
      const medicalTerms = ['diagnosis', 'treatment', 'symptoms', 'prescription', 'examination', 'prognosis', 'referral', 'follow-up'];
      const medicalTermCount = doctorMessages.reduce((acc, msg) => {
        return acc + medicalTerms.filter(term => msg.content.toLowerCase().includes(term)).length;
      }, 0);
      
      // Analyze professional tone
      const professionalPhrases = ['please', 'thank you', 'would you', 'could you', 'may I', 'let me explain', 'I understand'];
      const professionalPhraseCount = doctorMessages.reduce((acc, msg) => {
        return acc + professionalPhrases.filter(phrase => msg.content.toLowerCase().includes(phrase)).length;
      }, 0);
      
      // Generate feedback based on actual conversation analysis
      const feedbackData = {
        englishFluency: {
          score: Math.min(5, Math.max(1, Math.floor(avgMessageLength / 50))), // Score based on message length
          comments: [
            totalMessages > 5 ? "Good engagement in the conversation" : "Could engage more with the patient",
            avgMessageLength > 50 ? "Good use of detailed explanations" : "Could provide more detailed responses",
            medicalTermCount > 3 ? "Appropriate use of medical terminology" : "Could use more medical terminology"
          ]
        },
        voiceAccuracy: {
          score: Math.min(5, Math.max(1, Math.floor(professionalPhraseCount / 2))), // Score based on professional phrases
          comments: [
            professionalPhraseCount > 3 ? "Good use of professional language" : "Could use more professional phrases",
            "Clear communication style",
            "Appropriate tone for medical consultation"
          ]
        },
        commonMistakes: [
          totalMessages < 3 ? "Could ask more follow-up questions" : null,
          medicalTermCount < 2 ? "Could use more medical terminology" : null,
          professionalPhraseCount < 2 ? "Could use more professional phrases" : null,
          avgMessageLength < 30 ? "Could provide more detailed explanations" : null
        ].filter(Boolean),
        overallScore: Math.min(100, Math.max(0, 
          (avgMessageLength * 0.3) + 
          (medicalTermCount * 10) + 
          (professionalPhraseCount * 10) +
          (totalMessages * 5)
        )),
        suggestions: [
          totalMessages < 5 ? "Practice asking more follow-up questions" : null,
          medicalTermCount < 3 ? "Study and practice using more medical terminology" : null,
          professionalPhraseCount < 3 ? "Practice using more professional phrases" : null,
          avgMessageLength < 40 ? "Practice providing more detailed explanations" : null,
          "Review medical consultation best practices",
          "Practice active listening and responding appropriately"
        ].filter(Boolean)
      };
      
      setFeedback(feedbackData);
      setShowFeedback(true);
    } catch (error) {
      console.error('Error generating feedback:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleComplete = () => {
    if (onComplete) {
      onComplete(conversation.length - 1); // Subtract 1 for the initial system message
    }
  };
  
  const handleTranslate = async (messageIndex) => {
    const message = conversation[messageIndex];
    if (!message || message.role !== 'patient') return;

    try {
      const { data } = await translateText({
        variables: {
          text: message.content,
          targetLanguage: nativeLanguage
        }
      });

      if (data.translateText.translatedText) {
        setTranslatedMessages(prev => ({
          ...prev,
          [messageIndex]: data.translateText.translatedText
        }));
      }
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Failed to translate message. Please try again.');
    }
  };
  
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault(); // Prevent default to avoid newline
      if (currentQuestion.trim()) {
        handleSubmitQuestion();
      }
    }
  };
  
  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-xl shadow-lg">
      <div className="mb-6">
        <div className="flex items-center mb-2">
          <Stethoscope className="text-teal-600 mr-2" size={20} />
          <h2 className="text-xl font-bold text-gray-800">{clinicalCase?.title}</h2>
        </div>
        <p className="text-gray-600 mb-4">{clinicalCase?.description}</p>
      </div>
      
      <div className="space-y-6">
        <div 
          ref={chatContainerRef}
          className="bg-gray-50 p-4 rounded-lg border border-gray-200 h-64 overflow-y-auto scroll-smooth"
        >
          {conversation.map((message, index) => (
            <div 
              key={index} 
              className={`mb-4 ${
                message.role === 'doctor' ? 'text-right' : 'text-left'
              }`}
            >
              <div 
                className={`inline-block p-3 rounded-lg ${
                  message.role === 'doctor' 
                    ? 'bg-teal-100 text-teal-800' 
                    : message.role === 'patient'
                      ? 'bg-indigo-100 text-indigo-800'
                      : 'bg-gray-200 text-gray-800'
                }`}
              >
                <div className="flex items-center">
                  {message.role === 'doctor' ? (
                    <Stethoscope className="mr-1" size={16} />
                  ) : message.role === 'patient' ? (
                    <User className="mr-1" size={16} />
                  ) : (
                    <History className="mr-1" size={16} />
                  )}
                  <span className="font-medium">
                    {message.role === 'doctor' 
                      ? `${caseData.patientCase.speciality.name}`
                      : message.role === 'patient'
                        ? 'Patient'
                        : 'System'}
                  </span>
                  {message.role === 'patient' && (
                    <>
                      <button
                        onClick={() => handleTranslate(index)}
                        className="ml-2 p-1 rounded-full bg-indigo-200 hover:bg-indigo-300 transition-colors"
                      >
                        <Languages size={14} />
                      </button>
                      {voiceResponses[index] && (
                        <button
                          onClick={() => playVoiceResponse(voiceResponses[index])}
                          className="ml-2 p-1 rounded-full bg-indigo-200 hover:bg-indigo-300 transition-colors"
                        >
                          <Volume2 size={14} />
                        </button>
                      )}
                    </>
                  )}
                </div>
                <p>{message.content}</p>
                {translatedMessages[index] && (
                  <div className="mt-2 p-2 bg-indigo-50 rounded text-indigo-700 text-sm">
                    {translatedMessages[index]}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isPatientTyping && (
            <div className="flex items-center space-x-2 text-gray-500">
              <User className="text-indigo-600" size={16} />
              <span className="font-medium">Patient</span>
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex flex-col space-y-4">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={currentQuestion}
              onChange={(e) => setCurrentQuestion(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your question here..."
              className="flex-grow p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <button
              onClick={isRecording ? stopRecording : startRecording}
              className={`p-2 rounded-lg ${
                isRecording 
                  ? 'bg-red-500 hover:bg-red-600' 
                  : 'bg-teal-600 hover:bg-teal-700'
              } text-white transition-colors`}
            >
              {isRecording ? <Square size={18} /> : <Mic size={18} />}
            </button>
            <button
              onClick={handleSubmitQuestion}
              disabled={!currentQuestion.trim() || isLoading}
              className={`p-2 rounded-lg ${
                !currentQuestion.trim() || isLoading
                  ? 'bg-gray-300 cursor-not-allowed'
                  : 'bg-teal-600 hover:bg-teal-700'
              } text-white transition-colors`}
            >
              <Send size={18} />
            </button>
          </div>
          
          {isRecording && (
            <div className="text-center text-red-500 font-medium">
              Recording... Speak now
            </div>
          )}
          
          {transcribedText && (
            <div className="text-sm text-gray-600">
              Transcribed: {transcribedText}
            </div>
          )}
        </div>
        
        <div className="flex justify-end mt-6">
          <button
            onClick={handleCompleteConsultation}
            disabled={isLoading}
            className={`flex items-center px-4 py-2 text-white rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg ${
              isLoading ? 'opacity-50 cursor-not-allowed' : ''
            }`}
            style={{
              background: 'var(--color-background-gradient)',
              border: 'none'
            }}
          >
            {isLoading ? 'Generating Feedback...' : 'Complete Consultation'}
            <ArrowRight className="ml-2" size={18} />
          </button>
        </div>
      </div>
      
      {showFeedback && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Consultation Feedback</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-blue-800 mb-2">English Fluency</h3>
              <div className="flex items-center mb-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-5 h-5 ${i < feedback.englishFluency.score ? 'text-yellow-400' : 'text-gray-300'}`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">{feedback.englishFluency.score}/5</span>
              </div>
              <ul className="list-disc list-inside text-sm text-gray-700">
                {feedback.englishFluency.comments.map((comment, index) => (
                  <li key={index}>{comment}</li>
                ))}
              </ul>
            </div>

            <div className="bg-green-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold text-green-800 mb-2">Voice Accuracy</h3>
              <div className="flex items-center mb-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-5 h-5 ${i < feedback.voiceAccuracy.score ? 'text-yellow-400' : 'text-gray-300'}`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">{feedback.voiceAccuracy.score}/5</span>
              </div>
              <ul className="list-disc list-inside text-sm text-gray-700">
                {feedback.voiceAccuracy.comments.map((comment, index) => (
                  <li key={index}>{comment}</li>
                ))}
              </ul>
            </div>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-yellow-800 mb-2">Common Mistakes</h3>
            <ul className="list-disc list-inside text-sm text-gray-700">
              {feedback.commonMistakes.map((mistake, index) => (
                <li key={index}>{mistake}</li>
              ))}
            </ul>
          </div>

          <div className="bg-purple-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-purple-800 mb-2">Overall Performance</h3>
            <div className="flex items-center mb-4">
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-purple-600 h-2.5 rounded-full"
                  style={{ width: `${feedback.overallScore}%` }}
                ></div>
              </div>
              <span className="ml-2 text-sm font-medium text-gray-700">{feedback.overallScore}%</span>
            </div>
            <h4 className="text-md font-medium text-purple-700 mb-2">Suggestions for Improvement:</h4>
            <ul className="list-disc list-inside text-sm text-gray-700">
              {feedback.suggestions.map((suggestion, index) => (
                <li key={index}>{suggestion}</li>
              ))}
            </ul>
          </div>

          <div className="flex justify-end">
            <button
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Next Clinical Case
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComplexClinicalCase; 