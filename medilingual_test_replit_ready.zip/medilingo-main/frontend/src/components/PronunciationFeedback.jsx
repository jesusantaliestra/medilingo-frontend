import React from 'react';
import { Check, X, AlertTriangle, Info } from 'lucide-react';

const PronunciationFeedback = ({ feedback, score }) => {
  // Determine feedback color and icon based on score
  const getFeedbackStyle = () => {
    if (score >= 90) {
      return {
        color: 'text-green-600',
        bgColor: 'bg-green-50',
        borderColor: 'border-green-200',
        icon: <Check className="text-green-500" size={20} />,
        title: 'Excellent Pronunciation!'
      };
    } else if (score >= 70) {
      return {
        color: 'text-blue-600',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
        icon: <Info className="text-blue-500" size={20} />,
        title: 'Good Pronunciation'
      };
    } else if (score >= 50) {
      return {
        color: 'text-yellow-600',
        bgColor: 'bg-yellow-50',
        borderColor: 'border-yellow-200',
        icon: <AlertTriangle className="text-yellow-500" size={20} />,
        title: 'Fair Pronunciation'
      };
    } else {
      return {
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-200',
        icon: <X className="text-red-500" size={20} />,
        title: 'Needs Improvement'
      };
    }
  };

  const style = getFeedbackStyle();

  return (
    <div className={`p-4 rounded-lg border ${style.bgColor} ${style.borderColor} ${style.color}`}>
      <div className="flex items-center mb-2">
        {style.icon}
        <h3 className="ml-2 font-semibold">{style.title}</h3>
        <div className="ml-auto font-bold">{score}%</div>
      </div>
      
      {feedback && (
        <div className="mt-2">
          <h4 className="font-medium mb-1">Feedback:</h4>
          <ul className="list-disc pl-5 space-y-1">
            {Array.isArray(feedback) ? (
              feedback.map((item, index) => (
                <li key={index}>{item}</li>
              ))
            ) : (
              <li>{feedback}</li>
            )}
          </ul>
        </div>
      )}
      
      <div className="mt-3 pt-2 border-t border-gray-200">
        <div className="flex items-center">
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div 
              className={`h-2.5 rounded-full ${
                score >= 90 ? 'bg-green-500' : 
                score >= 70 ? 'bg-blue-500' : 
                score >= 50 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${score}%` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PronunciationFeedback; 