import React, { useState, useEffect } from 'react';
import { BookOpen, Stethoscope, User, Award, ChevronRight } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Navbar from './Navbar';
import { useQuery, gql } from '@apollo/client';
import Cookies from 'js-cookie';
import { getLanguageInfo } from '../config/languages';
import ProgressBar from './ProgressBar';

const GET_LEVELS = gql`
  query GetLevels {
    allLevels {
      id
      name
      title
      description
      slug
      isTopLevel
      levelType
      totalPractice
      totalCompleted
      sublevels {
        id
        name
        title
        description
        slug
      }
    }
  }
`;

const GET_SUBLEVELS = gql`
  query GetSublevels($levelSlug: String!) {
    sublevels(levelSlug: $levelSlug) {
      id
      name
      title
      description
      slug
      levelType
      totalPractice
      totalCompleted
    }
  }
`;

const LevelChooserPage = ({ nativeLanguage, onLogout }) => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const levelSlug = searchParams.get('level');
  
  // Get the language to learn from cookie and get its name
  const languageToLearnCode = Cookies.get('accept-language');
  const languageToLearn = languageToLearnCode ? getLanguageInfo(languageToLearnCode) : null;
  const languageName = languageToLearn ? languageToLearn.name : 'English'; // Default to English if not found
  
  const { loading: levelsLoading, error: levelsError, data: levelsData } = useQuery(GET_LEVELS);
  const { loading: sublevelsLoading, error: sublevelsError, data: sublevelsData } = useQuery(GET_SUBLEVELS, {
    variables: { levelSlug },
    skip: !levelSlug
  });
  
  const getLevelIcon = (levelName) => {
    switch(levelName) {
      case 'Level 1':
        return <BookOpen size={24} className="text-blue-600" />;
      case 'Level 2':
        return <Stethoscope size={24} className="text-blue-600" />;
      case 'Level 3':
        return <User size={24} className="text-blue-600" />;
      default:
        return <BookOpen size={24} className="text-blue-600" />;
    }
  };
  
  const handleLevelSelect = (level) => {
    if (level.sublevels && level.sublevels.length > 0) {
      // If level has sublevels, navigate to the level page with the level slug as a query parameter
      navigate(`/levelchooser?level=${level.slug}`);
    } else {
      // Navigate directly to practice based on level type
      const levelTypeToPracticeType = {
        'vocabulary': 'vocabulary',
        'guided_case': 'guided',
        'complex_case': 'complex'
      };
      // Default to 'vocabulary' if levelType is not available
      const practiceType = level.levelType ? 
        levelTypeToPracticeType[level.levelType.toLowerCase()] || 'vocabulary' : 
        'vocabulary';
      navigate(`/level/${level.slug}/practice/${practiceType}`);
    }
  };
  
  // Calculate progress percentage
  const calculateProgress = (totalPractice, totalCompleted) => {
    if (!totalPractice || totalPractice === 0) return 0;
    return Math.round((totalCompleted / totalPractice) * 100);
  };
  
  if (levelsLoading || (levelSlug && sublevelsLoading)) return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 via-white to-blue-50">
      <Navbar onLogout={onLogout} />
      <main className="flex-grow container mx-auto px-4 py-8 mt-16">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
        </div>
      </main>
    </div>
  );
  
  if (levelsError || sublevelsError) return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 via-white to-blue-50">
      <Navbar onLogout={onLogout} />
      <main className="flex-grow container mx-auto px-4 py-8 mt-16">
        <div className="text-center text-red-600">
          Error loading levels: {levelsError?.message || sublevelsError?.message}
        </div>
      </main>
    </div>
  );
  
  // If we have a level parameter, show its sublevels
  if (levelSlug && sublevelsData?.sublevels) {
    return (
      <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 via-white to-blue-50">
        <Navbar onLogout={onLogout} />
        <main className="flex-grow container mx-auto px-4 py-8 mt-16">
          <div className="space-y-4 sm:space-y-6">
            <div className="flex justify-between items-center mb-6 sm:mb-8">
              <div className="text-center flex-1">
                <h1 className="text-2xl sm:text-3xl font-bold mb-2 text-gray-800">Select a Practice Mode</h1>
                <p className="text-sm sm:text-base text-gray-600">Choose a practice mode to begin improving your medical English skills</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {sublevelsData.sublevels.map((sublevel) => (
                <div 
                  key={sublevel.id}
                  className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-blue-200 hover:border-blue-500 transition-all duration-200 cursor-pointer"
                  onClick={() => {
                    const levelTypeToPracticeType = {
                      'vocabulary': 'vocabulary',
                      'guided_case': 'guided',
                      'complex_case': 'complex'
                    };
                    // Default to 'vocabulary' if levelType is not available
                    const practiceType = sublevel.levelType ? 
                      levelTypeToPracticeType[sublevel.levelType.toLowerCase()] || 'vocabulary' : 
                      'vocabulary';
                    navigate(`/level/${sublevel.slug}/practice/${practiceType}`);
                  }}
                >
                  <div className="flex items-center mb-3 sm:mb-4">
                    {getLevelIcon(sublevel.name)}
                    <h2 className="text-lg sm:text-xl font-bold ml-2 text-gray-800">{sublevel.name}</h2>
                  </div>
                  <h3 className="text-base sm:text-lg font-semibold mb-2 text-gray-800">{sublevel.title}</h3>
                  <p className="text-sm sm:text-base mb-4 text-gray-600">{sublevel.description}</p>
                  <ProgressBar 
                    score={calculateProgress(sublevel.totalPractice, sublevel.totalCompleted)} 
                    name={`${sublevel.name} Progress`} 
                  />
                  <button 
                    className="w-full flex items-center justify-center px-4 py-2 text-white rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg mt-4"
                    style={{
                      background: 'var(--color-background-gradient)',
                      border: 'none'
                    }}
                  >
                    Start Practice
                    <ChevronRight className="ml-2" size={16} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }
  
  // Filter to show only top-level levels
  const topLevels = levelsData.allLevels?.filter(level => level.isTopLevel);
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-50 via-white to-blue-50">
      <Navbar onLogout={onLogout} />
      
      <main className="flex-grow container mx-auto px-4 py-8 mt-16">
        <div className="space-y-4 sm:space-y-6">
          <div className="flex justify-between items-center mb-6 sm:mb-8">
            <div className="text-center flex-1">
              <h1 className="text-2xl sm:text-3xl font-bold mb-2 text-gray-800">Medical {languageName} Practice</h1>
              <p className="text-sm sm:text-base text-gray-600">Complete all levels to master medical {languageName} communication skills. Each level builds upon the previous one, helping you progress from basic vocabulary to complex clinical conversations.</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {topLevels?.map((level) => (
              <div 
                key={level.id}
                className="bg-white rounded-xl shadow-lg p-4 sm:p-6 border border-blue-200 hover:border-blue-500 transition-all duration-200 cursor-pointer"
                onClick={() => handleLevelSelect(level)}
              >
                <div className="flex items-center mb-3 sm:mb-4">
                  {getLevelIcon(level.name)}
                  <h2 className="text-lg sm:text-xl font-bold ml-2 text-gray-800">{level.name}</h2>
                </div>
                <h3 className="text-base sm:text-lg font-semibold mb-2 text-gray-800">{level.title}</h3>
                <p className="text-sm sm:text-base mb-4 text-gray-600">{level.description}</p>
                <ProgressBar 
                  score={calculateProgress(level.totalPractice, level.totalCompleted)} 
                  name={`${level.name} Progress`} 
                />
                <button 
                  className="w-full flex items-center justify-center px-4 py-2 text-white rounded-lg transition-all duration-300 transform hover:-translate-y-0.5 shadow-md hover:shadow-lg mt-4"
                  style={{
                    background: 'var(--color-background-gradient)',
                    border: 'none'
                  }}
                >
                  Start Practice
                  <ChevronRight className="ml-2" size={16} />
                </button>
              </div>
            ))}
          </div>
          
          <div className="p-3 sm:p-4 rounded-lg border border-blue-200 mt-6 sm:mt-8 bg-gradient-to-r from-blue-50 to-blue-100">
            <div className="flex items-center mb-2">
              <Award size={18} className="text-blue-600 mr-2" />
              <h3 className="font-semibold text-sm sm:text-base text-blue-700">Progress Overview</h3>
            </div>
            <p className="text-sm sm:text-base text-gray-600">
              Complete all levels to master medical {languageName} communication skills. Each level builds upon the previous one, helping you progress from basic vocabulary to complex clinical conversations.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default LevelChooserPage; 