import React, { useState, useRef, useEffect } from 'react';
import { Mic, Play, Square, Pause } from 'lucide-react';

const AudioRecorder = ({ onRecordingComplete, exampleAudioUrl, size = 'large' }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [audioBlob, setAudioBlob] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const timerRef = useRef(null);
  const audioRef = useRef(new Audio());

  // Cleanup audio URL when component unmounts
  useEffect(() => {
    return () => {
      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        } 
      });
      
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: 'audio/webm',
        audioBitsPerSecond: 128000
      });
      
      audioChunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        setAudioBlob(audioBlob);
        setAudioUrl(audioUrl);
        
        if (onRecordingComplete) {
          onRecordingComplete(audioBlob);
        }
      };
      
      mediaRecorderRef.current.start(250); // Collect data every 250ms
      setIsRecording(true);
      setRecordingTime(0);
      
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const togglePlayback = () => {
    if (!audioUrl) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.src = audioUrl;
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const playExample = () => {
    if (!exampleAudioUrl) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.src = exampleAudioUrl;
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  // Handle audio events
  useEffect(() => {
    const audio = audioRef.current;
    
    const handleEnded = () => {
      setIsPlaying(false);
    };
    
    const handlePause = () => {
      setIsPlaying(false);
    };
    
    const handlePlay = () => {
      setIsPlaying(true);
    };
    
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('play', handlePlay);
    
    return () => {
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('play', handlePlay);
    };
  }, []);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const buttonSize = size === 'small' ? 16 : 24;
  const buttonPadding = size === 'small' ? 'p-1' : 'p-3';

  return (
    <div className={`flex ${size === 'small' ? 'items-center' : 'flex-col items-center space-y-4'}`}>
      <div className={`flex items-center ${size === 'small' ? '' : 'space-x-4'}`}>
        <button
          onClick={isRecording ? stopRecording : startRecording}
          className={`flex items-center justify-center ${buttonPadding} rounded-full ${
            isRecording 
              ? 'bg-red-500 hover:bg-red-600' 
              : 'bg-teal-600 hover:bg-teal-700'
          } text-white shadow-md transition-all duration-200`}
        >
          {isRecording ? <Square size={buttonSize} /> : <Mic size={buttonSize} />}
        </button>
        
        {audioUrl && (
          <button
            onClick={togglePlayback}
            className={`flex items-center justify-center ${buttonPadding} rounded-full bg-indigo-600 hover:bg-indigo-700 text-white shadow-md transition-all duration-200 ${size === 'small' ? 'ml-1' : ''}`}
          >
            {isPlaying ? <Pause size={buttonSize} /> : <Play size={buttonSize} />}
          </button>
        )}
        
        {exampleAudioUrl && (
          <button
            onClick={playExample}
            className={`flex items-center justify-center ${buttonPadding} rounded-full bg-purple-600 hover:bg-purple-700 text-white shadow-md transition-all duration-200 ${size === 'small' ? 'ml-1' : ''}`}
          >
            <Play size={buttonSize} />
          </button>
        )}
      </div>
      
      {isRecording && (
        <div className={`text-red-500 font-medium ${size === 'small' ? 'ml-2' : 'mt-2'}`}>
          {formatTime(recordingTime)}
        </div>
      )}
      
      {audioUrl && !isRecording && size === 'large' && (
        <div className="text-teal-600 font-medium">
          Recording complete! Click play to hear your pronunciation.
        </div>
      )}
    </div>
  );
};

export default AudioRecorder; 