import React, { useState, useEffect } from 'react';
import { BookOpen, Mic, Stethoscope, MessageSquare, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

const AuthSidebar = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  // Rotate testimonials automatically
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTestimonial(prev => (prev + 1) % testimonials.length);
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  // Learning features for promotional display
  const features = [
    {
      icon: <BookOpen className="text-white" size={24} />,
      title: "Medical Vocabulary",
      description: "Learn specialized terminology for patient consultations and clinical practice"
    },
    {
      icon: <Mic className="text-white" size={24} />,
      title: "AI Pronunciation Feedback",
      description: "Perfect your medical English with real-time pronunciation assessment"
    },
    {
      icon: <Stethoscope className="text-white" size={24} />,
      title: "Clinical Case Studies",
      description: "Practice with realistic patient scenarios in a risk-free environment"
    },
    {
      icon: <MessageSquare className="text-white" size={24} />,
      title: "Patient Communication",
      description: "Master effective communication techniques for diverse patient interactions"
    },
    {
      icon: <Award className="text-white" size={24} />,
      title: "Achievement System",
      description: "Track your progress with gamified learning goals and personalized rewards"
    }
  ];

  const testimonials = [
    {
      quote: "MediLingual transformed my confidence when speaking with international patients. The AI pronunciation feedback is incredibly helpful.",
      name: "Dr. Maria Rodriguez",
      title: "Cardiologist",
      country: "Spain",
      avatar: "MR"
    },
    {
      quote: "The clinical scenarios are exactly like my daily interactions. I've improved so much in just two months.",
      name: "Nurse Takashi Yamamoto",
      title: "Emergency Room Nurse",
      country: "Japan",
      avatar: "TY"
    },
    {
      quote: "As a non-native English speaker, MediLingual has been invaluable in helping me communicate precisely with patients and colleagues.",
      name: "Dr. Elena Petrov",
      title: "Neurologist",
      country: "Russia",
      avatar: "EP"
    }
  ];

  return (
    <div className="hidden lg:flex lg:w-1/2 flex-col justify-between relative overflow-hidden" 
         style={{background: 'var(--color-background-gradient)'}}>
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-white opacity-5 rounded-full -mr-48 -mt-48"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-white opacity-5 rounded-full -ml-40 -mb-40"></div>
      <div className="absolute top-1/2 left-1/3 w-64 h-64 bg-white opacity-5 rounded-full"></div>
      
      <div className="relative z-10 p-12">
        <div className="flex items-center mb-12">
          <img 
            src="/logoicon.png" 
            alt="MediLingual Logo" 
            className="h-12 w-12 mr-3"
          />
          <div>
            <h1 className="text-3xl font-bold text-white tracking-tight">MediLingual</h1>
            <p className="text-white text-opacity-90 mt-1 text-sm">Professional Medical English</p>
          </div>
        </div>
        <div className="mt-8 text-white">
          <h2 className="text-2xl font-semibold mb-2 leading-tight">Master Medical English</h2>
          <h3 className="text-xl font-light mb-5 leading-tight text-white text-opacity-90">Like Never Before</h3>
          <p className="mb-6 text-base leading-relaxed opacity-90">The interactive app designed exclusively for healthcare professionals to perfect their medical English communication skills.</p>
          
          <div className="mt-8 space-y-4">
            {features.map((feature, index) => (
              <div key={index} className="flex items-start group transition-all duration-300 hover:translate-x-1 cursor-pointer">
                <div className="flex items-center justify-center p-2 rounded-lg mr-3 group-hover:scale-105 transition-all" 
                     style={{backgroundColor: 'rgba(255, 255, 255, 0.15)'}}>
                  {feature.icon}
                </div>
                <div>
                  <h3 className="font-semibold text-base">{feature.title}</h3>
                  <p className="text-white text-opacity-90 text-sm">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Testimonial slider */}
      <div className="relative z-10 mx-12 mb-8 p-5 rounded-xl backdrop-blur-sm border border-opacity-20 overflow-hidden"
           style={{backgroundColor: 'rgba(255, 255, 255, 0.1)', borderColor: 'rgba(255, 255, 255, 0.2)'}}>
        <div className="absolute top-0 left-0 w-full h-1">
          <div className="h-full bg-white bg-opacity-50 animate-progress" style={{animationDuration: '8s'}}></div>
        </div>
        <div className="flex items-center mb-3">
          <div className="flex">
            {[1, 2, 3, 4, 5].map(star => (
              <svg key={star} className="w-4 h-4 text-yellow-300 mr-1" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
              </svg>
            ))}
          </div>
          <span className="text-white text-xs ml-2">4.9/5 from 2,800+ healthcare professionals</span>
        </div>
        
        <div className="relative overflow-hidden" style={{height: '100px'}}>
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className={`absolute w-full transition-opacity duration-500 ${
                index === activeTestimonial ? 'opacity-100' : 'opacity-0'
              }`}
            >
              <p className="text-white text-opacity-90 text-sm mb-3">{testimonial.quote}</p>
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-white bg-opacity-20 flex items-center justify-center text-white font-semibold text-xs mr-3">
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="text-white font-semibold text-sm">{testimonial.name}</p>
                  <p className="text-white text-opacity-70 text-xs">{testimonial.title}, {testimonial.country}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Links */}
      <div className="relative z-10 mx-12 mb-4">
        <div className="flex justify-center gap-6 flex-wrap">
          <Link
            to="/about"
            className="text-sm text-white text-opacity-70 hover:text-opacity-100 hover:underline"
          >
            About
          </Link>
          <Link
            to="/legal/terms-conditions"
            className="text-sm text-white text-opacity-70 hover:text-opacity-100 hover:underline"
          >
            Terms of Service
          </Link>
          <Link
            to="/legal/privacy-policy"
            className="text-sm text-white text-opacity-70 hover:text-opacity-100 hover:underline"
          >
            Privacy Policy
          </Link>
          <Link
            to="/legal/refund-policy"
            className="text-sm text-white text-opacity-70 hover:text-opacity-100 hover:underline"
          >
            Refund Policy
          </Link>
          <Link
            to="/legal/cookie-policy"
            className="text-sm text-white text-opacity-70 hover:text-opacity-100 hover:underline"
          >
            Cookies Policy
          </Link>
        </div>
        <p className="text-sm text-white text-opacity-70 text-center mt-4">
          © {new Date().getFullYear()} Santaliestra Limited. MediLingual is a trademark of Santaliestra Limited. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default AuthSidebar; 