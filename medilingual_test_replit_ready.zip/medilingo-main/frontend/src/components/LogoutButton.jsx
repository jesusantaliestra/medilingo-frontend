import React from 'react';
import { LogOut } from 'lucide-react';

const LogoutButton = ({ onLogout }) => {
  return (
    <button
      onClick={onLogout}
      className="flex items-center px-3 py-1.5 text-gray-600 hover:text-gray-800 transition-colors text-sm sm:text-base"
    >
      <LogOut className="mr-1" size={16} />
      Logout
    </button>
  );
};

export default LogoutButton; 