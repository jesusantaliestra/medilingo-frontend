import React, { useState, useRef, useEffect } from 'react';
import { LogOut, ChevronDown, User, Settings, BookOpen } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import MediLingualLogo from './MediLingualLogo';
import Cookies from 'js-cookie';
import { getLanguageInfo } from '../config/languages';

interface NavbarProps {
  onLogout: () => void;
  title?: string;
}

const Navbar: React.FC<NavbarProps> = ({ onLogout, title }) => {
  const navigate = useNavigate();
  const currentLanguage = Cookies.get('current_language');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleLogoClick = () => {
    navigate('/');
  };

  const handleChangeLanguage = () => {
    navigate('/choose-language');
  };

  const handleOETExamClick = () => {
    navigate('/oet');
  };

  const handleSettings = () => {
    navigate('/settings');
    setIsDropdownOpen(false);
  };

  const handleLogout = () => {
    onLogout();
    setIsDropdownOpen(false);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const languageInfo = currentLanguage ? getLanguageInfo(currentLanguage) : null;

  return (
    <header className="bg-white shadow-sm fixed top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div 
          className="flex items-center cursor-pointer hover:opacity-80 transition-opacity"
          onClick={handleLogoClick}
        >
          <MediLingualLogo className="h-10 w-10 mr-3" />
          <h1 className="text-2xl font-bold" style={{color: 'var(--color-primary)'}}>MediLingual</h1>
        </div>
        
        <div className="flex-1 flex justify-center">
          <button
            onClick={handleOETExamClick}
            className="flex items-center px-6 py-2.5 rounded-lg text-white font-medium shadow-md hover:shadow-xl transform hover:-translate-y-1 active:translate-y-0 active:shadow-inner transition-all duration-200 scale-100 hover:scale-105 active:scale-95 cursor-pointer"
            style={{
              background: 'linear-gradient(135deg, #2563eb, #7c3aed, #db2777)',
              backgroundSize: '200% 200%',
              border: 'none',
              animation: 'gradientShift 3s ease infinite',
              boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)'
            }}
          >
            <BookOpen className="h-5 w-5 mr-2 animate-pulse" />
            OET Exam
          </button>
        </div>
        
        <div className="flex items-center space-x-4">
          {languageInfo && (
            <button
              onClick={handleChangeLanguage}
              className="flex items-center px-3 py-1.5 rounded-lg bg-gray-50 border border-gray-200 hover:bg-gray-100 transition-colors group"
            >
              <img
                src={`https://flagcdn.com/w20/${languageInfo.flagCode}.png`}
                alt={`${languageInfo.name} flag`}
                className="w-4 h-3 mr-2"
              />
              <span className="text-sm font-medium text-gray-700 mr-1">
                {languageInfo.name}
              </span>
              <ChevronDown className="h-4 w-4 text-gray-500 group-hover:text-gray-700 transition-colors" />
            </button>
          )}
          
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
            >
              <User className="h-5 w-5 text-gray-600" />
            </button>

            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 border border-gray-200">
                <button
                  onClick={handleSettings}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </button>
                <button
                  onClick={handleLogout}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar; 