import React from 'react';

interface MediLingualLogoProps {
  className?: string;
}

const MediLingualLogo: React.FC<MediLingualLogoProps> = ({ className }) => {
  return (
    <img 
      src="/logoicon.png" 
      alt="MediLingual Logo" 
      className={className}
    />
  );
};

export default MediLingualLogo; 